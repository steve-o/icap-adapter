package com.thomsonreuters.rfa.valueadd.admin.internal;

import java.io.File;
import java.io.UnsupportedEncodingException;
import java.net.URL;
import java.net.URLDecoder;
import com.reuters.rfa.common.Context;

public class AdminContext
{
    private static String DefaultProductVersion = "7.2.0.L1.all";
    private static Class<AdminContext> vaPackageClass = AdminContext.class;
    public static String getRFAVersion()
    {
        return Context.getRFAVersionInfo().getProductVersion();
    }

    public static String getVersion()
    {
        Package pckz = vaPackageClass.getPackage();
        if (pckz != null)
        {
            String version = pckz.getImplementationVersion();
            return version == null ? DefaultProductVersion : version;
        }
        return DefaultProductVersion;
    }

    public static long getBuildTime()
    {
        String jarFilePath = getJarFilePath(vaPackageClass);
        if (jarFilePath != null) 
        {
            File file = new File(jarFilePath);
            if (file.canRead()) {
                return file.lastModified();
            }
        }
        return System.currentTimeMillis();
    }

    private static String getJarFilePath(Class<?> clazz)
    {
        URL url = ClassLoader.getSystemResource(clazz.getName().replace('.', '/') + ".class");
        // extract everything after "file:/" up to and including ".jar"
        if (url == null)
            return null;

        String urlString = null;
        try
        {
            urlString = URLDecoder.decode(url.toString(), "UTF-8");
        }
        catch (UnsupportedEncodingException e)
        {
            return null;
        }

        String startToken = "file:";
        String endToken = ".jar";
        int startPos = urlString.indexOf(startToken);
        if (startPos == -1)
            return null;
        startPos += startToken.length();
        urlString = urlString.substring(startPos);
        if (urlString.length() == 0)
            return null;
        int endPos = urlString.indexOf(endToken);
        if (endPos == -1)
            return null;
        endPos += endToken.length();
        urlString = urlString.substring(0, endPos);

        return urlString;
    }
}
