package com.thomsonreuters.rfa.valueadd.admin;

import java.util.logging.Level;

import com.reuters.rfa.config.ConfigDb;

/**
 * Base class used by configuration for consumer, interactive provider and non-interactive provider core.
 * <p>Example usage:<br>
 * <code>
 * ConsumerCoreConfig config = new ConsumerCoreConfig();<br>
 * config.setSessionName("RSSLNameSpace::Consumer");<br>
 * ...<br>
 * consumerCore.initialize(config);<br>
 * </code>
 * @see ConsumerCoreConfig
 * @see ProviderInteractiveCoreConfig
 * @see ProviderNonInteractiveCoreConfig
 */
public class CoreConfig
{
    private String sessionName;
    private Level rfaLogLevel = Level.INFO;
    private String coreName;
    private boolean completionEventInterest = true;
    private int dispatchTimeout = 10;
    private boolean useInternalThread = true;
    private boolean commandErrorInterest = true;
    private Level adminLogLevel = Level.INFO;
    private String adminLogFile;
    private ConfigDb rfaConfigDb = null;
    private boolean useDeprecatedRequestMsgs = true;
    
    public CoreConfig()
    {

    }

    /**
     * 
     * @return Session name used by OMM event source.
     */
    public String getSessionName()
    {
        return sessionName;
    }

   /**
    * 
    * @param sessionName Session name used by OMM event source. <br>
     * Default values:<br>
     * <li>"RSSLNameSpace::Consumer" for ConsumerCore 
     * <li>"RSSLNameSpace::ProviderInteractive" for ProviderInteractiveCore
     * <li>"RSSLNameSpace::ProviderNonInteractive" for ProviderNonInteractiveCore
    */
    public void setSessionName(String sessionName)
    {
        this.sessionName = sessionName;
    }

    /**
     * 
     * @return Flag that indicates if Core has registered interest in completion events.
     */
    public boolean getCompletionEventInterest()
    {
        return completionEventInterest;
    }

    /**
     * Sets interest for completion events from OMM event source. It is used during core initialization.
     * @param completionEventInterest <br>
     * Default value is true.
     */
    public void setCompletionEventInterest(boolean completionEventInterest)
    {
        this.completionEventInterest = completionEventInterest;
    }

    /**
     * 
     * @return Log level used by all RFA loggers.
     */
    public Level getRFALogLevel()
    {
        return rfaLogLevel;
    }

    /**
     * 
     * @param logLevel Log level to use by RFA loggers. <br>
     * Default value is Level.INFO.
     */
    public void setRFALogLevel(Level logLevel)
    {
        this.rfaLogLevel = logLevel;
    }

    /**
     * 
     * @return Dispatch timeout in milliseconds used by core's dispatch thread.
     */
    public int getDispatchTimeout()
    {
        return dispatchTimeout;
    }

    /**
     * 
     * @param dispatchTimeout Timeout in milliseconds for dispatch thread. <br>
     * Default value is 10 milliseconds.
     */
    public void setDispatchTimeout(int dispatchTimeout)
    {
        this.dispatchTimeout = dispatchTimeout;
    }

    /**
     * 
     * @return Flag that indicates whether core is using internal dispatch thread.  
     */
    public boolean useInternalThread()
    {
        return useInternalThread;
    }

    /**
     * Sets flag to indicate whether to use internal dispatch thread or not. It is used during core initialization.
     * @param useInternalThread <br>
     * Default value is true.
     */
    public void useInternalThread(boolean useInternalThread)
    {
        this.useInternalThread = useInternalThread;
    }

    /**
     * 
     * @return If core has registered interest in command error events.
     */
    public boolean getCommandErrorInterest()
    {
        return commandErrorInterest;
    }
    
    /**
     * Sets interest for command error events. It is used during core initialization.
     * @param commandErrorInterest <br>
     * Default value is true.
     */
    public void setCommandErrorInterest(boolean commandErrorInterest)
    {
        this.commandErrorInterest = commandErrorInterest;
    }

    /**
     * 
     * @return Core's name.
     */
    public String getCoreName()
    {
        return coreName;
    }

    /**
     * 
     * @param coreName <br>
     * Default values: <br>
     * "Consumer" for ConsumerCore<br>
     * "ProviderInteractive" for ProviderInteractiveCore<br>
     * "ProviderNonInteractive" for ProviderNonInteractiveCore<br>
     */
    public void setCoreName(String coreName)
    {
        this.coreName = coreName;
    }
    
    /**
     * 
     * @return Log level used by core admin.
     */
    public Level getAdminLogLevel()
    {
        return adminLogLevel;
    }
   
    /**
     * 
     * @param adminLogLevel Log level to be used by core admin. <br>
     * Default value is Level.INFO.
     */
    public void setAdminLogLevel(Level adminLogLevel)
    {
        this.adminLogLevel = adminLogLevel;
    }
    
    /**
     * 
     * @return Log file for core admin.
     */
    public String getAdminLogFile()
    {
        return adminLogFile;
    }
    
    /**
     * 
     * @param adminLogFile Log file for core admin. <br>
     * Default is to log to console (Stdout).
     */
    public void setAdminLogFile(String adminLogFile)
    {
        this.adminLogFile = adminLogFile;
    }

    /**
     * 
     * @return ConfigDb for RFA. Returns valid value only when non-default ConfigDb is used by RFA. 
     */
    public ConfigDb getRFAConfigDb()
    {
        return rfaConfigDb;
    }
    
    /**
     * 
     * @param rfaConfigDb Non-default ConfigDb to be used by RFA. When not set, RFA uses preference database by default. 
     */
    public void setRFAConfigDb(ConfigDb rfaConfigDb)
    {
        this.rfaConfigDb = rfaConfigDb;
    }

    
    /**
     * Clears all previously set values for configuration. All values are set to their default values.
     * <p> This should be used only after un-initialization. Calling between initialize() and uninitialize() call
     * have no effect on configuration values already used by the core admin. 
     */
    public void clear()
    {
        sessionName = "RSSLNameSpace::Session_1";
        rfaLogLevel = Level.INFO;

        completionEventInterest = true;
        dispatchTimeout = 10;
        useInternalThread = true;
        commandErrorInterest = true;
        adminLogFile = null;
        adminLogLevel = Level.INFO;
        rfaConfigDb = null;
        useDeprecatedRequestMsgs = true;
    }

    public String toString()
    {
        StringBuilder buffer = new StringBuilder();
        buffer.append("SessionName: " + sessionName);
        buffer.append(", Log Level: " + rfaLogLevel);
        buffer.append(", CoreName: " + coreName);
        buffer.append(", Wants completion events? " + completionEventInterest);
        buffer.append(", Wants error events? " + commandErrorInterest);
        buffer.append(", Dispatch timeout (millis): " + dispatchTimeout);
        buffer.append(", Using Dispatch Thread? " + useInternalThread);
        if(adminLogLevel != null)
            buffer.append(", Log Level for Value Add Admin: " + adminLogLevel);
        buffer.append(", Log File for Value Add Admin: " + adminLogFile);
        return buffer.toString();
    }
    
    /**
     * 
     * Used by AdminCore to determine how to decode request messages.
     * This only affect interactive providers.
     * @param value true indicates that request messages should be 
     * decoded into the deprecated request message types. false indicates
     * that request messages should be decoded into the REQUEST message type.
     * @see com.thomsonreuters.rfa.valueadd.domainrep.rdm.login.RDMLoginRequest.MessageType
     * @see com.thomsonreuters.rfa.valueadd.domainrep.rdm.dictionary.RDMDictionaryRequest.MessageType
     * @see com.thomsonreuters.rfa.valueadd.domainrep.rdm.directory.RDMDirectoryRequest.MessageType
     * @since RFAJ7.2.1
     */
    public void setUseDeprecatedRequestMsgs(boolean value)
    {
        useDeprecatedRequestMsgs = value;
    }
    
    public boolean getUseDeprecatedRequestMsgs()
    {
        return useDeprecatedRequestMsgs;
    }


}
