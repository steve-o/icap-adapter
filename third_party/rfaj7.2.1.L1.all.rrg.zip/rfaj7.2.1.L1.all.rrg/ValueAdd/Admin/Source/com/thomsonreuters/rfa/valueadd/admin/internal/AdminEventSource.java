package com.thomsonreuters.rfa.valueadd.admin.internal;

import com.reuters.rfa.common.Client;
import com.reuters.rfa.common.EventQueue;
import com.reuters.rfa.common.EventSource;
import com.reuters.rfa.common.Handle;
import com.reuters.rfa.common.InterestSpec;
import com.reuters.rfa.common.Token;
import com.reuters.rfa.session.Session;
import com.reuters.rfa.session.omm.OMMCmd;
import com.reuters.rfa.session.omm.OMMConsumer;
import com.reuters.rfa.session.omm.OMMProvider;
import com.thomsonreuters.rfa.valueadd.admin.CoreConfig;
import com.thomsonreuters.rfa.valueadd.util.ValueAddException;
import com.thomsonreuters.rfa.valueadd.util.ValueAddMessageKeys;

public class AdminEventSource
{
    private EventSource eventSource;

    public AdminEventSource(Session session, int esType, CoreConfig config)
    {
        eventSource = session.createEventSource(esType, config.getCoreName(),
                                                config.getCompletionEventInterest());
    }

    public Handle register(InterestSpec intSpec, EventQueue eventQueue, Client client,
            Object closure)
    {
        if (eventSource.getEventSourceType() == EventSource.OMM_CONSUMER)
        {
            return ((OMMConsumer)eventSource).registerClient(eventQueue, intSpec, client, closure);
        }
        else if (eventSource.getEventSourceType() == EventSource.OMM_PROVIDER)
        {
            return ((OMMProvider)eventSource).registerClient(eventQueue, intSpec, client, closure);
        }
        else
            throw new ValueAddException(ValueAddMessageKeys.INVALID_EVENT_SOURCE.format(eventSource
                    .getEventSourceType()));

    }

    public Token generateToken()
    {
        if (eventSource.getEventSourceType() == EventSource.OMM_PROVIDER)
        {
            return ((OMMProvider)eventSource).generateToken();
        }
        else
            throw new ValueAddException(ValueAddMessageKeys.INVALID_EVENT_SOURCE.format(eventSource
                    .getEventSourceType()));

    }

    public void reissue(Handle handle, InterestSpec intSpec)
    {
        if (eventSource.getEventSourceType() == EventSource.OMM_CONSUMER)
        {
            ((OMMConsumer)eventSource).reissueClient(handle, intSpec);
        }
        else
            throw new ValueAddException(ValueAddMessageKeys.INVALID_EVENT_SOURCE.format(eventSource
                    .getEventSourceType()));
    }

    public void unregister(Handle handle)
    {
        if (eventSource.getEventSourceType() == EventSource.OMM_CONSUMER)
        {
            ((OMMConsumer)eventSource).unregisterClient(handle);
        }
        else if (eventSource.getEventSourceType() == EventSource.OMM_PROVIDER)
        {
            ((OMMProvider)eventSource).unregisterClient(handle);
        }
        else
            throw new ValueAddException(ValueAddMessageKeys.INVALID_EVENT_SOURCE.format(eventSource
                    .getEventSourceType()));
    }

    public int submit(OMMCmd cmd, Object closure)
    {
        if (eventSource.getEventSourceType() == EventSource.OMM_CONSUMER)
        {
            return ((OMMConsumer)eventSource).submit(cmd, closure);
        }
        else if (eventSource.getEventSourceType() == EventSource.OMM_PROVIDER)
        {
            return ((OMMProvider)eventSource).submit(cmd, closure);
        }
        else
            throw new ValueAddException(ValueAddMessageKeys.INVALID_EVENT_SOURCE.format(eventSource
                    .getEventSourceType()));
    }

    public void cleanup()
    {
        if (eventSource != null)
            eventSource.destroy();
    }
}
