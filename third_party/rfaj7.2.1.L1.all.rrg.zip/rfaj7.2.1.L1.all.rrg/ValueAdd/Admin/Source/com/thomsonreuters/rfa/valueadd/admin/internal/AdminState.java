package com.thomsonreuters.rfa.valueadd.admin.internal;

public enum AdminState
{
    NONE, CONSTRUCTED, INITIALIZED, UNINITIALIZED;
}
