package com.thomsonreuters.rfa.valueadd.admin;

import java.net.InetAddress;

import com.reuters.rfa.common.Client;
import com.reuters.rfa.common.Event;
import com.reuters.rfa.common.EventSource;
import com.reuters.rfa.common.Handle;
import com.reuters.rfa.common.Token;
import com.reuters.rfa.omm.OMMMsg;
import com.reuters.rfa.omm.OMMPool;
import com.reuters.rfa.session.TimerIntSpec;
import com.reuters.rfa.session.omm.OMMCmdErrorEvent;
import com.reuters.rfa.session.omm.OMMErrorIntSpec;
import com.reuters.rfa.session.omm.OMMItemCmd;
import com.reuters.rfa.session.omm.OMMItemEvent;
import com.reuters.rfa.session.omm.OMMItemIntSpec;
import com.reuters.rfa.session.omm.OMMProvider;
import com.thomsonreuters.rfa.valueadd.admin.internal.AdminState;
import com.thomsonreuters.rfa.valueadd.domainrep.rdm.login.RDMLoginRequest;
import com.thomsonreuters.rfa.valueadd.domainrep.rdm.login.RDMLoginRequestAttrib;
import com.thomsonreuters.rfa.valueadd.domainrep.rdm.login.RDMLogin;
import com.thomsonreuters.rfa.valueadd.util.ValueAddException;
import com.thomsonreuters.rfa.valueadd.util.ValueAddMessageKeys;
/**
 * Core Interface for non interactive application. Adds non interactive provider specific functionality to the base class AdminCore.
 * <p> During initialization, it requests the login to source distributor.
 * <p> During un-initialization, it logs out the ProviderNonInteractiveCore.
 * <p> Also provides functionality to submit messages and outbound callback for events received from RFA.
 *     Application can extend this class and provide implementation to process various outbound events by overriding these callback methods.
 * @see AdminCore
 * @see ProviderNonInteractiveCoreConfig
 */
public class ProviderNonInteractiveCore extends AdminCore
{
    private Handle errorHandle;
    private Handle loginHandle;
    private ProviderNonInteractiveCoreConfig provNonInteractiveCoreConfig;
    private OMMItemCmd itemCmd = new OMMItemCmd();
    private TimerIntSpec timerIntSpec = new TimerIntSpec();
    private OMMPool pool;
    private ProviderNonInteractiveEventRouter niProvRouter = new ProviderNonInteractiveEventRouter();

    public ProviderNonInteractiveCore()
    {
        super();
        state.set(AdminState.CONSTRUCTED);
    }

    /**
     * Initializes ProviderNonInteractiveCore with specified ProviderNonInteractiveCore configuration.
     * @param  config - ProviderNonInteractiveCoreConfig
     */
    final public void initialize(ProviderNonInteractiveCoreConfig config)
    {
        adminLogger.info("Initializing ProviderNonInteractiveCore.");
        adminLogger.fine("ProviderNonInteractiveCoreConfig:" + config.toString());
        if (state.get() == AdminState.INITIALIZED)
            throw new ValueAddException(ValueAddMessageKeys.ALREADY_INITIALIZED.format());

        state.set(AdminState.INITIALIZED);
        provNonInteractiveCoreConfig = config;
        pool = OMMPool.create();
        super.initialize(EventSource.OMM_PROVIDER, config);
        loginHandle = requestLogin();
        errorHandle = registerError();
        adminLogger.info("ProviderNonInteractiveCore initialized.");
    }

    /**
     * Initializes ProviderNonInteractiveCore with default ProviderNonInteractiveCore configuration.
     */
    final public void initialize()
    {
        initialize(new ProviderNonInteractiveCoreConfig());
    }

    /**
     * Un-Initializes ProviderNonInteractiveCore. It can be re initialized again by calling initialize().
     * @throws ValueAddException if ProviderNonInteractiveCore is not initialized.
     */
    final public void uninitialize()
    {
        ensureInitializedState();
        adminLogger.info("Uninitializing ProviderNonInteractiveCore.");
        if (errorHandle != null)
            eventSource.unregister(errorHandle);

        errorHandle = null;

        if (loginHandle != null)
            eventSource.unregister(loginHandle);

        loginHandle = null;

        pool.destroy();
        super.uninitialize();
        state.set(AdminState.UNINITIALIZED);
        adminLogger.info("ProviderNonInteractiveCore Uninitialized.");
    }


    /**
     * 
     * @return ProviderNonInteractiveCoreConfig used by ProviderNonInteractiveCoreConfig. It can be user specified config or default configuration created during initialize() call. 
     */
    final public ProviderNonInteractiveCoreConfig getCoreConfig()
    {
        return provNonInteractiveCoreConfig;
    }

    /**
     * Registers interest for timer based events.
     * @param milliseconds millisecond delay time, in milliseconds, to wait before creating a timer Event 
     * @param isRepeating Set if this timer repeats.
     * @param useEventQueue Use event queue for timer events
     * @param closure Closure to associate to timer events.
     * @return Handle to timer event stream.
     * @see OMMProvider#registerClient(com.reuters.rfa.common.EventQueue, com.reuters.rfa.common.InterestSpec, Client, Object)
     * @see TimerIntSpec
     */
    final public Handle registerTimer(long milliseconds, boolean isRepeating, boolean useEventQueue,
            Object closure)
    {
        ensureInitializedState();
        adminLogger.fine("Registering timer.");
        timerIntSpec.setDelay(milliseconds);
        timerIntSpec.setRepeating(isRepeating);
        return eventSource.register(timerIntSpec, useEventQueue ? queue : null, niProvRouter,
                                    closure);
    }

    /**
     * 
     * @param handle to cancel timer events for.
     */
    final public void unRegisterTimer(Handle handle)
    {
        ensureInitializedState();
        adminLogger.fine("Unregistering timer.");
        eventSource.unregister(handle);
    }

    /**
     * Submit market data messages to OMMProvider event source.
     * @param token  associated with the request.
     * @param responseMsg response message.
     * @param closure an Object representing some application provided data.
     *      This is returned by the{@link OMMCmdErrorEvent}.
     * @return ID that is unique to the submit or 0 if cmd included
     * an invalid {@link com.reuters.rfa.common.Token Token} or is of an
     * unsupported type.
     * @throws ValueAddException if ProviderNonInteractiveCore is not initialized.
     * @see OMMProvider#submit(com.reuters.rfa.session.omm.OMMCmd, Object)
     */
    final public int submitMsg(Token token, OMMMsg responseMsg, Object closure)
    {
        ensureInitializedState();
        adminLogger.fine("Submitting message");
        itemCmd.setMsg(responseMsg);
        itemCmd.setToken(token);
        return eventSource.submit(itemCmd, closure);
    }

    /**
     * Create a Token for use by non-interactive provider application. 
     * @return Token for non-interactive publishing.
     * @see OMMProvider#generateToken()
     */
    final public Token getItemToken()
    {
        ensureInitializedState();
        adminLogger.fine("Generating token");
        return eventSource.generateToken();
    }

    /**
     * 
     * @return Handle to login event stream opened during initilization.
     * @throws ValueAddException if ProviderNonInteractiveCore is not initialized.
     */
    final public Handle getRDMLoginHandle()
    {
        ensureInitializedState();
        return loginHandle;
    }
    
    private Handle requestLogin()
    {
        OMMMsg loginMsg = (provNonInteractiveCoreConfig.getRDMLoginRequest() != null) ? provNonInteractiveCoreConfig.getRDMLoginRequest()
                : getDefaultLoginReq();
        OMMItemIntSpec itemIntSpec = new OMMItemIntSpec();
        itemIntSpec.setMsg(loginMsg);
        adminLogger.fine("Requesting Login");
        return eventSource.register(itemIntSpec,
                                    queue,
                                    niProvRouter, null);
    }

    private OMMMsg getDefaultLoginReq()
    {
        String username = "guest";
        try
        {
            username = System.getProperty("user.name");
        }
        catch (Exception e)
        {
        }
        String defaultPosition = "1.1.1.1/net";
        try
        {
            defaultPosition = InetAddress.getLocalHost().getHostAddress() + "/"
                    + InetAddress.getLocalHost().getHostName();
        }
        catch (Exception e)
        {
        }
        String defaultApplication = "256";

        RDMLoginRequest loginReq = new RDMLoginRequest();
        RDMLoginRequestAttrib loginAttribInfo = new RDMLoginRequestAttrib();
        loginAttribInfo.setName(username);
        loginAttribInfo.setApplicationId(defaultApplication);
        loginAttribInfo.setPosition(defaultPosition);
        loginAttribInfo.setRole(RDMLogin.Role.PROVIDER_NON_INTERACTIVE);
        loginReq.setAttrib(loginAttribInfo);

        return loginReq.getMsg(pool);
    }

    private Handle registerError()
    {
        Handle handle;
        adminLogger.fine("Registering interest for error events");
        if (provNonInteractiveCoreConfig.getCommandErrorInterest())
            handle = eventSource.register(new OMMErrorIntSpec(), queue, niProvRouter, null);
        else
            handle = null;
        return handle;
    }

    /**
     * No-op callback method for OMMCmdErrorEvents. Application can override this method to process OMMCmdErrorEvent.
     * OMMCmdErrorEvent is received if application has shown interest in command errors during ProviderNonInteractiveCore initialization.
     * @param cmdErrorEvent OMMCmdErrorEvent received.
     */
    public void processOMMCmdErrorEvent(OMMCmdErrorEvent cmdErrorEvent)
    {
        adminLogger.fine("Received OMMCmdErrorEvent:" + cmdErrorEvent);
    }

    /**
     * No-op callback method for OMMItemEvents. Application can override this method to process OMMItemEvent.
     * @param itemEvent OMMItemEvent received.
     */
    public void processOMMItemEvent(OMMItemEvent itemEvent)
    {
        adminLogger.fine("Received OMMItemEvent:" + itemEvent);
    }

    /**
     * No-op callback method for events that are not OMMItemEvent or OMMCmdErrorEvent. 
     * @param unKnownEvent Event received.
     */
    public void processUnknownEvent(Event unKnownEvent)
    {
        adminLogger.fine("Received an event:" + unKnownEvent);
    }

    private class ProviderNonInteractiveEventRouter implements Client
    {
        public void processEvent(Event event)
        {
            switch (event.getType())
            {
                case Event.OMM_CMD_ERROR_EVENT:
                    processOMMCmdErrorEvent((OMMCmdErrorEvent)event);
                    break;
                case Event.OMM_ITEM_EVENT:
                    processOMMItemEvent((OMMItemEvent)event);
                    break;
                default:
                    processUnknownEvent(event);
                    break;
            }
        }
    }
}