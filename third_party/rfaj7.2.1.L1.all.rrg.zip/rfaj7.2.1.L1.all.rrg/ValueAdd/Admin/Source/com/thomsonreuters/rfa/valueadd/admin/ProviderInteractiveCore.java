package com.thomsonreuters.rfa.valueadd.admin;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.reuters.rfa.common.Client;
import com.reuters.rfa.common.Event;
import com.reuters.rfa.common.EventSource;
import com.reuters.rfa.common.Handle;
import com.reuters.rfa.common.Token;
import com.reuters.rfa.omm.OMMMsg;
import com.reuters.rfa.session.TimerIntSpec;
import com.reuters.rfa.session.omm.OMMActiveClientSessionEvent;
import com.reuters.rfa.session.omm.OMMClientSessionIntSpec;
import com.reuters.rfa.session.omm.OMMCmdErrorEvent;
import com.reuters.rfa.session.omm.OMMErrorIntSpec;
import com.reuters.rfa.session.omm.OMMInactiveClientSessionCmd;
import com.reuters.rfa.session.omm.OMMInactiveClientSessionEvent;
import com.reuters.rfa.session.omm.OMMItemCmd;
import com.reuters.rfa.session.omm.OMMListenerEvent;
import com.reuters.rfa.session.omm.OMMListenerIntSpec;
import com.reuters.rfa.session.omm.OMMProvider;
import com.reuters.rfa.session.omm.OMMSolicitedItemEvent;
import com.thomsonreuters.rfa.valueadd.admin.internal.AdminState;
import com.thomsonreuters.rfa.valueadd.util.ValueAddException;
import com.thomsonreuters.rfa.valueadd.util.ValueAddMessageKeys;

/**
 * Core Interface for interactive application. Adds interactive provider specific functionality to the base class AdminCore.
 * <p> Provides functionality to submit messages and outbound callback for events received from RFA.
 *     Application can extend this class and provide implementation to process various outbound events by overriding these callback methods.
 * <p> Events for both listener socket and client sessions are handled by this class. 
 * @see AdminCore
 * @see ProviderInteractiveCoreConfig
 */
public class ProviderInteractiveCore extends AdminCore
{
    private ProviderInteractiveCoreConfig providerInteractiveCoreConfig;
    private Handle csListenerIntSpecHandle;
    private ClientSessionTreatment clientSessionTreatment = ClientSessionTreatment.NOTIFY;
    private Object clientSessionClosure;
    private List<Handle> clientSessions = new ArrayList<Handle>();
    private Handle errorHandle;
    private TimerIntSpec timerIntSpec = new TimerIntSpec();
    private OMMItemCmd itemCmd = new OMMItemCmd();
    private ProviderInteractiveEventRouter providerInteractiveEventRouter = new ProviderInteractiveEventRouter();

    public ProviderInteractiveCore()
    {
        state.set(AdminState.CONSTRUCTED);
    }

    /**
     * Initializes ProviderInteractiveCore with specified provider core configuration.
     * @param  config - ProviderInteractiveCoreConfig
     */
    final public void initialize(ProviderInteractiveCoreConfig config)
    {
        if (state.get() == AdminState.INITIALIZED)
            throw new ValueAddException(ValueAddMessageKeys.ALREADY_INITIALIZED.format());

        adminLogger.info("Initializing ProviderInteractiveCore.");
        adminLogger.fine("ProviderInteractiveCore config:" + config.toString());
        super.initialize(EventSource.OMM_PROVIDER, config);
        providerInteractiveCoreConfig = config;
        state.set(AdminState.INITIALIZED);
        OMMListenerIntSpec listenerIntSpec = new OMMListenerIntSpec();
        listenerIntSpec.setListenerName(((ProviderInteractiveCoreConfig)config).getListenerName());
        csListenerIntSpecHandle = eventSource.register(listenerIntSpec, queue,
                                                       providerInteractiveEventRouter, null);
        adminLogger.info("ProviderInteractiveCore initialized.");
    }

    /**
     * Initializes ProviderInteractiveCore with default provider core configuration.
     */
    final public void initialize()
    {
        initialize(new ProviderInteractiveCoreConfig());
    }

    /**
     * Closes all client sessions, listener socket and un-initializes RFA session. It can be re initialized again by calling initialize().
     * @throws ValueAddException if ProviderInteractiveCore is not initialized.
     */
    final public void uninitialize()
    {
        ensureInitializedState();
        adminLogger.info("Uninitializing ProviderInteractiveCore.");
        if (errorHandle != null)
            eventSource.unregister(errorHandle);

        Iterator<Handle> iter = clientSessions.iterator();
        while (iter.hasNext())
        {
            Handle handle = iter.next();
            iter.remove();
            eventSource.unregister(handle);
        }

        if (csListenerIntSpecHandle != null)
            eventSource.unregister(csListenerIntSpecHandle);
        super.uninitialize();
        state.set(AdminState.UNINITIALIZED);
        adminLogger.info("ProviderInteractiveCore Uninitialized.");
    }

    /**
     * 
     * @return ProviderInteractiveCoreConfig used by ProviderInteractiveCore. It can be user specified config or default configuration created during initialize() call. 
     */
    final public ProviderInteractiveCoreConfig getCoreConfig()
    {
        return providerInteractiveCoreConfig;
    }

    /**
     * Registers interest for timer based events.
     * @param milliseconds millisecond delay time, in milliseconds, to wait before creating a timer Event 
     * @param isRepeating Set if this timer repeats.
     * @param useEventQueue Use event queue for timer events
     * @param closure Closure to associate to timer events.
     * @return Handle to timer event stream.
     * @see OMMProvider#registerClient(com.reuters.rfa.common.EventQueue, com.reuters.rfa.common.InterestSpec, Client, Object)
     * @see TimerIntSpec
     */
    final public Handle registerTimer(long milliseconds, boolean isRepeating, boolean useEventQueue,
            Object closure)
    {
        ensureInitializedState();
        adminLogger.fine("Registering timer.");
        timerIntSpec.setDelay(milliseconds);
        timerIntSpec.setRepeating(isRepeating);
        return eventSource.register(timerIntSpec, useEventQueue ? queue : null,
                                    providerInteractiveEventRouter, closure);
    }

    /**
     * 
     * @param handle to cancel timer events for.
     */
    final public void unRegisterTimer(Handle handle)
    {
        ensureInitializedState();
        adminLogger.fine("Unregistering timer.");
        if (handle != null)
            eventSource.unregister(handle);
    }

    /**
     * Method used by the provider application to accept a client session that it is notified for.
     * @param clientSessionHandle Handle to client session being accepted by the provider.
     * @param closure an Object representing application provided data
     * @return Client Session handle that is just accepted
     * @throws ValueAddException if ProviderInteractiveCore is not initialized or client session treatment policy is set to ACCEPT or REJECT.
     */
    final public Handle acceptClientSession(Handle clientSessionHandle, Object closure)
    {
        ensureInitializedState();
        if (clientSessionTreatment == ClientSessionTreatment.ACCEPT
                || clientSessionTreatment == ClientSessionTreatment.REJECT)
            throw new ValueAddException("Client Session is handled by the admin module");
        return acceptClientSessionInternal(clientSessionHandle, closure);
    }

    private Handle acceptClientSessionInternal(Handle clientSessionHandle, Object closure)
    {
        adminLogger.fine("Accepting client session:" + clientSessionHandle);
        OMMClientSessionIntSpec intSpec = new OMMClientSessionIntSpec();
        intSpec.setClientSessionHandle(clientSessionHandle);
        Handle handle = eventSource.register(intSpec, queue, providerInteractiveEventRouter, closure);
        registerError();
        return handle;
    }

    /**
     * Method used by the provider application to reject a client session that it is notified for.
     * @param clientSessionHandle Handle to client session being rejected by the provider.
     * @param closure an Object representing application provided data
     * @return non-zero is reject is successful or 0 otherwise.
     * @throws ValueAddException if ProviderInteractiveCore is not initialized or client session treatment policy is set to ACCEPT or REJECT.
     */
    final public int rejectClientSession(Handle clientSessionHandle, Object closure)
    {
        ensureInitializedState();

        if (clientSessionTreatment == ClientSessionTreatment.ACCEPT
                || clientSessionTreatment == ClientSessionTreatment.REJECT)
            throw new ValueAddException("Client Session is handled by the admin module");

        return rejectClientSessionInternal(clientSessionHandle, closure);
    }

    private int rejectClientSessionInternal(Handle clientSessionHandle, Object closure)
    {
        adminLogger.fine("Rejecting client session:" + clientSessionHandle);
        OMMInactiveClientSessionCmd inactivecmd = new OMMInactiveClientSessionCmd();
        inactivecmd.setClientSessionHandle(clientSessionHandle);

        return eventSource.submit(inactivecmd, closure);
    }

    /**
     * Submit market data messages to OMMProvider event source.
     * @param token  associated with the request.
     * @param responseMsg response message.
     * @param closure an Object representing some application provided data.
     *      This is returned by the{@link OMMCmdErrorEvent}.
     * @return ID that is unique to the submit or 0 if cmd included
     * an invalid {@link com.reuters.rfa.common.Token Token} or is of an
     * unsupported type.
     * @throws ValueAddException if ProviderInteractiveCore is not initialized.
     * @see OMMProvider#submit(com.reuters.rfa.session.omm.OMMCmd, Object)
     */
    final public int submitMsg(Token token, OMMMsg responseMsg, Object closure)
    {
        ensureInitializedState();
        adminLogger.fine("Submitting message");
        itemCmd.setMsg(responseMsg);
        itemCmd.setToken(token);
        return eventSource.submit(itemCmd, closure);
    }

    /**
     * Force disconnect a client session.
     * @param clientSessionHandle
     */
    final public void closeClientSession(Handle clientSessionHandle)
    {
        ensureInitializedState();

        adminLogger.fine("Closing client session:" + clientSessionHandle);
        if(clientSessions != null && clientSessions.contains(clientSessionHandle))
            clientSessions.remove(clientSessionHandle);
        
        eventSource.unregister(clientSessionHandle);
    }

    private void processInActiveClientSessionEvent(OMMInactiveClientSessionEvent inActiveCSEvent)
    {
        adminLogger.fine("ClientSession from " + inActiveCSEvent.getClientIPAddress() + "/"
                + inActiveCSEvent.getClientHostName() + "/" + inActiveCSEvent.getListenerName()
                + " has become inactive.");
        if (clientSessionTreatment == ClientSessionTreatment.NOTIFY)
        {
            processOMMInActiveClientSessionEvent(inActiveCSEvent);
        }
        else
        {
            // since admin module is responsible for maintaining client
            // sessions, remove/close client session
            adminLogger.fine("Is client session handle active? "
                    + inActiveCSEvent.getHandle().isActive());

            // if this is for closing of client session, remove the handle
            if (hasClientSession(inActiveCSEvent.getHandle()))
            {
                clientSessions.remove(inActiveCSEvent.getHandle());
            }
        }

    }

    private void processActiveClientSessionEvent(OMMActiveClientSessionEvent activeCSEvent)
    {
        adminLogger.fine("Receive OMMActiveClientSessionEvent from client position : "
                + activeCSEvent.getClientIPAddress() + "/" + activeCSEvent.getClientHostName()
                + "/" + activeCSEvent.getListenerName());
        if (clientSessionTreatment == ClientSessionTreatment.ACCEPT)
        {
            Handle csHandle = acceptClientSessionInternal(activeCSEvent.getClientSessionHandle(),
                                                          clientSessionClosure);
            clientSessions.add(csHandle);
        }
        else if (clientSessionTreatment == ClientSessionTreatment.REJECT)
        {
            rejectClientSessionInternal(activeCSEvent.getClientSessionHandle(),
                                        clientSessionClosure);
        }
        else
        {
            adminLogger.fine("Notifying application about active client session event");
            processOMMActiveClientSessionEvent(activeCSEvent);
        }
    }

    private boolean hasClientSession(Handle handle)
    {
        return clientSessions.contains(handle);
    }

    private void registerError()
    {
        if (providerInteractiveCoreConfig.getCommandErrorInterest())
        {
            adminLogger.fine("Registering interest for error events");
            errorHandle = eventSource
                    .register(new OMMErrorIntSpec(), queue, providerInteractiveEventRouter, null);
        }
    }

    /**
     * Method to specify if all new active client sessions should be
     * automatically rejected, accepted by ProviderInteractiveCore or ProviderInteractiveCore
     * will notify the application (which is the default)
     * @param clientSessionTreatment
     * @param closure an Object representing some application provided data.
     *      This is returned by the{@link OMMCmdErrorEvent}.
     */
    final public void setClientSessionTreatment(ClientSessionTreatment clientSessionTreatment, Object closure)
    {
        this.clientSessionTreatment = clientSessionTreatment;
        this.clientSessionClosure = closure;
        adminLogger.info("Client session treatment set to: " + clientSessionTreatment);
    }
    
    /**
     * 
     * @return ClientSessionTreatment
     */
    final public ClientSessionTreatment getClientSessionTreatment()
    {
        return clientSessionTreatment;
    }

    /**
     * No-op callback method for OMMCmdErrorEvents. Application can override this method to process OMMCmdErrorEvent.
     * OMMCmdErrorEvent is received if application has shown interest in command errors during ProviderInteractiveCore initialization.
     * @param cmdErrorEvent OMMCmdErrorEvent received.
     */
    public void processOMMCmdErrorEvent(OMMCmdErrorEvent cmdErrorEvent)
    {
        adminLogger.fine("Received OMMCmdErrorEvent:" + cmdErrorEvent);
    }

    /**
     * No-op callback method for OMMListenerEvent. Application can override this method to process OMMListenerEvent.
     * OMMListenerEvent is received during initialization of ProviderInteractiveCore.
     * @param listenerEvent OMMListenerEvent received.
     */
    public void processOMMListenerEvent(OMMListenerEvent listenerEvent)
    {
        adminLogger.fine("Received OMMListenerEvent:" + listenerEvent);
    }

    /**
     * No-op callback method for OMMActiveClientSessionEvent. Application can override this method to process OMMActiveClientSessionEvent.
     * OMMActiveClientSessionEvent is received when a new client session is trying to connect. Application is notified for this event only when
     * ClientSessionTreatment is set to NOTIFY.
     * @param activeClientSessionEvent OMMActiveClientSessionEvent received.
     */
    public void processOMMActiveClientSessionEvent(
            OMMActiveClientSessionEvent activeClientSessionEvent)
    {
        adminLogger.fine("Received OMMActiveClientSessionEvent:" + activeClientSessionEvent);
    }

    /**
     * No-op callback method for OMMInactiveClientSessionEvent. Application can override this method to process OMMInactiveClientSessionEvent.     
     * OMMInactiveClientSessionEvent is received when a new client session disconnects. 
     * Application is notified for this event only when ClientSessionTreatment is set to NOTIFY.
     * @param inActiveClientSessionEvent OMMInactiveClientSessionEvent received.
     */
    public void processOMMInActiveClientSessionEvent(
            OMMInactiveClientSessionEvent inActiveClientSessionEvent)
    {
        adminLogger.fine("Received OMMInactiveClientSessionEvent:" + inActiveClientSessionEvent);
    }

    /**
     * No-op callback method for OMMSolicitedItemEvent. Application can override this method to process OMMSolicitedItemEvent
     * OMMSolicitedItemEvent is received when a client session sends a solicited item request. 
     * @param itemEvent OMMSolicitedItemEvent received.
     */
    public void processOMMSolicitedItemEvent(OMMSolicitedItemEvent itemEvent)
    {
        adminLogger.fine("Received OMMSolicitedItemEvent:" + itemEvent);
    }

    /**
     * No-op callback method for unknown events. This could be completion events from provider event source.
     * @param unKnownEvent Event received.
     */
    public void processUnknownEvent(Event unKnownEvent)
    {
        adminLogger.fine("Received an event:" + unKnownEvent);
    }

    private class ProviderInteractiveEventRouter implements Client
    {
        public void processEvent(Event event)
        {
            switch (event.getType())
            {
                case Event.OMM_CMD_ERROR_EVENT:
                    processOMMCmdErrorEvent((OMMCmdErrorEvent)event);
                    break;
                case Event.OMM_ACTIVE_CLIENT_SESSION_PUB_EVENT:
                    processActiveClientSessionEvent((OMMActiveClientSessionEvent)event);
                    break;
                case Event.OMM_INACTIVE_CLIENT_SESSION_PUB_EVENT:
                    processInActiveClientSessionEvent((OMMInactiveClientSessionEvent)event);
                    break;
                case Event.OMM_LISTENER_EVENT:
                    processOMMListenerEvent((OMMListenerEvent)event);
                    break;
                case Event.OMM_SOLICITED_ITEM_EVENT:
                    processOMMSolicitedItemEvent((OMMSolicitedItemEvent)event);
                    break;
                default:
                    processUnknownEvent(event);
                    break;
            }
        }
    }
}