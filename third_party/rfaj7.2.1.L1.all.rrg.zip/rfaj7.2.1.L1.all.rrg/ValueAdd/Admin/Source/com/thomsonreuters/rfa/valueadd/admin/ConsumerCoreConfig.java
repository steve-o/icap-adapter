package com.thomsonreuters.rfa.valueadd.admin;

import com.reuters.rfa.omm.OMMMsg;
import com.reuters.rfa.omm.OMMPool;

/**
 * Configuration for consumer core. Adds consumer core specific configuration to base class - CoreConfig.
 * @see CoreConfig
 */
public class ConsumerCoreConfig extends CoreConfig
{
    private OMMMsg rdmLoginRequest;
    private OMMMsg rdmDirRequest;
    private OMMMsg rdmFieldDictRequest;
    private OMMMsg enumDefRequest;
    private OMMPool pool;
    private boolean downloadDictionary;
    
    /**
     * Initializes ConsumerCoreConfig with default values.
     */
    public ConsumerCoreConfig()
    {
        pool = OMMPool.create();
        setSessionName("RSSLNameSpace::Consumer");
        setCoreName("Consumer");
        downloadDictionary = true;
    }

    /**
     * 
     * @return Login request message used by ConsumerCore. If ConsumerCore uses default login request, this method returns null.
     */
    public OMMMsg getRDMLoginRequest()
    {
        return rdmLoginRequest;
    }
    
    /**
     * Sets Login request message to be used by ConsumerCore.
     * @param encodedLoginRequestMsg 
     */
    public void setRDMLoginRequest(OMMMsg encodedLoginRequestMsg)
    {
        this.rdmLoginRequest = pool.acquireCopy(encodedLoginRequestMsg, false);
    }

    /**
     * 
     * @return Directory request message used by ConsumerCore. If ConsumerCore uses default directory request, this method returns null.
     */
    public OMMMsg getRDMDirectoryRequest()
    {
        return rdmDirRequest;
    }

    /**
     * Sets Directory request message to be used by ConsumerCore.
     * @param encodedDirRequestMsg 
     */
    public void setRDMDirectoryRequest(OMMMsg encodedDirRequestMsg)
    {
        this.rdmDirRequest = pool.acquireCopy(encodedDirRequestMsg, false);
    }

    /**
     * 
     * @return Field Dictionary request message used by ConsumerCore. If ConsumerCore uses default field dictionary request, this method returns null.
     */
    public OMMMsg getRDMFieldDictionaryRequest()
    {
        return rdmFieldDictRequest;
    }
    

    /**
     * Sets Field Dictionary request message to be used by ConsumerCore.
     * @param encodedDictRequestMsg 
     */
    public void setRDMFieldDictionaryRequest(OMMMsg encodedDictRequestMsg)
    {
        this.rdmFieldDictRequest = pool.acquireCopy(encodedDictRequestMsg, false);
    }

    /**
     * Sets EnumDef Dictionary request message to be used by ConsumerCore.
     * @param encodedDictRequestMsg 
     */
    public void setEnumDefDictionaryRequest(OMMMsg encodedDictRequestMsg)
    {
        enumDefRequest = pool.acquireCopy(encodedDictRequestMsg, false);
    }

    /**
     * 
     * @return EnumDef Dictionary request message used by ConsumerCore. If ConsumerCore uses default EnumDef dictionary request, this method returns null.
     */
    public OMMMsg getEnumDefDictionaryRequest()
    {
        return enumDefRequest;
    }

    /**
     * 
     * @return Indication if dictionaries are downloaded by ConsumerCore.
     */
    public boolean getDownloadDictionary()
    {
        return downloadDictionary;
    }


    /**
     * 
     * @param dictionaryDownload - Flag to ConsumerCore to indicate whether to download dictionaries or not. 
     */
    public void setDownloadDictionary(boolean dictionaryDownload)
    {
        this.downloadDictionary = dictionaryDownload;
    }

    /**
     * Clears all configuration values set by the user and sets them to default values.
     */
    public void clear()
    {
        super.clear();
        setSessionName("RSSLNameSpace::Consumer");
        setCoreName("Consumer");
        if (rdmLoginRequest != null)
            pool.releaseMsg(rdmLoginRequest);
        rdmLoginRequest = null;
        if (rdmDirRequest != null)
            pool.releaseMsg(rdmDirRequest);
        rdmDirRequest = null;
        if (rdmFieldDictRequest != null)
            pool.releaseMsg(rdmFieldDictRequest);
        rdmFieldDictRequest = null;
        if (enumDefRequest != null)
            pool.releaseMsg(enumDefRequest);
        enumDefRequest = null;
        downloadDictionary = true;
    }

    public String toString()
    {
        StringBuilder buffer = new StringBuilder(super.toString());
        buffer.append(", Login Request set by user? " + rdmLoginRequest != null);
        buffer.append(", Directory Request set by user? " + rdmDirRequest != null);
        buffer.append(", Enum Dictionary Request set by user? " + enumDefRequest != null);
        buffer.append(", Field Dictionary Request set by user? " + rdmFieldDictRequest != null);
        buffer.append(", Downloading dictionary? " + downloadDictionary);

        return buffer.toString();
    }
}