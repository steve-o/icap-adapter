package com.thomsonreuters.rfa.valueadd.admin;

import java.net.InetAddress;
import java.util.EnumSet;
import java.util.List;

import com.reuters.rfa.common.Client;
import com.reuters.rfa.common.Event;
import com.reuters.rfa.common.EventSource;
import com.reuters.rfa.common.Handle;
import com.reuters.rfa.omm.OMMMsg;
import com.reuters.rfa.omm.OMMPool;
import com.reuters.rfa.omm.OMMTypes;
import com.reuters.rfa.rdm.RDMMsgTypes;
import com.reuters.rfa.session.TimerIntSpec;
import com.reuters.rfa.session.omm.OMMCmdErrorEvent;
import com.reuters.rfa.session.omm.OMMConsumer;
import com.reuters.rfa.session.omm.OMMErrorIntSpec;
import com.reuters.rfa.session.omm.OMMHandleItemCmd;
import com.reuters.rfa.session.omm.OMMItemEvent;
import com.reuters.rfa.session.omm.OMMItemIntSpec;
import com.thomsonreuters.rfa.valueadd.admin.internal.AdminState;
import com.thomsonreuters.rfa.valueadd.domainrep.rdm.dictionary.RDMDictionaryRequest;
import com.thomsonreuters.rfa.valueadd.domainrep.rdm.dictionary.RDMDictionaryRequestAttrib;
import com.thomsonreuters.rfa.valueadd.domainrep.rdm.dictionary.RDMDictionaryResponseAttrib;
import com.thomsonreuters.rfa.valueadd.domainrep.rdm.dictionary.RDMDictionary;
import com.thomsonreuters.rfa.valueadd.domainrep.rdm.directory.RDMDirectory;
import com.thomsonreuters.rfa.valueadd.domainrep.rdm.directory.RDMDirectoryRequest;
import com.thomsonreuters.rfa.valueadd.domainrep.rdm.directory.RDMDirectoryRequestAttrib;
import com.thomsonreuters.rfa.valueadd.domainrep.rdm.directory.RDMDirectoryResponse;
import com.thomsonreuters.rfa.valueadd.domainrep.rdm.directory.RDMDirectoryResponsePayload;
import com.thomsonreuters.rfa.valueadd.domainrep.rdm.directory.Service;
import com.thomsonreuters.rfa.valueadd.domainrep.rdm.login.RDMLoginRequest;
import com.thomsonreuters.rfa.valueadd.domainrep.rdm.login.RDMLoginRequestAttrib;
import com.thomsonreuters.rfa.valueadd.domainrep.rdm.login.RDMLogin;
import com.thomsonreuters.rfa.valueadd.util.ValueAddException;
import com.thomsonreuters.rfa.valueadd.util.ValueAddMessageKeys;

/**
 * Core Interface for consumer application. Adds OMM consumer specific functionality to the base class AdminCore.
 * <p> During initialization, it handles administrative domain messages by requesting login, directory and optionally dictionaries from the provider.
 * <p> It unregisters interests for these administrative domain messages during un-initialization.
 * <p> Also provides functionality to register an item interest and outbound callback for events received from RFA.
 *     Application can extend this class and provide implementation to process various outbound events by overriding these callback methods.
 * @see AdminCore
 * @see ConsumerCoreConfig
 */
public class ConsumerCore extends AdminCore
{
    private Handle errorHandle;
    private ConsumerCoreConfig consumerCoreConfig;
    private TimerIntSpec timerIntSpec = new TimerIntSpec();
    private ConsumerCoreEventRouter csEventRouter = new ConsumerCoreEventRouter();
    private OMMItemIntSpec itemIntSpec = new OMMItemIntSpec();
    private OMMPool pool;
    private Handle loginHandle;
    private Handle dirHandle;
    private Integer fullDict = 0;
    private static byte RDM_COMPLETE = 0x01; // Received complete RDM field from
    private static byte ENUM_COMPLETE = 0x10; // Received complete Enumtable
    private static String RWFFldDictName = "RWFFld";
    private static String RWFEnumDictName = "RWFEnum";
    private Handle enumDefHandle = null;
    private Handle fldDefHandle = null;

    private boolean dictionaryDownloadFlag = true;

   
    public ConsumerCore()
    {
        super();
        state.set(AdminState.CONSTRUCTED);
    }

    /**
     * Initializes ConsumerCore with specified consumer core configuration.
     * @param  config - ConsumerCoreConfig
     */
    final public void initialize(ConsumerCoreConfig config)
    {
        adminLogger.info("Initializing ConsumerCore.");
        adminLogger.fine("ConsumerCore config:" + config.toString());
        if (state.get() == AdminState.INITIALIZED)
            throw new ValueAddException(ValueAddMessageKeys.ALREADY_INITIALIZED.format());

        state.set(AdminState.INITIALIZED);
        this.consumerCoreConfig = config;
        pool = OMMPool.create();
        super.initialize(EventSource.OMM_CONSUMER, config);
        if (!consumerCoreConfig.getDownloadDictionary())
        {
            adminLogger.info("Download dictionary is configured: false");
        }

        dictionaryDownloadFlag = consumerCoreConfig.getDownloadDictionary();

        requestLogin();
        requestDirectory();
        initDownloadDictionaryRequests(consumerCoreConfig);
        adminLogger.info("ConsumerCore initialized.");
    }

    /**
     * Initializes ConsumerCore with default consumer core configuration.
     */
    final public void initialize()
    {
        initialize(new ConsumerCoreConfig());
    }

    /**
     * Un-Initializes ConsumerCore. It can be re initialized again by calling initialize().
     * @throws ValueAddException if ConsumerCore is not initialized.
     */
    final public void uninitialize()
    {
        adminLogger.info("Uninitializing ConsumerCore.");
        ensureInitializedState();

        if (errorHandle != null)
            closeRequest(errorHandle);
        if (dirHandle != null)
            closeRequest(dirHandle);
        if (loginHandle != null)
            closeRequest(loginHandle);
        dirHandle = null;
        errorHandle = null;
        loginHandle = null;
        pool.destroy();

        super.uninitialize();
        state.set(AdminState.UNINITIALIZED);
        adminLogger.info("ConsumerCore uninitialized.");
    }

    /**
     * 
     * @return ConsumerCoreConfig used by ConsumerCore. It can be user specified config or default configuration created during initialize() call. 
     */
    final public ConsumerCoreConfig getCoreConfig()
    {
        return consumerCoreConfig;
    }

    /**
     * Opens an event stream on OMM consumer event source with specified request message.
     * @param requestMsg - Request message to send to OMM consumer event source.
     * @param useEventQueue - Specifies whether to use event queue for response events.
     * @param closure - Closure
     * @return Handle for opened stream.
     * @see OMMConsumer#registerClient(com.reuters.rfa.common.EventQueue, com.reuters.rfa.common.InterestSpec, Client, Object)
     */
    final public Handle openRequest(OMMMsg requestMsg, boolean useEventQueue, Object closure)
    {
        ensureInitializedState();
        itemIntSpec.setMsg(requestMsg);
        adminLogger.fine("Opening request.");
        return eventSource.register(itemIntSpec, useEventQueue ? queue : null, csEventRouter,
                                    closure);
    }

    /**
     * Modifies existing event stream with new request.
     * @param handle of event stream to modify request for.
     * @param modificationRequestMsg Request message with modification attributes.
     * @see OMMConsumer#reissueClient(Handle, com.reuters.rfa.common.InterestSpec)
     */
    final public void modifyRequest(Handle handle, OMMMsg modificationRequestMsg)
    {
        ensureInitializedState();
        OMMItemIntSpec ommItemIntSpec = new OMMItemIntSpec();
        ommItemIntSpec.setMsg(modificationRequestMsg);
        adminLogger.fine("Modifying request.");
        eventSource.reissue(handle, ommItemIntSpec);
    }

    /**
     * Modifies existing event streams for the list of handles. 
     * @param handles List of handles to existing event streams.
     * @param modificationRequestMsg Request message with modification attributes.
     * @see OMMConsumer#reissueClient(Handle, com.reuters.rfa.common.InterestSpec)
     */
    final public void modifyRequest(List<Handle> handles, OMMMsg modificationRequestMsg)
    {
        ensureInitializedState();
        for (Handle handle : handles)
        {
            modifyRequest(handle, modificationRequestMsg);
        }
    }

    /**
     * Closes an event stream associated with specified handle.
     * @param handle to event stream to close.
     * @see OMMConsumer#unregisterClient(Handle)
     */
    final public void closeRequest(Handle handle)
    {
        ensureInitializedState();
        adminLogger.fine("Closing request.");
        eventSource.unregister(handle);
    }

    /**
     * Closes existing event streams associated with the list of handles.
     * @param handles to event streams to close.
     * @see OMMConsumer#unregisterClient(Handle)
     */
    final public void closeRequest(List<Handle> handles)
    {
        ensureInitializedState();
        for (Handle handle : handles)
        {
            closeRequest(handle);
        }
    }

    /**
     * Registers interest for timer based events
     * @param milliseconds millisecond delay time, in milliseconds, to wait before creating a timer Event 
     * @param isRepeating Set if this timer repeats.
     * @param useEventQueue Use event queue for timer events
     * @param closure Closure to associate to timer events.
     * @return Handle to timer event stream.
     * @see OMMConsumer#registerClient(com.reuters.rfa.common.EventQueue, com.reuters.rfa.common.InterestSpec, Client, Object)
     * @see TimerIntSpec
     */
    final public Handle registerTimer(long milliseconds, boolean isRepeating,
            boolean useEventQueue, Object closure)
    {
        ensureInitializedState();
        adminLogger.fine("Registering for timer events");
        timerIntSpec.setDelay(milliseconds);
        timerIntSpec.setRepeating(isRepeating);
        return eventSource.register(timerIntSpec, useEventQueue ? queue : null, csEventRouter,
                                    closure);
    }

    /**
     * 
     * @param handle to cancel timer events for.
     */
    final public void unRegisterTimer(Handle handle)
    {
        ensureInitializedState();
        adminLogger.fine("Unregistering timer events");
        if (handle != null)
            closeRequest(handle);
    }

    /**
     * Sends generic or post message on existing event stream.
     * @param handle Identifies event stream to send message to.
     * @param msg Generic or Post message to send
     * @param closure an Object representing some application provided data
     * @return ID that is unique to the submit or 0 if cmd included
     * an invalid {@link com.reuters.rfa.common.Handle Handle} or is of an
     * unsupported type.
     * @see OMMConsumer#submit(com.reuters.rfa.session.omm.OMMCmd, Object)
     */
    final public int submitMsg(Handle handle, OMMMsg msg, Object closure)
    {
        ensureInitializedState();

        if (msg.getMsgType() != OMMMsg.MsgType.POST && msg.getMsgType() != OMMMsg.MsgType.GENERIC)
        {
            throw new ValueAddException(
                    ValueAddMessageKeys.ONLY_GENERIC_OR_POST_ALLOWED.format(OMMMsg.MsgType
                            .toString(msg.getMsgType())));
        }

        adminLogger.fine("Submitting OMMMSg");
        OMMHandleItemCmd itemCmd = new OMMHandleItemCmd();
        itemCmd.setHandle(handle);
        itemCmd.setMsg(msg);
        return eventSource.submit(itemCmd, closure);
    }

    /**
     * 
     * @return Handle to login event stream opened during initilization.
     * @throws ValueAddException if ConsumerCore is not initialized.
     */
    final public Handle getRDMLoginHandle()
    {
        ensureInitializedState();
        return loginHandle;
    }

    /**
     * 
     * @return Handle to directory event stream opened during initilization.
     * @throws ValueAddException if ConsumerCore is not initialized.
     */
    final public Handle getRDMDirectoryHandle()
    {
        ensureInitializedState();
        return dirHandle;
    }

    /**
     * No-op callback method for OMMItemEvents. Application can override this method to process OMMItemEvent.
     * @param itemEvent OMMItemEvent received.
     */
    public void processOMMItemEvent(OMMItemEvent itemEvent)
    {
        adminLogger.fine("Received OMMItemEvent:" + itemEvent);
    }

    /**
     * No-op callback method for OMMCmdErrorEvents. Application can override this method to process OMMCmdErrorEvent.
     * OMMCmdErrorEvent is received if application has shown interest in command errors during ConsumerCore initialization.
     * @param cmdErrorEvent OMMCmdErrorEvent received.
     */
    public void processOMMCmdErrorEvent(OMMCmdErrorEvent cmdErrorEvent)
    {
        adminLogger.fine("Received OMMCmdErrorEvent:" + cmdErrorEvent);
    }

    /**
     * No-op callback method for events that are not OMMItemEvent or OMMCmdErrorEvent. 
     * @param unKnownEvent Event received.
     */
    public void processUnknownEvent(Event unKnownEvent)
    {
        adminLogger.fine("Received an event:" + unKnownEvent);
    }

    private boolean dictionariesDownloaded()
    {
        return (fullDict == (RDM_COMPLETE | ENUM_COMPLETE));
    }

    private void registerError()
    {
        if (consumerCoreConfig.getCommandErrorInterest())
        {
            adminLogger.info("Registering for error events");
            errorHandle = eventSource.register(new OMMErrorIntSpec(), queue, csEventRouter, null);
        }
    }

    private void requestLogin()
    {
        OMMMsg encodedLoginMsg = null;
        if (consumerCoreConfig.getRDMLoginRequest() != null)
        {
            adminLogger
                    .info("Requesting login using user defined login request in the configuration");
            itemIntSpec.setMsg(consumerCoreConfig.getRDMLoginRequest());
        }
        else
        {
            adminLogger.info("Requesting login using default login request");
            encodedLoginMsg = encodeLoginRequest();
            itemIntSpec.setMsg(encodedLoginMsg);
        }
        loginHandle = eventSource.register(itemIntSpec, queue, csEventRouter, null);
        if (encodedLoginMsg != null)
            pool.releaseMsg(encodedLoginMsg);
        registerError();
    }

    private OMMMsg encodeLoginRequest()
    {
        String username = "guest";
        try
        {
            username = System.getProperty("user.name");
        }
        catch (Exception e)
        {
        }
        String defaultPosition = "1.1.1.1/net";
        try
        {
            defaultPosition = InetAddress.getLocalHost().getHostAddress() + "/"
                    + InetAddress.getLocalHost().getHostName();
        }
        catch (Exception e)
        {
        }
        String defaultApplication = "256";

        RDMLoginRequest loginReq = new RDMLoginRequest();
        RDMLoginRequestAttrib loginAttribInfo = new RDMLoginRequestAttrib();
        loginReq.setMessageType(RDMLoginRequest.MessageType.REQUEST);
        loginReq.setIndicationMask(EnumSet.of(RDMLoginRequest.IndicationMask.REFRESH));
        loginAttribInfo.setName(username);
        loginAttribInfo.setApplicationId(defaultApplication);
        loginAttribInfo.setPosition(defaultPosition);
        loginAttribInfo.setRole(RDMLogin.Role.CONSUMER);
        loginReq.setAttrib(loginAttribInfo);

        return loginReq.getMsg(pool);
    }

    private void requestDirectory()
    {
        OMMMsg encodedDirReqMsg = null;
        if (consumerCoreConfig.getRDMDirectoryRequest() != null)
        {
            adminLogger
                    .info("Requesting directory using user defined directory request in the configuration");
            itemIntSpec.setMsg(consumerCoreConfig.getRDMDirectoryRequest());
        }
        else
        {
            adminLogger.info("Requesting all directories with all filters");
            encodedDirReqMsg = encodeDirectoryRequest();
            itemIntSpec.setMsg(encodedDirReqMsg);
        }

        dirHandle = eventSource.register(itemIntSpec, queue, csEventRouter, null);
        if (encodedDirReqMsg != null)
            pool.releaseMsg(encodedDirReqMsg);
    }

    private Handle requestDictionary(OMMMsg dictReq)
    {
        OMMItemIntSpec itemIntSpec = new OMMItemIntSpec();
        itemIntSpec.setMsg(dictReq);
        return eventSource.register(itemIntSpec, queue, csEventRouter, null);
    }

    private OMMMsg encodeDirectoryRequest()
    {
        RDMDirectoryRequest dirReq = new RDMDirectoryRequest();
        dirReq.setMessageType(RDMDirectoryRequest.MessageType.REQUEST);
        dirReq.setIndicationMask(EnumSet.of(RDMDirectoryRequest.IndicationMask.REFRESH));
        RDMDirectoryRequestAttrib dirReqAI = new RDMDirectoryRequestAttrib(
                EnumSet.allOf(RDMDirectory.FilterMask.class));
        dirReq.setAttrib(dirReqAI);

        return dirReq.getMsg(pool);
    }

    private void initDownloadDictionaryRequests(ConsumerCoreConfig consumerCoreConfig)
    {
        if (!dictionaryDownloadFlag)
            return;

        OMMMsg enumDefRequest = consumerCoreConfig.getEnumDefDictionaryRequest();
        OMMMsg fldDefRequest = consumerCoreConfig.getRDMFieldDictionaryRequest();

        if (enumDefRequest != null)
        {
            adminLogger
                    .info("Requesting enum dictionary using user defined enum dictionary request");
            fldDefHandle = requestDictionary(enumDefRequest);
        }

        if (fldDefRequest != null)
        {
            adminLogger
                    .info("Requesting field dictionary using user defined enum dictionary request");
            enumDefHandle = requestDictionary(fldDefRequest);
        }
    }

    private void processDirectoryResponseInt(OMMItemEvent itemEvent)
    {
        if (!dictionaryDownloadFlag)
            return;

        if (dictionariesDownloaded())
            return;

        if (enumDefHandle != null && fldDefHandle != null)
            return;

        OMMMsg respMsg = itemEvent.getMsg();
        if (respMsg.getMsgModelType() != RDMMsgTypes.DIRECTORY)
            return;

        RDMDirectoryResponse dirResp = new RDMDirectoryResponse(respMsg);
        if (!dirResp.hasPayload())
            return;
       

        RDMDirectoryResponsePayload payload = dirResp.getPayload();
        if (!payload.hasServiceList())
            return;
        
        String serviceToDownloadDict = null;
        for (Service service : payload.getServiceList())
        {
            if (!service.hasStateFilter())
                continue;
            Service.StateFilter state = service.getStateFilter();
            
            //Need to check for service up
            //There might be more than one services from ADS/Provider and requesting a dictionary
            //from a service that might be down forever will cause failure to download dictionaries.
            //RFA Java queues the requests including dictionary requests to a service that is not up.
            //In future, when RFA Java forwards the dictionary requests to ADS regardless of service state,
            //this check is not required.
            if (state.hasServiceUp() && state.getServiceUp() && state.getAcceptingRequests())
                serviceToDownloadDict = service.getServiceName();
            else
                adminLogger.info("Service: '" + service.getServiceName()
                        + "' is not accepting requests, dictionaries will not be requested from this service.");
        }

        if (serviceToDownloadDict == null)
            return;

        if (fldDefHandle == null)
        {
            adminLogger.info("Requesting '" + RWFFldDictName + "' from: " + serviceToDownloadDict);
            OMMMsg fldDictReqMsg = encodeDictReq(RWFFldDictName, serviceToDownloadDict);
            requestDictionary(fldDictReqMsg);
            pool.releaseMsg(fldDictReqMsg);
        }
        if (enumDefHandle == null)
        {
            adminLogger.info("Requesting '" + RWFEnumDictName + "' from: " + serviceToDownloadDict);
            OMMMsg enumDictReqMsg = encodeDictReq(RWFEnumDictName, serviceToDownloadDict);
            requestDictionary(enumDictReqMsg);
            pool.releaseMsg(enumDictReqMsg);
        }
    }

    private OMMMsg encodeDictReq(String dictionaryName, String serviceName)
    {
        RDMDictionaryRequest dictReq = new RDMDictionaryRequest();
        RDMDictionaryRequestAttrib dictAttribInfo = new RDMDictionaryRequestAttrib();
        dictReq.setMessageType(RDMDictionaryRequest.MessageType.REQUEST);
        dictReq.setIndicationMask(EnumSet.of(RDMDictionaryRequest.IndicationMask.REFRESH,
                                             RDMDictionaryRequest.IndicationMask.NONSTREAMING));
        dictAttribInfo.setVerbosity(RDMDictionary.Verbosity.NORMAL);
        dictAttribInfo.setDictionaryName(dictionaryName);
        dictAttribInfo.setServiceName(serviceName);
        dictReq.setAttrib(dictAttribInfo);

        return dictReq.getMsg(pool);
    }

    private void processDictionaryResponseInt(OMMItemEvent itemEvent)
    {
        OMMMsg respMsg = itemEvent.getMsg();
        if (respMsg.getMsgModelType() == RDMMsgTypes.DICTIONARY
                && respMsg.has(OMMTypes.ATTRIB_INFO)
                && respMsg.isSet(OMMMsg.Indication.REFRESH_COMPLETE))
        {
            RDMDictionaryResponseAttrib attribInfo = new RDMDictionaryResponseAttrib(
                    respMsg.getAttribInfo());
            if (RWFFldDictName.equals(attribInfo.getDictionaryName()))
            {
                adminLogger.info("Dictionary: '" + RWFFldDictName + "' received.");
                fullDict |= RDM_COMPLETE;
            }
            else if (RWFEnumDictName.equals(attribInfo.getDictionaryName()))
            {
                adminLogger.info("Dictionary: '" + RWFEnumDictName + "' received.");
                fullDict |= ENUM_COMPLETE;
            }
            if (dictionariesDownloaded())
                adminLogger.info("Both RWFFld and RWFEnum dictionaries received.");
        }
    }

    private class ConsumerCoreEventRouter implements Client
    {
        public void processEvent(Event event)
        {
            switch (event.getType())
            {
                case Event.OMM_CMD_ERROR_EVENT:
                    processOMMCmdErrorEvent((OMMCmdErrorEvent)event);
                    break;
                case Event.OMM_ITEM_EVENT:
                    processOMMItemEventInt((OMMItemEvent)event);
                    processOMMItemEvent((OMMItemEvent)event);
                    break;
                default:
                    processUnknownEvent(event);
                    break;
            }
        }

        public void processOMMItemEventInt(OMMItemEvent itemEvent)
        {
            OMMMsg respMsg = itemEvent.getMsg();
            switch (respMsg.getMsgModelType())
            {
                case RDMMsgTypes.DICTIONARY:
                    processDictionaryResponseInt(itemEvent);
                    break;
                case RDMMsgTypes.DIRECTORY:
                    processDirectoryResponseInt(itemEvent);
                    break;
                default:
                    break;
            }
        }
    }
}
