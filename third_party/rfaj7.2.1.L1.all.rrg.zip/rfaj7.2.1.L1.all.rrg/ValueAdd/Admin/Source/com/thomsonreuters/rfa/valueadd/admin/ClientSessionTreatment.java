package com.thomsonreuters.rfa.valueadd.admin;

/**
 * Enumeration that defines treatment by provider core for automatically accepting/rejecting
 * all client sessions or notify the provider application about these client sessions accept requests.  
 */
public enum ClientSessionTreatment
{
    NOTIFY, ACCEPT, REJECT;
}
