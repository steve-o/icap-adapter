package com.thomsonreuters.rfa.valueadd.example.consumer;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import com.reuters.rfa.common.Handle;
import com.reuters.rfa.dictionary.DictionaryException;
import com.reuters.rfa.dictionary.FieldDictionary;
import com.thomsonreuters.rfa.valueadd.domainrep.rdm.dictionary.RDMDictionaryCache;
import com.thomsonreuters.rfa.valueadd.domainrep.rdm.dictionary.RDMDictionaryResponse;
import com.thomsonreuters.rfa.valueadd.domainrep.rdm.dictionary.RDMDictionaryResponseAttrib;
import com.thomsonreuters.rfa.valueadd.domainrep.rdm.dictionary.RDMDictionary;
import com.thomsonreuters.rfa.valueadd.example.consumer.DictionaryUtil;
import com.thomsonreuters.rfa.valueadd.example.utility.CommandLine;
import com.thomsonreuters.rfa.valueadd.example.utility.GenericOMMParser;

/**
 * Manages downloading of RWFFld and RWFEnum dictionaries. 
 */
class DictionaryManager
{
    private ValueAddConsumer consumerApp;
    private String serviceName;
    private static byte RDM_MATCH = 0x01; // RDM field from network has the same
    // version and ID as local file
    private static byte ENUM_MATCH = 0x10; // Enumtable from network has the
    // same version and ID as local file
    private static byte RDM_COMPLETE = 0x01; // Received complete RDM field from
    // network or use local(if
    // version is the same)
    private static byte ENUM_COMPLETE = 0x10; // Received complete Enumtable
    // from network or use local(if
    // version is the same)
    private byte dictInfo; // flag to check version of RDM and Enumtable
    // between network and file
    private byte fullDict; // flag to check that RDM and Enumtable are complete

    private String className = getClass().getSimpleName();

    private String downloadedFieldDictName = "flddict";
    private String downloadedEnumDictName = "enumfile";
    private boolean dumpDictFiles = false;

    public DictionaryManager(ValueAddConsumer vaConsDemo)
    {
        this.consumerApp = vaConsDemo;
        readCommandLineOptions();
    }

    private void readCommandLineOptions()
    {
        dumpDictFiles = CommandLine.booleanVariable("dumpFiles");
        serviceName = CommandLine.variable("serviceName");
    }

    // processes RDMDictionaryResponse message containing dictionary info.
    // check the version of local vs. dictionary info and download the full
    // dictionary if version is different.
    public void processDictionaryInfo(RDMDictionaryResponse dictResp, Handle handle)
    {
        RDMDictionaryCache dictInfoCache = new RDMDictionaryCache();
        // Decode and load dictionary into RDMDictionaryStorage
        if (dictResp.hasPayload() && dictResp.getPayload() != null)
            dictInfoCache.load(dictResp.getPayload(), handle);

        // Check dictionary version
        RDMDictionaryResponseAttrib dictAttribInfo = dictResp.getAttrib();
        FieldDictionary fldDictInfo = dictInfoCache.getFieldDictionary();
        FieldDictionary localDictInfo = consumerApp.dictCache.getFieldDictionary();
        String version = "N/A";
        int dictionaryId = fldDictInfo.getDictId();

        boolean sameVersion = true;
        RDMDictionary.DictionaryType dictionaryType = dictInfoCache.getDictionaryType(handle);
        if (dictionaryType == RDMDictionary.DictionaryType.RWFFLD)
        {
            version = fldDictInfo.getFieldProperty("Version");

            // Check field dictionary version
            sameVersion = (dictionaryId == localDictInfo.getDictId())
                    && version.equals(localDictInfo.getFieldProperty("Version"));
            if (sameVersion)
            {
                try
                {
                    downloadedFieldDictName = dictAttribInfo.getDictionaryName();
                    dictInfo |= RDM_MATCH;
                    fullDict |= RDM_COMPLETE;
                }
                catch (DictionaryException e)
                {
                    // Error during read from file, download it instead.
                    sameVersion = false;
                }
            }
        }
        else if (dictionaryType == RDMDictionary.DictionaryType.RWFENUM)
        {
            // Check enum dictionary version
            String localEnumVersion = localDictInfo.getEnumProperty("Version");
            String downloadedEnumVersion = fldDictInfo.getEnumProperty("Version");
            sameVersion = (dictionaryId == localDictInfo.getDictId())
                    && (localEnumVersion == downloadedEnumVersion || localEnumVersion
                            .equals(downloadedEnumVersion));
            if (sameVersion)
            {
                try
                {
                    downloadedEnumDictName = dictAttribInfo.getDictionaryName();
                    dictInfo |= ENUM_MATCH;
                    fullDict |= ENUM_COMPLETE;
                }
                catch (DictionaryException e)
                {
                    // Error during read from file, download it instead.
                    sameVersion = false;
                }
            }
        }

        // If version is same as local dictionaries, request items.
        // Otherwise download full dictionaries from a single service.
        if (sameVersion)
        {
            System.out.println(className + ": " + dictAttribInfo.getDictionaryName()
                    + " from network has the same verion and ID as the local, use the local file");
            if (dictInfo == (RDM_MATCH | ENUM_MATCH))
            {
                System.out
                        .println(className
                                + ": Field and EnumTable from network have the same version and ID as local files.");
                System.out
                        .println(className + className + ": " + "Not downloading full dictionary");
            }

            if (fullDict == (RDM_COMPLETE | ENUM_COMPLETE))
                consumerApp.consumer.sendItemRequest();
        }
        else
        {
            System.out
                    .println(className
                            + ": "
                            + dictAttribInfo.getDictionaryName()
                            + " from network has different version or ID, going to download full dictionary from network.");
            consumerApp.consumer.modifyRequest(handle, consumerApp.requestEncoder
                    .encodeStreamingFullDictReq(dictAttribInfo.getDictionaryName(), serviceName));
        }
    }

    // processes RDMDictionaryResponse message containing full dictionary.
    public void processFullDictionary(RDMDictionaryResponse dictResp, Handle handle)
    {
        // Decode and load dictionary into RDMDictionaryStorage
        if (dictResp.hasPayload() && dictResp.getPayload() != null)
            consumerApp.dictCache.load(dictResp.getPayload(), handle);

        // Initialize GenericOMMParser to use field dictionary received
        try
        {
            GenericOMMParser.initializeDictionary(consumerApp.dictCache.getFieldDictionary());
        }
        catch (DictionaryException ex)
        {
            System.out.println("ERROR: Unable to initialize dictionaries.");
            System.out.println(ex.getMessage());
            return;
        }

        // If dictionary response is final refresh, dump the dictionaries into a
        // file and
        // request items.
        if (dictResp.getIndicationMask().contains(RDMDictionaryResponse.IndicationMask.REFRESH_COMPLETE))
        {
            if (dictResp.hasAttrib())
            {
                RDMDictionaryResponseAttrib dictAttribInfo = dictResp.getAttrib();
                System.out.println(className
                        + ".processFullDictionary: Receive full dictionary of "
                        + dictAttribInfo.getDictionaryName());
            }
            if (consumerApp.dictCache.getDictionaryType(handle) == RDMDictionary.DictionaryType.RWFFLD)
                fullDict |= (byte)RDM_COMPLETE;
            if (consumerApp.dictCache.getDictionaryType(handle) == RDMDictionary.DictionaryType.RWFENUM)
                fullDict |= (byte)ENUM_COMPLETE;

            if (dumpDictFiles)
            {
                try
                {
                    if (consumerApp.dictCache.getDictionaryType(handle) == RDMDictionary.DictionaryType.RWFFLD)
                    {
                        // Field Dictionary
                        File file1 = new File(downloadedFieldDictName + "_network");
                        PrintStream ps1 = new PrintStream(new FileOutputStream(file1));
                        System.out.println(className
                                + ".processFullDictionary: dump Field Dictionary in "
                                + file1.getAbsolutePath());
                        DictionaryUtil.printFieldDictionary(consumerApp.dictCache
                                .getFieldDictionary(), ps1);
                        ps1.close();
                    }
                    if (consumerApp.dictCache.getDictionaryType(handle) == RDMDictionary.DictionaryType.RWFENUM)
                    {
                        // EnumTable Dictionary
                        File file2 = new File(downloadedEnumDictName + "_network");
                        PrintStream ps2 = new PrintStream(new FileOutputStream(file2));
                        System.out.println(className + ".processFullDictionary: dump EnumTable in "
                                + file2.getAbsolutePath());
                        DictionaryUtil.printEnumDictionary(consumerApp.dictCache
                                .getFieldDictionary(), ps2);
                        ps2.close();
                    }
                }
                catch (IOException ex)
                {
                    System.out.println("ERROR : " + className
                            + ".processFullDictionary, cannot print the dictionaries to files");
                    System.out.println(ex.getMessage());
                }
            }
            else
            {
                System.out.println(className + ".processFullDictionary: Printing Field Dictionary");
                DictionaryUtil.printFieldDictionary(consumerApp.dictCache.getFieldDictionary());

                System.out.println(className + ".processFullDictionary: Printing Enum Dictionary");
                DictionaryUtil.printEnumDictionary(consumerApp.dictCache.getFieldDictionary());
            }

            if (fullDict == (RDM_COMPLETE | ENUM_COMPLETE))
                consumerApp.consumer.sendItemRequest();
        }
    }
}
