package com.thomsonreuters.rfa.valueadd.example.consumer;

import java.net.InetAddress;
import java.util.logging.Level;

import com.reuters.rfa.common.Context;
import com.reuters.rfa.dictionary.DictionaryException;
import com.reuters.rfa.omm.OMMMsg;
import com.thomsonreuters.rfa.valueadd.admin.ConsumerCore;
import com.thomsonreuters.rfa.valueadd.admin.ConsumerCoreConfig;
import com.thomsonreuters.rfa.valueadd.domainrep.rdm.dictionary.RDMDictionaryCache;
import com.thomsonreuters.rfa.valueadd.domainrep.rdm.dictionary.RDMDictionary.DictionaryType;
import com.thomsonreuters.rfa.valueadd.example.utility.CommandLine;
import com.thomsonreuters.rfa.valueadd.example.utility.GenericOMMParser;
import com.thomsonreuters.rfa.valueadd.util.ValueAddContext;

/**
 * <p>
 * This is a main class to run ValueAddConsumer application.
 * </p>
 * <p>Initializes ConsumerCore with login, directory and dictionary requests.
 * <p>Dictionaries are requested based on value specified by the user with command line option - dictionaryDownloadType<br>
 * <li>0 - Dictionaries are not requested and therefore are not downloaded by the ConsumerCore
 * <li>1 - Full dictionaries, RWFFld and RWFEnum are automatically downloaded by the ConsumerCore from the first available service.
 * <li>2 - ValueAddConsumer application creates dictionary requests to download full dictionaries for RWFFld and RWFEnum.
 * <li>3 - ValueAddConsumer application creates dictionary requests to download dictionary info for RWFFld and RWFEnum.
 * <p>ConsumerCore dispatches response events in its dispatch thread. ConsumerCore can be configured not to use internal dispatching
 * thread. In this case, application is responsible for dispatches events in its own thread using {@link ConsumerCore#dispatchEvent(int)} interface.  
 * <p>Extends ConsumerCore to handle admin and item events.
 * <p>Cleans up by unregistering all item streams and uninitializing ConsumerCore.
 *
 * @see ConsumerExt
 * @see ConsumerEncoder
 * @see DictionaryManager
 * @see ItemManager
 * 
 */
public class ValueAddConsumer
{
    RDMDictionaryCache dictCache;   // dictionary cache containing local or
                                    // downloaded field dictionary
    ConsumerExt consumer;      // extension to value add consumer core to process events
    ConsumerEncoder requestEncoder; // for encoding all requests

    // wait for dictionaries to be downloaded?
    // if no dictionary (full/info) is being downloaded, this flag is set to false and
    // item is requested after login is successful.
    boolean waitForDictDownload;
    
    enum DictionaryDownloadType
    {
       DO_NOT_DOWNLOAD(0), 
       DOWNLOAD_BY_CORE(1), //Dictionaries are automatically downloaded by the ConsumerCore.  
       DOWNLOAD_WITH_REQUESTS(2), //Dictionaries are downloaded by the ConsumerCore with requests created by the application.
       DOWNLOAD_INFO(3); //ConsumerCore will download only Dictionary INFO.
       
       DictionaryDownloadType(int value)
       {
           this.value = value;
       }
       
       public static DictionaryDownloadType getEnum(int value)
       {
           switch(value)
           {
               case 0:
                   return DO_NOT_DOWNLOAD;
               case 2:
                   return DOWNLOAD_WITH_REQUESTS;
               case 3:
                   return DOWNLOAD_INFO;
               default:
                    return DictionaryDownloadType.DOWNLOAD_BY_CORE;
           }
       }
       int value;
    }
    
    private String className = "ValueAddConsumer";

    ValueAddConsumer()
    {
        System.out.println("*****************************************************************************");
        System.out.println("*          Begin Java VA Consumer Demo Program                              *");
        System.out.println("*****************************************************************************");
        System.out.println("Value Add Version: " + ValueAddContext.getVersion());
    }

    /**
     * Initializes the consumer application.
     * <p>Creates ConsumerCoreConfig, configures administrative requests and initializes ConsumerCore with these admin requests.
     * <p>Creating admin requests and configuring ConsumerCore with these requests is optional.
     * <p>ConsumerCore can be initialized without specifying any admin requests. For example,
     * <p>
     * <code>
     * ConsumerCore consumerCore = new ConsumerCore(); <br>
     * consumerCore.initialize();<br>
     * </code>
     * OR <br>
     * <code>
     * ConsumerCore consumerCore = new ConsumerCore(); <br>
     * ConsumerCoreConfig config = new ConsumerCoreConfig()<br>
     * config.setSessionName(...); <br>
     * consumerCore.initialize(config);<br>
     * </code>
     * @see ConsumerCore#initialize()
     * @see ConsumerCore#initialize(ConsumerCoreConfig)
     */
    public void init()
    {
        System.out.println(className + ": Initializing...");
        consumer = new ConsumerExt(this);
        requestEncoder = new ConsumerEncoder();

        dictCache = new RDMDictionaryCache();

        ConsumerCoreConfig config = new ConsumerCoreConfig();
        config.setSessionName(CommandLine.variable("session"));
        if(CommandLine.booleanVariable("debug"))
        {
            config.setRFALogLevel(Level.FINE);
            config.setAdminLogLevel(Level.FINE);
            config.setAdminLogFile(CommandLine.variable("logfile"));
        }
        configureAdminRequests(config);

        //configure dictionary downloading
        DictionaryDownloadType dictDownLoadType = DictionaryDownloadType.getEnum(CommandLine.intVariable("dictionaryDownloadType"));
        switch(dictDownLoadType)
        {
            case DOWNLOAD_WITH_REQUESTS:
                configureFullDictionaryDownloadWithRequests(config);
                break;
            case DOWNLOAD_INFO:
                configureDictionaryInfoDownload(config);
                break;
            case DO_NOT_DOWNLOAD:
                configureNoDictionaryDownload(config);
                break;
            default:
                configureFullDictionaryDownloadByAdmin(config);
                break;
        }
        
        consumer.initialize(config);
    }

    // encode login and directory requests
    // and inform value add admin module to requests on behalf of the
    // application
    // Directories for all services is downloaded. Info and state filters for
    // theese directories are requested.
    private void configureAdminRequests(ConsumerCoreConfig config)
    {
        OMMMsg loginReqMsg = requestEncoder.encodeLoginRequest(CommandLine.variable("user"),
                                                               CommandLine.variable("position"),
                                                               CommandLine.variable("application"));
        config.setRDMLoginRequest(loginReqMsg);
        requestEncoder.pool.releaseMsg(loginReqMsg);

        OMMMsg dirReqMsg = requestEncoder.encodeDirectoryRequest();
        config.setRDMDirectoryRequest(dirReqMsg);
        requestEncoder.pool.releaseMsg(dirReqMsg);
    }

    // read the dictionaries from local files, no dictionary (info or full) is
    // downloaded.
    // request is made after login is sucessful in this case.
    private void configureNoDictionaryDownload(ConsumerCoreConfig config)
    {
        readLocalDictionaries();
        waitForDictDownload = false;
        config.setDownloadDictionary(false);
    }

    // read from local files, but also download dictionary information.
    // versions from local and downloaded dictionary information is compared
    // if different versions, full dictionary is downloaded.
    // item is requested after dictionary information is received.
    private void configureDictionaryInfoDownload(ConsumerCoreConfig config)
    {
        readLocalDictionaries();
        OMMMsg enumDictReqMsg = requestEncoder.encodeStreamingDictInfoReq("RWFEnum", CommandLine
                .variable("serviceName"));
        OMMMsg fldDictReqMsg = requestEncoder.encodeStreamingDictInfoReq("RWFFld", CommandLine
                .variable("serviceName"));
        config.setEnumDefDictionaryRequest(enumDictReqMsg);
        config.setRDMFieldDictionaryRequest(fldDictReqMsg);
        requestEncoder.pool.releaseMsg(enumDictReqMsg);
        requestEncoder.pool.releaseMsg(fldDictReqMsg);

        waitForDictDownload = true;
        config.setDownloadDictionary(true);
    }

    // Encode requests to download full dictionaries (RWFEnum, RWFFld) from the
    // source.
    // Indicate to value add admin module to request dictionaries from these
    // requests.
    // Item is requested after these dictionaries are received.
    private void configureFullDictionaryDownloadWithRequests(ConsumerCoreConfig config)
    {
        waitForDictDownload = true;
        OMMMsg enumDictReqMsg = requestEncoder.encodeNonStreamingFullDictReq("RWFEnum", CommandLine
                .variable("serviceName"));
        OMMMsg fldDictReqMsg = requestEncoder.encodeNonStreamingFullDictReq("RWFFld", CommandLine
                .variable("serviceName"));
        config.setEnumDefDictionaryRequest(enumDictReqMsg);
        config.setRDMFieldDictionaryRequest(fldDictReqMsg);
        requestEncoder.pool.releaseMsg(enumDictReqMsg);
        requestEncoder.pool.releaseMsg(fldDictReqMsg);
        config.setDownloadDictionary(true);
    }

    // Download full dictionaries (RWFEnum, RWFFld) from the source.
    // Admin module requests the dictionaries after directory message is
    // received.
    // It requests these dictionaries from the first service that accepts
    // requests.
    // Item is requested after these dictionaries are received.
    private void configureFullDictionaryDownloadByAdmin(ConsumerCoreConfig config)
    {
        waitForDictDownload = true;
        config.setDownloadDictionary(true);
    }

    private void readLocalDictionaries()
    {
        String fieldDictionaryFilename = CommandLine.variable("rdmFieldDictionary");
        String enumDictionaryFilename = CommandLine.variable("enumType");
        if ((fieldDictionaryFilename.length() > 0) && (enumDictionaryFilename.length() > 0))
        {
            try
            {
                dictCache.load(fieldDictionaryFilename, DictionaryType.RWFFLD);
                dictCache.load(enumDictionaryFilename, DictionaryType.RWFENUM);
                System.out.println(fieldDictionaryFilename + " is loaded.");
                System.out.println(enumDictionaryFilename + " is loaded.");
                GenericOMMParser.initializeDictionary(dictCache.getFieldDictionary());
            }
            catch (DictionaryException ex)
            {
                System.out.println("ERROR: " + " unable to initialize dictionary from file.");
                System.out.println(ex.getMessage());
                if (ex.getCause() != null)
                    System.err.println(": " + ex.getCause().getMessage());
                cleanup(-1);
            }
        }
    }

    /**
     * Cleans up application resources by unregistering item interest handles and un-initializing ConsumerCore.
     * <p> Exits the application after cleanup.
     * @param exitCode
     */
    public void cleanup(int exitCode)
    {
        System.out.println(className + ": Cleaning up resources....");

        if (consumer != null && exitCode != -1)
            consumer.cleanup();
        requestEncoder.cleanup();
        System.out.println(className + ": Cleaning up resources....done");
        System.exit(exitCode);
    }

    public static void main(String[] args)
    {
        addCommandLineOptions();
        CommandLine.setArguments(args);

        ValueAddConsumer demo = new ValueAddConsumer();
        demo.init();
        demo.run();
        demo.cleanup(0);
    }

    /**
     * Runs the application for specified runTime seconds.
     * Events are dispatched by ConsumerCore in its dispatch thread. 
     * ConsumerCore can be configured not to use internal dispatching thread. 
     * In this case, application is responsible for dispatches events in its own thread using {@link ConsumerCore#dispatchEvent(int)} interface.  
     */
    public void run()
    {
        int runTime = CommandLine.intVariable("runTime");

        // By default, all events are dispatched from value add admin's
        // dispatching thread
        // if application wants to dispatch events in its own thread, configure
        // admin module
        // during initialization to not use dispatching thread to dispatch
        // events.
        // i.e. do coreconfig.useInternalThread(false) in init and use commented
        // out code below.

        // Dispatching by dispatching thread in the value add admin.
        try
        {
            Thread.sleep(runTime * 1000);
        }
        catch (InterruptedException de)
        {
            de.printStackTrace();
        }

        // Dispatching from application thread.
        /*
         * long startTime = System.currentTimeMillis(); while
         * ((System.currentTimeMillis() - startTime) < runTime * 1000) { try {
         * if(consumer != null) consumer.dispatchEvent(1000); }
         * catch(DispatchException de) { de.printStackTrace(); } }
         */
        System.out.println(Context.string());
        System.out.println(className + ": " + runTime + " seconds elapsed, " + getClass().toString()
                           + " exiting");
    }

    static void addCommandLineOptions()
    {
        CommandLine.addOption("debug", false, "enable debug tracing");
        CommandLine.addOption("session", "RSSLNameSpace::Consumer",
                              "Session name to use. Default: RSSLNameSpace::Consumer");
        CommandLine.addOption("serviceName", "DIRECT_FEED", "service to request");
        CommandLine.addOption("itemName", "TRI.N", "List of items to open separated by ','.");
        CommandLine.addOption("dumpFiles", true, "Dump dictionary files?");
        CommandLine.addOption("mmt", "MARKET_PRICE", "Message Model Type");
        CommandLine.addOption("attribInfoInUpdates", false,
                              "Ask provider to send OMMAttribInfo with update and status messages");
        CommandLine.addOption("rdmFieldDictionary", "etc/RDM/RDMFieldDictionary",
                           "RDMFieldDictionary filename. Defaults to etc/RDM/RDMFieldDictionary.");
        CommandLine.addOption("enumType", "etc/RDM/enumtype.def",
                              "enumtype.def filename. Defaults to etc/RDM/enumtype.def");
        CommandLine.addOption("runTime", 600,
                              "How long application should run before exiting (in seconds)");
        CommandLine.addOption("dictionaryDownloadType", 1,
                              "Download dictionary? Type: 0=DO_NOT_DOWNLOAD, 1:DOWNLOAD_BY_CORE, 2: DOWNLOAD_WITH_REQUESTS, 3: DOWNLOAD_INFO. Default is 1: DOWNLOAD_BY_CORE");
        CommandLine.addOption("logfile", "console", "Log file for the value add library. Defaults to console");

        String username = "guest";
        try
        {
            username = System.getProperty("user.name");
        }
        catch (Exception e)
        {
        }
        CommandLine.addOption("user", username, "DACS username for login");
        String defaultPosition = "1.1.1.1/net";
        try
        {
            defaultPosition = InetAddress.getLocalHost().getHostAddress() + "/"
                    + InetAddress.getLocalHost().getHostName();
        }
        catch (Exception e)
        {
        }
        CommandLine.addOption("position", defaultPosition, "DACS position for login");
        CommandLine.addOption("application", "256", "DACS application ID for login");
    }
}
