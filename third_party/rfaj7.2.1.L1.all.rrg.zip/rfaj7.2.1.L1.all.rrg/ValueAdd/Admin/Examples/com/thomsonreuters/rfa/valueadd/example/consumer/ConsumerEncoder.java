package com.thomsonreuters.rfa.valueadd.example.consumer;

import java.util.EnumSet;

import com.reuters.rfa.omm.OMMMsg;
import com.reuters.rfa.omm.OMMPool;
import com.reuters.rfa.rdm.RDMInstrument;
import com.thomsonreuters.rfa.valueadd.domainrep.rdm.dictionary.RDMDictionaryRequest;
import com.thomsonreuters.rfa.valueadd.domainrep.rdm.dictionary.RDMDictionaryRequestAttrib;
import com.thomsonreuters.rfa.valueadd.domainrep.rdm.dictionary.RDMDictionary;
import com.thomsonreuters.rfa.valueadd.domainrep.rdm.directory.RDMDirectory;
import com.thomsonreuters.rfa.valueadd.domainrep.rdm.directory.RDMDirectoryRequest;
import com.thomsonreuters.rfa.valueadd.domainrep.rdm.directory.RDMDirectoryRequestAttrib;
import com.thomsonreuters.rfa.valueadd.domainrep.rdm.login.RDMLoginRequest;
import com.thomsonreuters.rfa.valueadd.domainrep.rdm.login.RDMLoginRequestAttrib;
import com.thomsonreuters.rfa.valueadd.domainrep.rdm.login.RDMLogin;

/**
 * Utility methods to encode login, directory, dictionary and market price messages. 
 */
public class ConsumerEncoder
{
    OMMPool pool;

    public ConsumerEncoder()
    {
        pool = OMMPool.create();
    }

    public OMMMsg encodeStreamingDictInfoReq(String dictionaryName, String serviceName)
    {
        RDMDictionaryRequest dictReq = new RDMDictionaryRequest();
        RDMDictionaryRequestAttrib dictAttribInfo = new RDMDictionaryRequestAttrib();
        dictAttribInfo.setVerbosity(RDMDictionary.Verbosity.INFO);
        dictAttribInfo.setDictionaryName(dictionaryName);
        dictReq.setMessageType(RDMDictionaryRequest.MessageType.REQUEST);
        dictReq.setIndicationMask(EnumSet.of(RDMDictionaryRequest.IndicationMask.REFRESH));
        dictAttribInfo.setServiceName(serviceName);
        dictReq.setAttrib(dictAttribInfo);

        return dictReq.getMsg(pool);
    }

    public OMMMsg encodeStreamingFullDictReq(String dictionaryName, String serviceName)
    {
        RDMDictionaryRequest dictReq = new RDMDictionaryRequest();
        RDMDictionaryRequestAttrib dictAttribInfo = new RDMDictionaryRequestAttrib();
        dictAttribInfo.setVerbosity(RDMDictionary.Verbosity.NORMAL);
        dictAttribInfo.setServiceName(serviceName);
        dictReq.setMessageType(RDMDictionaryRequest.MessageType.REQUEST);
        dictReq.setIndicationMask(EnumSet.of(RDMDictionaryRequest.IndicationMask.REFRESH));
        dictReq.setAttrib(dictAttribInfo);
        return dictReq.getMsg(pool);
    }

    public OMMMsg encodeNonStreamingFullDictReq(String dictionaryName, String serviceName)
    {
        RDMDictionaryRequest dictReq = new RDMDictionaryRequest();
        RDMDictionaryRequestAttrib dictAttribInfo = new RDMDictionaryRequestAttrib();
        dictAttribInfo.setVerbosity(RDMDictionary.Verbosity.NORMAL);
        dictAttribInfo.setDictionaryName(dictionaryName);
        dictReq.setMessageType(RDMDictionaryRequest.MessageType.REQUEST);
        dictReq.setIndicationMask(EnumSet.of(RDMDictionaryRequest.IndicationMask.REFRESH, 
                                             RDMDictionaryRequest.IndicationMask.NONSTREAMING));
        dictAttribInfo.setServiceName(serviceName);
        dictReq.setAttrib(dictAttribInfo);

        return dictReq.getMsg(pool);
    }

    public OMMMsg encodeLoginRequest(String userName, String defaultPosition,
            String defaultApplication)
    {
        RDMLoginRequest loginReq = new RDMLoginRequest();
        RDMLoginRequestAttrib loginAttribInfo = new RDMLoginRequestAttrib();
        loginAttribInfo.setName(userName);
        loginAttribInfo.setApplicationId(defaultApplication);
        loginAttribInfo.setPosition(defaultPosition);
        loginAttribInfo.setRole(RDMLogin.Role.CONSUMER);
        loginReq.setAttrib(loginAttribInfo);
        loginReq.setMessageType(RDMLoginRequest.MessageType.REQUEST);
        loginReq.setIndicationMask(EnumSet.of(RDMLoginRequest.IndicationMask.REFRESH));

        return loginReq.getMsg(pool);
    }

    public OMMMsg encodeDirectoryRequest()
    {
        RDMDirectoryRequest dirReq = new RDMDirectoryRequest();
        dirReq.setMessageType(RDMDirectoryRequest.MessageType.REQUEST);
        dirReq.setIndicationMask(EnumSet.of(RDMDirectoryRequest.IndicationMask.REFRESH));
        RDMDirectoryRequestAttrib dirReqAI = new RDMDirectoryRequestAttrib(EnumSet.of(RDMDirectory.FilterMask.INFO, RDMDirectory.FilterMask.STATE));
        dirReq.setAttrib(dirReqAI);

        return dirReq.getMsg(pool);
    }

    public OMMMsg encodeItemRequest(String serviceName, String itemName, short capability)
    {
        OMMMsg ommMsg = pool.acquireMsg();
        ommMsg.setMsgType(OMMMsg.MsgType.REQUEST);
        ommMsg.setMsgModelType(capability);
        ommMsg.setIndicationFlags(OMMMsg.Indication.REFRESH);
        ommMsg.setPriority((byte)1, 1);
        ommMsg.setAttribInfo(serviceName, itemName.trim(), RDMInstrument.NameType.RIC);
        return ommMsg;
    }

    void cleanup()
    {
        if (pool != null)
            pool.destroy();
        pool = null;
    }
}
