package com.thomsonreuters.rfa.valueadd.example.providernoninteractive;

import java.util.EnumSet;

import com.reuters.rfa.common.QualityOfService;
import com.reuters.rfa.omm.OMMEncoder;
import com.reuters.rfa.omm.OMMFieldList;
import com.reuters.rfa.omm.OMMMsg;
import com.reuters.rfa.omm.OMMNumeric;
import com.reuters.rfa.omm.OMMPool;
import com.reuters.rfa.omm.OMMState;
import com.reuters.rfa.omm.OMMTypes;
import com.reuters.rfa.rdm.RDMInstrument;
import com.reuters.rfa.rdm.RDMMsgTypes;
import com.thomsonreuters.rfa.valueadd.domainrep.ResponseStatus;
import com.thomsonreuters.rfa.valueadd.domainrep.rdm.directory.RDMDirectoryResponse;
import com.thomsonreuters.rfa.valueadd.domainrep.rdm.directory.RDMDirectoryResponseAttrib;
import com.thomsonreuters.rfa.valueadd.domainrep.rdm.directory.RDMDirectoryResponsePayload;
import com.thomsonreuters.rfa.valueadd.domainrep.rdm.directory.RDMDirectory;
import com.thomsonreuters.rfa.valueadd.domainrep.rdm.directory.Service;
import com.thomsonreuters.rfa.valueadd.domainrep.rdm.login.RDMLoginRequest;
import com.thomsonreuters.rfa.valueadd.domainrep.rdm.login.RDMLoginRequestAttrib;
import com.thomsonreuters.rfa.valueadd.domainrep.rdm.login.RDMLogin;
import com.thomsonreuters.rfa.valueadd.example.utility.Rounding;

/**
 * Utility class for encoding login request and responses for directory, market price update and market price refresh
 * messages.
 */
public class ProviderNonInteractiveEncoder
{
    OMMPool pool;
    private OMMEncoder encoder;

    public ProviderNonInteractiveEncoder()
    {
        this.pool = OMMPool.create();
        encoder = pool.acquireEncoder();
        encoder.initialize(OMMTypes.MSG, 2000);
    }

    public OMMMsg encodeLoginRequest(String userName, String defaultPosition, String defaultApplication)
    {
        RDMLoginRequest loginReq = new RDMLoginRequest();
        RDMLoginRequestAttrib loginAttribInfo = new RDMLoginRequestAttrib();
        loginAttribInfo.setName(userName);
        loginAttribInfo.setApplicationId(defaultApplication);
        loginAttribInfo.setPosition(defaultPosition);
        loginAttribInfo.setRole(RDMLogin.Role.PROVIDER_NON_INTERACTIVE);
        loginReq.setAttrib(loginAttribInfo);

        return loginReq.getMsg(pool);
    }

    public OMMMsg encodeMarketPriceUpdate(ItemInfo itemInfo)
    {
        // The size is an estimate. The size MUST be large enough for the entire
        // message.
        // If size is not large enough, RFA will throw out exception related to
        // buffer usage.
        encoder.initialize(OMMTypes.MSG, 500);

        // OMMMsg is a poolable object.
        OMMMsg outmsg = pool.acquireMsg();

        // Set the message type to be an update response.
        outmsg.setMsgType(OMMMsg.MsgType.UPDATE_RESP);

        // Set the message model to be MARKET_PRICE.
        // (all other item message models are not supported by this application)
        outmsg.setMsgModelType(RDMMsgTypes.MARKET_PRICE);

        // Set the indication flag for data not to be conflated.
        outmsg.setIndicationFlags(OMMMsg.Indication.DO_NOT_CONFLATE);

        // Set the response type to be a quote update.
        outmsg.setRespTypeNum(RDMInstrument.Update.QUOTE);

        // Since no attribInfo is requested in the updates, don't set
        // attribInfo into the update response message.
        // No OMMAttribInfo in the message defaults to NO_DATA for
        // OMMAttribInfo.
        // There will be data encoded to the update response message
        // (and we know it is FieldList), so use FIELD_List for the data type of
        // the update response
        // message.
        encoder.encodeMsgInit(outmsg, OMMTypes.NO_DATA, OMMTypes.FIELD_LIST);

        // Initialize the field list encoding.
        // Specifies that this field list has only standard data (data
        // that is not defined in a DataDefinition)
        // DictionaryId is set to 0. This means the data encoded in this
        // message used dictionary identified by id equal to 0.
        // Field list number is set to 1. This identifies the field list
        // (in case for caching in the application or downstream components).
        // Data definition id is set to 0 since standard data does not
        // use data definition. Large data is set to false. This is used since
        // updates in
        // general are not large in size. (If unsure, use true)
        encoder.encodeFieldListInit(OMMFieldList.HAS_STANDARD_DATA, (short)0, (short)1, (short)0);

        // TRDPRC_1
        // Initialize the entry with the field id and data type from
        // RDMFieldDictionary for TRDPRC_1
        encoder.encodeFieldEntryInit((short)6, OMMTypes.REAL);
        double value = itemInfo.getTradePrice1();
        long longValue = Rounding.roundDouble2Long(value, OMMNumeric.EXPONENT_NEG4);

        encoder.encodeReal(longValue, OMMNumeric.EXPONENT_NEG4);
        // BID
        // Initialize the entry with the field id and data type from
        // RDMFieldDictionary for BID
        encoder.encodeFieldEntryInit((short)22, OMMTypes.REAL);
        value = itemInfo.getBid();
        longValue = Rounding.roundDouble2Long(value, OMMNumeric.EXPONENT_NEG4);
        encoder.encodeReal(longValue, OMMNumeric.EXPONENT_NEG4);
        // ASK
        // Initialize the entry with the field id and data type from
        // RDMFieldDictionary for ASK
        encoder.encodeFieldEntryInit((short)25, OMMTypes.REAL);
        value = itemInfo.getAsk();
        longValue = Rounding.roundDouble2Long(value, OMMNumeric.EXPONENT_NEG4);
        encoder.encodeReal(longValue, OMMNumeric.EXPONENT_NEG4);
        // ACVOL_1
        // Initialize the entry with the field id and data type from
        // RDMFieldDictionary for ACVOL_1
        encoder.encodeFieldEntryInit((short)32, OMMTypes.REAL);
        encoder.encodeReal(itemInfo.getACVol1(), OMMNumeric.EXPONENT_0);

        encoder.encodeAggregateComplete(); // Complete the FieldList.
        OMMMsg encodedMsg = (OMMMsg)encoder.acquireEncodedObject();
        pool.releaseMsg(outmsg);
        return encodedMsg;
    }

    public OMMMsg encodeMarketPriceImage(ItemInfo itemInfo, String serviceName)
    {
        // Initialize the encoder to contain a buffer of 1000 bytes.
        encoder.initialize(OMMTypes.MSG, 1000);
        OMMMsg outmsg = pool.acquireMsg();

        // Set the message type to be refresh response.
        outmsg.setMsgType(OMMMsg.MsgType.REFRESH_RESP);

        // Set the message model type to be the type requested.
        outmsg.setMsgModelType(RDMMsgTypes.MARKET_PRICE);

        // Indicate this message will be full refresh or this is the last
        // refresh in the multi-part refresh
        outmsg.setIndicationFlags(OMMMsg.Indication.REFRESH_COMPLETE);

        // Set the item group to be 2. Indicates the item will be in group 2.
        // Set the state of the item stream.
        // Indicate the stream is streaming (Stream.OPEN) and the data provided
        // is OK.
        outmsg.setItemGroup(2);
        outmsg.setState(OMMState.Stream.OPEN, OMMState.Data.OK, OMMState.Code.NONE, "OK");

        // This section is similar to sendUpdates() function, with additional
        // fields. Please see sendUpdates for detailed description.
        outmsg.setIndicationFlags(OMMMsg.Indication.REFRESH_COMPLETE);
        outmsg.setRespTypeNum(OMMMsg.RespType.UNSOLICITED);
        outmsg.setAttribInfo(serviceName, itemInfo.getName(), RDMInstrument.NameType.RIC);
        encoder.encodeMsgInit(outmsg, OMMTypes.NO_DATA, OMMTypes.FIELD_LIST);

        encoder.encodeFieldListInit(OMMFieldList.HAS_STANDARD_DATA | OMMFieldList.HAS_INFO,
                                    (short)0, (short)1, (short)0);
        // RDNDISPLAY
        encoder.encodeFieldEntryInit((short)2, OMMTypes.UINT);
        encoder.encodeUInt(64L);
        // RDN_EXCHID
        encoder.encodeFieldEntryInit((short)4, OMMTypes.ENUM);
        encoder.encodeEnum(2); // NYS
        // DIVIDEND_DATE
        encoder.encodeFieldEntryInit((short)38, OMMTypes.DATE);
        encoder.encodeDate(2008, 12, 25);
        // TRDPRC_1
        // Initialize the entry with the field id and data type from
        // RDMFieldDictionary for TRDPRC_1
        encoder.encodeFieldEntryInit((short)6, OMMTypes.REAL);
        double value = itemInfo.getTradePrice1();
        long longValue = Rounding.roundDouble2Long(value, OMMNumeric.EXPONENT_NEG4);

        // Encode the real number with the price and the hint value.
        // BID
        // Initialize the entry with the field id and data type from
        // RDMFieldDictionary for BID
        encoder.encodeReal(longValue, OMMNumeric.EXPONENT_NEG4);
        encoder.encodeFieldEntryInit((short)22, OMMTypes.REAL);
        value = itemInfo.getBid();
        longValue = Rounding.roundDouble2Long(value, OMMNumeric.EXPONENT_NEG4);
        encoder.encodeReal(longValue, OMMNumeric.EXPONENT_NEG4);

        // ASK
        // Initialize the entry with the field id and data type from
        // RDMFieldDictionary for ASK
        encoder.encodeFieldEntryInit((short)25, OMMTypes.REAL);
        value = itemInfo.getAsk();
        longValue = Rounding.roundDouble2Long(value, OMMNumeric.EXPONENT_NEG4);
        encoder.encodeReal(longValue, OMMNumeric.EXPONENT_NEG4);
        // ACVOL_1
        encoder.encodeFieldEntryInit((short)32, OMMTypes.REAL);
        encoder.encodeReal(itemInfo.getACVol1(), OMMNumeric.EXPONENT_0);
        // ASK_TIME
        encoder.encodeFieldEntryInit((short)267, OMMTypes.TIME);
        encoder.encodeTime(19, 12, 23, 0);

        encoder.encodeAggregateComplete();
        OMMMsg encodedMsg = (OMMMsg)encoder.acquireEncodedObject();
        pool.releaseMsg(outmsg);
        return encodedMsg;
    }

    public OMMMsg encodeDirectoryImage(String serviceName)
    {
        RDMDirectoryResponse dirResp = new RDMDirectoryResponse();
        RDMDirectoryResponseAttrib dirAttribInfo = new RDMDirectoryResponseAttrib();
        dirAttribInfo.setFilterMask(EnumSet.of(RDMDirectory.FilterMask.INFO, RDMDirectory.FilterMask.STATE));
        dirResp.setAttrib(dirAttribInfo);
        dirResp.setMessageType(RDMDirectoryResponse.MessageType.REFRESH_RESP);
        dirResp.setResponseStatus(new ResponseStatus(OMMState.Stream.OPEN, OMMState.Data.OK, OMMState.Code.NONE,""));
        dirResp.setIndicationMask(EnumSet.of(RDMDirectoryResponse.IndicationMask.REFRESH_COMPLETE));
        dirResp.setIsRefreshSolicited(false);

        // The section below is similar to other message encoding.
        RDMDirectoryResponsePayload directoryPayload = new RDMDirectoryResponsePayload();
        dirResp.setPayload(directoryPayload);
        Service service = new Service();
        RDMDirectory.ServiceList list = new RDMDirectory.ServiceList();
        service.setServiceName(serviceName);
        service.setAction(RDMDirectory.ServiceAction.ADD);
        list.add(service);
        directoryPayload.setServiceList(list);
        Service.InfoFilter info = generateInfoBlock(serviceName);
        service.setInfoFilter(info);
        Service.StateFilter state = generateStateBlock();
        service.setStateFilter(state);
        return dirResp.getMsg(pool);
    }

    Service.InfoFilter generateInfoBlock(String serviceName)
    {
        Service.InfoFilter dfInfoBlock = new Service.InfoFilter(serviceName);
        dfInfoBlock.setFilterAction(RDMDirectory.FilterAction.SET);
        dfInfoBlock.setVendor("Reuters");
        dfInfoBlock.setIsSource(false);

        RDMDirectory.CapabilityList capabilityList = new RDMDirectory.CapabilityList();
        capabilityList.add(RDMDirectory.Capability.DICTIONARY);
        capabilityList.add(RDMDirectory.Capability.MARKET_PRICE);
        dfInfoBlock.setCapabilityList(capabilityList);

        RDMDirectory.DictionaryUsedList dictUsed = new RDMDirectory.DictionaryUsedList();
        dictUsed.add("RWFFld");
        dictUsed.add("RWFEnum");

        dfInfoBlock.setDictionaryUsedList(dictUsed);

        RDMDirectory.QosList qos = new RDMDirectory.QosList();
        qos.add(QualityOfService.QOS_REALTIME_TICK_BY_TICK);
        dfInfoBlock.setQosList(qos);

        return dfInfoBlock;
    }

    Service.StateFilter generateStateBlock()
    {
        Service.StateFilter state = new Service.StateFilter(true);
        state.setFilterAction(RDMDirectory.FilterAction.UPDATE);
        state.setAcceptingRequests(true);
        state.setStatus(new ResponseStatus(OMMState.Stream.OPEN, OMMState.Data.OK,
                OMMState.Code.NONE, ""));

        return state;
    }

    public void cleanup()
    {
        if (pool != null && encoder != null)
            pool.releaseEncoder(encoder);

        if (pool != null)
            pool.destroy();
        pool = null;
        encoder = null;
    }
}
