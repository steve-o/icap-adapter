package com.thomsonreuters.rfa.valueadd.example.providernoninteractive;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.StringTokenizer;

import com.reuters.rfa.common.Handle;
import com.reuters.rfa.omm.OMMMsg;
import com.thomsonreuters.rfa.valueadd.example.utility.CommandLine;

/**
 * Client Class to provide data
 */
class DataProvider
{
    private Handle timerHandle;
    private ValueAddProvider_NonInteractive niProviderApp;
    private String servicename;
    private LinkedList<String> itemNamesList;
    List<ItemInfo> itemReqTable;
    int updateInterval, updateRate;

    public DataProvider(ValueAddProvider_NonInteractive niProviderApp)
    {
        /**
         * Create an OMMEncoder with type RWF and initial size of 2000 bytes.
         * The buffer size held on by the encoder is resizeable.
         * 
         * Create an OMMPool for creating OMM types.
         * 
         * @see com.reuters.rfa.omm.OMMPool
         * @see com.reuters.rfa.omm.OMMEncoder
         */
        itemReqTable = new ArrayList<ItemInfo>();
        this.niProviderApp = niProviderApp;
        servicename = CommandLine.variable("serviceName");
        String itemNames = CommandLine.variable("itemName");
        updateInterval = CommandLine.intVariable("updateInterval");
        updateRate = CommandLine.intVariable("updateRate");

        // Note: "," is a valid character for RIC name.
        // This application need to be modified if RIC names have ",".
        StringTokenizer st = new StringTokenizer(itemNames, ",");
        itemNamesList = new LinkedList<String>();
        while (st.hasMoreTokens())
            itemNamesList.add(st.nextToken().trim());
    }

    public void sendUpdates()
    {
        ItemInfo itemInfo = null;
        System.out.println("Updating " + itemReqTable.size() + " items");
        Iterator<ItemInfo> iter = itemReqTable.iterator();
        while (iter.hasNext())
        {
            itemInfo = iter.next();
            if (itemInfo == null)
                continue;

            for (int i = 0; i < updateRate; i++)
            {
                // increment the canned data information for this item.

                itemInfo.increment();

                OMMMsg marketPriceUpdate = niProviderApp.requestResponseEncoder
                        .encodeMarketPriceUpdate(itemInfo);
                // Note the closure of the submit is null. Any closure set by
                // the application must be long lived memory.
                int cmdRet = niProviderApp.providerNonInteractive.submitMsg(niProviderApp.providerNonInteractive
                        .getItemToken(), marketPriceUpdate, null);
                niProviderApp.requestResponseEncoder.pool.releaseMsg(marketPriceUpdate);
                if (cmdRet == 0)
                {
                    System.err.println("Trying to submit for an item with an inactive handle.");
                    iter.remove();
                    break; // break out the for loop to get next request token
                }
            }
        }
    }

    private void sendImage(String name)
    {
        ItemInfo itemInfo = new ItemInfo();
        itemInfo.setName(name);
        itemReqTable.add(itemInfo);
        OMMMsg marketPriceImage = niProviderApp.requestResponseEncoder
                .encodeMarketPriceImage(itemInfo, servicename);
        if (niProviderApp.providerNonInteractive.submitMsg(niProviderApp.providerNonInteractive.getItemToken(),
                                            marketPriceImage, null) > 0)
        {
            System.out.println("Reply sent");
        }
        else
        {
            System.err.println("Trying to submit for an item with an inactive handle.");

            // removes the reference to the Token associated for the item and
            // its ItemInfo.
            itemReqTable.remove(itemInfo.getToken());
        }
        niProviderApp.requestResponseEncoder.pool.releaseMsg(marketPriceImage);
    }

    private void sendDirectoryImage()
    {
        System.out.println("Sending Directory image");
        OMMMsg respMsg = niProviderApp.requestResponseEncoder.encodeDirectoryImage(servicename);
        if (niProviderApp.providerNonInteractive
                .submitMsg(niProviderApp.providerNonInteractive.getItemToken(), respMsg, null) > 0)
            System.out.println("Directory reply sent");
        else
            System.err.println("Trying to submit for an item with an inactive handle.");
        niProviderApp.requestResponseEncoder.pool.releaseMsg(respMsg);
    }

    public void processLoginSuccessful()
    {
        sendDirectoryImage();
        sendImages();

        // start updates to adh or ads pop
        if (timerHandle == null)
        {
            timerHandle = niProviderApp.providerNonInteractive.registerTimer(updateInterval * 1000, true, true,
                                                                 null);
        }
    }
    
    public void processLoginFail()
    {
        // stop publishing
        cleanup();
    }

    private void sendImages()
    {
        for (Iterator<String> iter = itemNamesList.iterator(); iter.hasNext();)
        {
            sendImage((String)iter.next());
        }
    }

    public void cleanup()
    {
        if (timerHandle != null)
        {
            niProviderApp.providerNonInteractive.unRegisterTimer(timerHandle);
            timerHandle = null;
        }
        itemReqTable.clear();
    }
}
