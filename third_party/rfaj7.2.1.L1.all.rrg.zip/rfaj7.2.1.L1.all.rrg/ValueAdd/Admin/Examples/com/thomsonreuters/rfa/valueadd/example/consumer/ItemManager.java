package com.thomsonreuters.rfa.valueadd.example.consumer;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.StringTokenizer;
import com.reuters.rfa.common.Handle;
import com.reuters.rfa.omm.OMMMsg;
import com.reuters.rfa.rdm.RDMMsgTypes;
import com.thomsonreuters.rfa.valueadd.example.utility.CommandLine;

/**
 * Manages opening and closing of item requests. 
 */
class ItemManager
{
    private ValueAddConsumer consumerApp;
    private String className = getClass().getSimpleName();
    private List<Handle> itemHandles = new ArrayList<Handle>();

    ItemManager(ValueAddConsumer consumerApp)
    {
        this.consumerApp = consumerApp;
    }

    void sendRequest()
    {
        System.out.println(className + ": Requesting item....");

        String serviceName = CommandLine.variable("serviceName");
        String itemNames = CommandLine.variable("itemName");
        short capability = RDMMsgTypes.msgModelType(CommandLine.variable("mmt"));

        // Note: "," is a valid character for RIC name.
        // This application need to be modified if RIC names have ",".
        StringTokenizer st = new StringTokenizer(itemNames, ",");
        LinkedList<String> itemNamesList = new LinkedList<String>();
        while (st.hasMoreTokens())
            itemNamesList.add(st.nextToken().trim());

        for (String itemName : itemNamesList)
        {
            OMMMsg ommMsg = consumerApp.requestEncoder.encodeItemRequest(serviceName, itemName,
                                                                         capability);
            Handle itemHandle = consumerApp.consumer.openRequest(ommMsg, true, null);
            itemHandles.add(itemHandle);
            consumerApp.requestEncoder.pool.releaseMsg(ommMsg);
        }
    }

    void cleanup()
    {
        consumerApp.consumer.closeRequest(itemHandles);
        itemHandles.clear();
    }
}
