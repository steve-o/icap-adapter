package com.thomsonreuters.rfa.valueadd.util;

import java.io.UnsupportedEncodingException;
import java.net.URL;
import java.net.URLDecoder;
import com.reuters.rfa.common.Context;

/**
 * Context containing version information for DomainRep library.
 */
public class ValueAddContext
{
    private static String DefaultValueAddVersion = "7.2.0.L1.all";
    private static Class<ValueAddContext> vaPackageClass = ValueAddContext.class;

    public synchronized static String getRFAVersion()
    {
        return Context.getRFAVersionInfo().getProductVersion().trim();
    }

    public synchronized static String getVersion()
    {
        Package pckz = vaPackageClass.getPackage();
        if (pckz != null)
        {
            String version = pckz.getImplementationVersion();
            return version == null ? DefaultValueAddVersion : version;
        }
        return DefaultValueAddVersion;
    }
    
    static String getJarFilePath(Class<?> clazz)
    {
        URL url = ClassLoader.getSystemResource(clazz.getName().replace('.', '/') + ".class");
        // extract everything after "file:/" up to and including ".jar"
        if (url == null)
            return null;

        String urlString = null;
        try
        {
            urlString = URLDecoder.decode(url.toString(), "UTF-8");
        }
        catch (UnsupportedEncodingException e)
        {
            return null;
        }

        String startToken = "file:";
        String endToken = ".jar";
        int startPos = urlString.indexOf(startToken);
        if (startPos == -1)
            return null;
        startPos += startToken.length();
        urlString = urlString.substring(startPos);
        if (urlString.length() == 0)
            return null;
        int endPos = urlString.indexOf(endToken);
        if (endPos == -1)
            return null;
        endPos += endToken.length();
        urlString = urlString.substring(0, endPos);

        return urlString;
    }
}
