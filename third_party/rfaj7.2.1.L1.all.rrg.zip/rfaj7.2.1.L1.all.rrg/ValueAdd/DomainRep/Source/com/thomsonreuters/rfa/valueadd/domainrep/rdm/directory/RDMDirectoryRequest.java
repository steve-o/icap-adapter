package com.thomsonreuters.rfa.valueadd.domainrep.rdm.directory;

import java.util.EnumSet;

import com.reuters.rfa.omm.OMMMsg;
import com.reuters.rfa.omm.OMMPool;
import com.reuters.rfa.omm.OMMTypes;
import com.reuters.rfa.rdm.RDMMsgTypes;
import com.thomsonreuters.rfa.valueadd.domainrep.DomainRequest;
import com.thomsonreuters.rfa.valueadd.domainrep.DomainType;
import com.thomsonreuters.rfa.valueadd.util.ValueAddException;
import com.thomsonreuters.rfa.valueadd.util.ValueAddMessageKeys;
import com.thomsonreuters.rfa.valueadd.util.ValueAddException.ReasonCode;

/**
 * Class to request directory information about services available in the system.
 * <li>It contains MessageType, directory request attributes and indication mask for the request.
 * <li>User can send Streaming ({@link MessageType#REQUEST REQUEST}) or
 *    Non-Streaming ({@link MessageType#REQUEST REQUEST} with 
 *    {@link IndicationMask#NONSTREAMING NONSTREAMING})
 *    request with an optional {@link IndicationMask IndicataionMask},
 *    {@link MessageType#CLOSE_REQUEST CLOSE_REQUEST}
 *    request, or a  {@link MessageType#GENERIC GENERIC} message. 
 * <li>Directory request attributes can be used to request specific filter of a service.
 * <li>As with any {@link DomainRequest}, use {@link #getMsg(OMMPool)} to get encoded {@link OMMMsg} from an object of this class.
 * <li>Similarly, use {@link #setMsg(OMMMsg)} or {@link #RDMDirectoryRequest(OMMMsg)} to decode {@link OMMMsg} into an object of this class.
  * <li>When a field is not set, get method for the field returns default values as specified by the RDM usage guide. 
 *    If there is no default value, get method throws an exception of class ValueAddException.
 * <li>has methods checks if a field is set or not.        
 *       
 * @see MessageType
 * @see IndicationMask
 * @see RDMDirectoryRequestAttrib
 * @see DomainRequest
 */
public class RDMDirectoryRequest extends DomainRequest
{
    private MessageType messageType;
    
    private RDMDirectoryRequestAttrib directoryRequestAttrib;
    private boolean hasDirectoryRequestAttrib;
    private EnumSet<IndicationMask> indicationMask = EnumSet.noneOf(IndicationMask.class);
   
    /**
     * Constructor to create Streaming Directory Request ({@link MessageType#REQUEST}.
     * Streaming Request can be changed to non-streaming request with 
     * {@link IndicationMask#NONSTREAMING}.
     */
    public RDMDirectoryRequest()
    {
        super(DomainType.RDM_DIRECTORY);
        indicationMask = EnumSet.noneOf(IndicationMask.class);
        messageType = MessageType.REQUEST;
    }

    /**
     * Create an {@link RDMDirectoryRequest} by decoding directory request OMMMsg.
     * @throws {@link ValueAddException} if OMMMsg is not valid directory request message. 
     */
    public RDMDirectoryRequest(OMMMsg ommEncodedMsg)
    {
        super(DomainType.RDM_DIRECTORY);
        clear();
        indicationMask = EnumSet.noneOf(IndicationMask.class);
        setMessageType(MessageType.getMessageType(ommEncodedMsg.getMsgType()));
        decode(ommEncodedMsg);
    }

    /**
     * Encode {@link RDMDirectoryRequest} and return encoded {@link OMMMsg}.
     * Caller is expected to return the message back into the same pool.
     * @param pool - OMMMsg is acquired from the pool used when this method is called.
     * @return OMMMsg - encoded OMMMsg. 
     */
    public OMMMsg getMsg(OMMPool pool)
    {
        return encode(pool);
    }

    /**
     * Decode directory request message represented in OMMMsg into this object.
     * Before the decoding, this method first clears any previous values stored for this object.
     * @throws {@link ValueAddException} if OMMMsg is not valid directory request message. 
     */
    public void setMsg(OMMMsg ommEncodedMsg)
    {
        clear();
        decode(ommEncodedMsg);
    }

    /**
     * @return MessageType set or decoded before. 
     * Returns default {@link MessageType#STREAMING_REQUEST} when message type is not set. 
     */
    public MessageType getMessageType()
    {
        return messageType;
    }

    /**
     * @param messageType
     */
    public void setMessageType(MessageType messageType)
    {
        this.messageType = messageType;
    }

    
    /**
     * @return {@link RDMDirectoryRequestAttrib Directory Request Attribute Information}.
     * @throws ValueAddException if attribute information is not set.
     */
    public RDMDirectoryRequestAttrib getAttrib()
    {
        if (hasDirectoryRequestAttrib)
            return directoryRequestAttrib;

        throw new ValueAddException(ReasonCode.MISSING_OPTIONAL_FIELD,
                ValueAddMessageKeys.FIELD_NOT_SET.format("DirectoryRequestAttribute"));
    }

    /**
     * @param directoryRequestAttrib
     */
    public void setAttrib(RDMDirectoryRequestAttrib directoryRequestAttrib)
    {
        this.directoryRequestAttrib = directoryRequestAttrib;
        hasDirectoryRequestAttrib = true;
    }

    /**
     * 
     * @return Boolean flag representing presence of {@link RDMDirectoryRequestAttrib Directory Request Attribute Information}.
     */
    public boolean hasAttrib()
    {
        return hasDirectoryRequestAttrib;
    }

    /**
     * @return Set of {@link IndicationMask IndicationMask}.
     *         Empty EnumSet if indication mask is not set. 
     */
    public EnumSet<IndicationMask> getIndicationMask()
    {
        return indicationMask;
    }

    /**
     * 
     * @param indicationMask
     */
    public void setIndicationMask(EnumSet<IndicationMask> indicationMask)
    {
         this.indicationMask = indicationMask;
    }

    private void setIndications(OMMMsg msg)
    {
        if (msg.isSet(OMMMsg.Indication.ATTRIB_INFO_IN_UPDATES))
        {
            indicationMask.add(IndicationMask.ATTRIB_INFO_IN_UPDATES);
        }
        
        if (msg.isSet(OMMMsg.Indication.REFRESH))
        {
            indicationMask.add(IndicationMask.REFRESH);
        }

        if (msg.isSet(OMMMsg.Indication.NONSTREAMING))
        {
            indicationMask.add(IndicationMask.NONSTREAMING);
        }
    }
    
    /**
     * Clears previously set values and set the default values as defined in RDM Usage Guide. 
     * Used to make this object reusable.
     * See RDMUsageGuide for default values.
     */
    public void clear()
    {
        if (directoryRequestAttrib != null)
            directoryRequestAttrib.clear();
        hasDirectoryRequestAttrib = false;
        messageType = MessageType.REQUEST;
        indicationMask = EnumSet.noneOf(IndicationMask.class);
    }

    private boolean isValidMsg(OMMMsg ommMsg)
    {
        if (ommMsg == null)
            return false;

        if (ommMsg.getMsgModelType() != RDMMsgTypes.DIRECTORY)
            return false;

        return true;
    }

    private void decode(OMMMsg ommMsg)
    {
        if (!isValidMsg(ommMsg))
            throw new ValueAddException(ValueAddMessageKeys.NOT_VALID_MSG.format("Directory"));
        if (ommMsg.has(OMMTypes.ATTRIB_INFO))
        {
            directoryRequestAttrib = new RDMDirectoryRequestAttrib(ommMsg.getAttribInfo());
            hasDirectoryRequestAttrib = true;
        }
        setIndications(ommMsg);
    }

    private OMMMsg encode(OMMPool pool)
    {
        OMMMsg msg = pool.acquireMsg();
        msg.setMsgType(MessageType.getValue(getMessageType()));
        msg.setMsgModelType(DomainType.getValue(getDomainType()));
        if (!indicationMask.isEmpty())
            msg.setIndicationFlags(IndicationMask.getValue(indicationMask));

        if (hasDirectoryRequestAttrib && directoryRequestAttrib != null)
            return directoryRequestAttrib.encode(pool, msg);

        return msg;
    }
    
    /**
     * Indication mask for directory request.
     * See RDM Usage guide for more details.
     */
    public enum IndicationMask
    {
        /**
         * Indication flag to indicate the consumer
         * wants {@link com.reuters.rfa.omm.OMMAttribInfo OMMAttribInfo} in every 
         * {@linkplain com.reuters.rfa.omm.OMMMsg.MsgType#UPDATE_RESP update}
         * and {@linkplain com.reuters.rfa.omm.OMMMsg.MsgType#STATUS_RESP status}
         * message.
         * Leaving this indication flag off will result in less bandwidth usage
         * and better performance.
         */
        ATTRIB_INFO_IN_UPDATES, 
        
        /**
         * Indication flag to indicate that a refresh is requested.
         */
        REFRESH, 
        
        /**
         * Indication flag to indicate a non streaming request (i.e. no updates). 
         * Typically used in conjunction with {@link IndicationMask#REFRESH} to request a refresh. 
         * Update may still be received if the refresh is a multi-part refresh. However,
         * the stream will be closed when the refresh is complete.
         */
        NONSTREAMING;

        static EnumSet<IndicationMask> getIndicationMask(int ommvalue)
        {
            EnumSet<IndicationMask> list = EnumSet.noneOf(IndicationMask.class);
            if ((ommvalue & OMMMsg.Indication.ATTRIB_INFO_IN_UPDATES) != 0)
                list.add(ATTRIB_INFO_IN_UPDATES);
            if ((ommvalue & OMMMsg.Indication.REFRESH) != 0)
                list.add(REFRESH);
            if ((ommvalue & OMMMsg.Indication.NONSTREAMING) != 0)
                list.add(NONSTREAMING);
            return list;
        }

        static int getValue(EnumSet<IndicationMask> typedValue)
        {
            int indicationMask = 0;
            if (typedValue.contains(ATTRIB_INFO_IN_UPDATES))
                indicationMask |= OMMMsg.Indication.ATTRIB_INFO_IN_UPDATES;
            if (typedValue.contains(REFRESH))
                indicationMask |= OMMMsg.Indication.REFRESH;
            if (typedValue.contains(NONSTREAMING))
                indicationMask |= OMMMsg.Indication.NONSTREAMING;
            return indicationMask;
        }
    }
    
    /**
     * Enumerations defining message types used for directory request.
     */
    public enum MessageType
    {
        @Deprecated STREAMING_REQUEST(OMMMsg.MsgType.STREAMING_REQ),
        @Deprecated NON_STREAMING_REQUEST(OMMMsg.MsgType.NONSTREAMING_REQ), 
        @Deprecated PRIORITY_REQUEST(OMMMsg.MsgType.PRIORITY_REQ),
        
        /**
         * Consumer request. 
         */
        REQUEST(OMMMsg.MsgType.REQUEST), 
        
        /**
         * Consumer request to close a stream.
         */
        CLOSE_REQUEST(OMMMsg.MsgType.CLOSE_REQ), 
        
        /**
         * Generic bidirectional message that can be sent or received by OMM Consumers or OMM Providers.
         * This message must be sent on an existing stream.  
         */
        GENERIC(OMMMsg.MsgType.GENERIC);

        private MessageType(int value)
        {
            this.value = (byte)value;
        }

        public static byte getValue(MessageType messageType)
        {
            return messageType.value;
        }

        @SuppressWarnings("deprecation")
        public static MessageType getMessageType(byte value)
        {
            switch (value)
            {
                case OMMMsg.MsgType.STREAMING_REQ:
                    return STREAMING_REQUEST;
                case OMMMsg.MsgType.NONSTREAMING_REQ:
                    return NON_STREAMING_REQUEST;
                case OMMMsg.MsgType.PRIORITY_REQ:
                    return PRIORITY_REQUEST;
                case OMMMsg.MsgType.REQUEST:
                    return REQUEST;
                case OMMMsg.MsgType.CLOSE_REQ:
                    return CLOSE_REQUEST;
                case OMMMsg.MsgType.GENERIC:
                    return GENERIC;
                default:
                    throw new ValueAddException(
                            ValueAddMessageKeys.UNSUPPORTED_MESSAGE_TYPE.format(value));
            }
        }

        private byte value;
    }
}