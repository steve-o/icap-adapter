package com.thomsonreuters.rfa.valueadd.util;

import java.util.ResourceBundle;
import com.reuters.util.MsgKey;

public class ValueAddMessageKeys
{
    public static final String PROPERTIES_FILE = "com.thomsonreuters.rfa.valueadd.util.ValueAddMessages";
    static ResourceBundle Bundle = ResourceBundle.getBundle(PROPERTIES_FILE);

    protected static class DomainMsgKey extends MsgKey
    {
        public DomainMsgKey(String message)
        {
            super(message);
        }

        protected ResourceBundle getBundle()
        {
            return Bundle;
        }
    }

    // rdm domain messages
    public static final MsgKey UNSUPPORTED_DOMAIN_TYPE = new DomainMsgKey("UNSUPPORTED_DOMAIN_TYPE");
    public static final MsgKey UNSUPPORTED_MESSAGE_TYPE = new DomainMsgKey(
            "UNSUPPORTED_MESSAGE_TYPE");
    public static final MsgKey UNSUPPORTED_DICTIONARY_TYPE = new DomainMsgKey(
            "UNSUPPORTED_DICTIONARY_TYPE");
    public static final MsgKey UNSUPPORTED_RESPTYPE_NUM = new DomainMsgKey(
            "UNSUPPORTED_RESPTYPE_NUM");
    public static final MsgKey UNSUPPORTED_DICTIONARY_PAYLOAD = new DomainMsgKey(
            "UNSUPPORTED_DICTIONARY_PAYLOAD");
    public static final MsgKey FIELD_NOT_SET = new DomainMsgKey("FIELD_NOT_SET");
    public static final MsgKey NOT_VALID_MSG = new DomainMsgKey("NOT_VALID_MSG");
    public static final MsgKey REQUIRED_MSG = new DomainMsgKey("REQUIRED_MSG");
    public static final MsgKey INVALID_DICTIONARY_TYPE = new DomainMsgKey("INVALID_DICTIONARY_TYPE");
    public static final MsgKey DICTIONARY_TYPE_UNDETERMINED = new DomainMsgKey(
            "DICTIONARY_TYPE_UNDETERMINED");
    public static final MsgKey INVALID_DATA_TYPE = new DomainMsgKey("INVALID_DATA_TYPE");
    public static final MsgKey DIR_FILTER_ENTRY_INVALID = new DomainMsgKey(
            "DIR_FILTER_ENTRY_INVALID");
    public static final MsgKey INFO_FILTER_NAME_MISMATCH = new DomainMsgKey(
            "INFO_FILTER_NAME_MISMATCH");
    public static final MsgKey INVALID_NAME_TYPE = new DomainMsgKey("INVALID_NAME_TYPE");
    public static final MsgKey INVALID_FILTER_ID = new DomainMsgKey("INVALID_FILTER_ID");
    public static final MsgKey INVALID_DIRECTORY_CAPABILITY = new DomainMsgKey(
            "INVALID_DIRECTORY_CAPABILITY");
    public static final MsgKey FILTER_NOT_ALLOWED_FOR_DELETE = new DomainMsgKey("FILTER_NOT_ALLOWED_FOR_DELETE");
    public static final MsgKey FILTERDATA_NOT_ALLOWED_FOR_CLEAR = new DomainMsgKey("FILTERDATA_NOT_ALLOWED_FOR_CLEAR");
    
    // admin
    public static final MsgKey INVALID_EVENT_SOURCE = new DomainMsgKey("INVALID_EVENT_SOURCE");
    public static final MsgKey UNINITIALIZED = new DomainMsgKey("UNINITIALIZED");
    public static final MsgKey COULD_NOT_ACQUIRE_SESSION = new DomainMsgKey(
            "COULD_NOT_ACQUIRE_SESSION");
    public static final MsgKey ONLY_GENERIC_OR_POST_ALLOWED = new DomainMsgKey(
            "ONLY_GENERIC_OR_POST_ALLOWED");
    public static final MsgKey NO_DISPATCH_ALLOWED = new DomainMsgKey("NO_DISPATCH_ALLOWED");
    public static final MsgKey NOT_INITIALIZED = new DomainMsgKey("NOT_INITIALIZED");
    public static final MsgKey ALREADY_INITIALIZED = new DomainMsgKey("ALREADY_INITIALIZED");

}
