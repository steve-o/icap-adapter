package com.thomsonreuters.rfa.valueadd.domainrep.rdm.login;

import java.util.EnumSet;

import com.reuters.rfa.rdm.RDMUser;
import com.thomsonreuters.rfa.valueadd.domainrep.DomainType;

/**
 * Enumerations used for {@linkplain DomainType#RDM_LOGIN Login RDM}.
 */
public class RDMLogin
{
    /**
     * Enumerations for CONSUMER or PROVIDER login role.
     */
    public enum Role
    {
        CONSUMER(RDMUser.Role.CONSUMER), PROVIDER_NON_INTERACTIVE(RDMUser.Role.PROVIDER);

        private Role(int value)
        {
            this.value = value;
        }

        static int getValue(Role role)
        {
            return role.value;
        }

        static Role getRole(int value)
        {
            switch (value)
            {
                case RDMUser.Role.PROVIDER:
                    return PROVIDER_NON_INTERACTIVE;
                default:
                    return CONSUMER;
            }
        }

        private int value;
    }

    /**
     * Enumeration for login name type. See RDM usage guide for more details. 
     *
     */
    public enum NameType
    {
        USER_NAME(RDMUser.NameType.USER_NAME), USER_TOKEN(RDMUser.NameType.USER_TOKEN), EMAIL_ADDRESS(
                RDMUser.NameType.EMAIL_ADDRESS);

        private NameType(short value)
        {
            this.value = value;
        }

        public static short getValue(NameType nameType)
        {
            return nameType.value;
        }

        public static NameType getNameType(short value)
        {
            switch (value)
            {
                case RDMUser.NameType.USER_NAME:
                    return USER_NAME;
                case RDMUser.NameType.USER_TOKEN:
                    return USER_TOKEN;
                case RDMUser.NameType.EMAIL_ADDRESS:
                    return EMAIL_ADDRESS;
                default:
                    return USER_NAME;
            }
        }

        private short value;
    }

    /**
     * Enumeration for single open attribute in the login messages.
     *
     */
    public enum SingleOpen
    {
        NOT_SUPPORTED, SUPPORTED;

        static EnumSet<RDMLogin.SingleOpen> getSingleOpen(int ommvalue)
        {
            if ((ommvalue & 1) != 0)
                return EnumSet.of(SUPPORTED);
            else
                return EnumSet.of(NOT_SUPPORTED);
        }

        static int getValue(EnumSet<RDMLogin.SingleOpen> typedValue)
        {
            if (typedValue.contains(SUPPORTED))
                return 1;
            else
                return 0;
        }
    }

    /**
     * Enumeration for allow suspect data attribute in the login messages.
     *
     */
    public enum AllowSuspectData
    {
        NOT_SUPPORTED, SUPPORTED;

        static EnumSet<RDMLogin.AllowSuspectData> getAllowSuspectData(int ommvalue)
        {
            if ((ommvalue & 1) != 0)
                return EnumSet.of(SUPPORTED);
            else
                return EnumSet.of(NOT_SUPPORTED);
        }

        static int getValue(EnumSet<RDMLogin.AllowSuspectData> typedValue)
        {
            if (typedValue.contains(SUPPORTED))
                return 1;
            else
                return 0;
        }
    }

    /**
     * Enumeration for download connection config attribute in the login messages. 
     *
     */
    public enum DownloadConnectionConfig
    {
        NOT_SUPPORTED, SUPPORTED;

        static EnumSet<RDMLogin.DownloadConnectionConfig> getDownloadConnectionConfig(int ommvalue)
        {
            if ((ommvalue & 1) != 0)
                return EnumSet.of(SUPPORTED);
            else
                return EnumSet.of(NOT_SUPPORTED);
        }

        static int getValue(EnumSet<RDMLogin.DownloadConnectionConfig> typedValue)
        {
            if (typedValue.contains(SUPPORTED))
                return 1;
            else
                return 0;
        }
    }

    /**
     * Enumeration for provide permission profile attribute in the login messages. 
     *
     */
    public enum ProvidePermissionProfile
    {
        NOT_SUPPORTED, SUPPORTED;

        static EnumSet<RDMLogin.ProvidePermissionProfile> getProvidePermissionProfile(int ommvalue)
        {
            if ((ommvalue & 1) != 0)
                return EnumSet.of(SUPPORTED);
            else
                return EnumSet.of(NOT_SUPPORTED);
        }

        static int getValue(EnumSet<RDMLogin.ProvidePermissionProfile> typedValue)
        {
            if (typedValue.contains(SUPPORTED))
                return 1;
            else
                return 0;
        }
    }

    /**
     * Enumeration for provide permission expressions attribute in the login messages. 
     *
     */
    public enum ProvidePermissionExpressions
    {
        NOT_SUPPORTED, SUPPORTED;

        static EnumSet<RDMLogin.ProvidePermissionExpressions> getProvidePermissionExpressions(
                int ommvalue)
        {
            if ((ommvalue & 1) != 0)
                return EnumSet.of(SUPPORTED);
            else
                return EnumSet.of(NOT_SUPPORTED);
        }

        static int getValue(EnumSet<RDMLogin.ProvidePermissionExpressions> typedValue)
        {
            if (typedValue.contains(SUPPORTED))
                return 1;
            else
                return 0;
        }
    }

    /**
     * Enumeration for support batch requests attribute in the login messages. 
     *
     */
    public enum SupportBatchRequests
    {
        NOT_SUPPORTED, REQUEST_SUPPORTED, REISSUE_SUPPORTED, CLOSE_SUPPORTED;

        static EnumSet<RDMLogin.SupportBatchRequests> getBatchSupport(int ommvalue)
        {
           
            if ((ommvalue & 0x01) != 0 && (ommvalue & 0x02) != 0 && (ommvalue & 0x04) != 0)
                return EnumSet.of(NOT_SUPPORTED);
           
            EnumSet<RDMLogin.SupportBatchRequests> enums = EnumSet.noneOf(RDMLogin.SupportBatchRequests.class);
            
            if((ommvalue & 0x01) != 0)
                enums.add(REQUEST_SUPPORTED);
            if((ommvalue & 0x02) != 0)
                enums.add(REISSUE_SUPPORTED);
            if((ommvalue & 0x04) != 0)
                enums.add(CLOSE_SUPPORTED);
            return enums;
        }

        static int getValue(EnumSet<RDMLogin.SupportBatchRequests> typedValue)
        {
            int retVal = 0;
            if (typedValue.contains(REQUEST_SUPPORTED))
                retVal |= 0x01;
            if (typedValue.contains(REISSUE_SUPPORTED))
                retVal |= 0x02;
            if (typedValue.contains(CLOSE_SUPPORTED))
                retVal |= 0x04;
            return retVal;
        }
    }

    /**
     * Enumeration for support standby attribute in the login messages. 
     *
     */
    public enum SupportStandby
    {
        NOT_SUPPORTED, SUPPORTED;

        static EnumSet<RDMLogin.SupportStandby> getStandbySupport(int ommvalue)
        {
            if ((ommvalue & 1) != 0)
                return EnumSet.of(SUPPORTED);
            else
                return EnumSet.of(NOT_SUPPORTED);
        }

        static int getValue(EnumSet<RDMLogin.SupportStandby> typedValue)
        {
            if (typedValue.contains(SUPPORTED))
                return 1;
            else
                return 0;
        }
    }

    /**
     * Enumeration for support optimized pause resume attribute in the login messages. 
     *
     */
    public enum SupportOptimizedPauseResume
    {
        NOT_SUPPORTED, SUPPORTED;

        static EnumSet<RDMLogin.SupportOptimizedPauseResume> getSupportOptimizedPauseResume(
                int ommvalue)
        {
            if ((ommvalue & 1) != 0)
                return EnumSet.of(SUPPORTED);
            else
                return EnumSet.of(NOT_SUPPORTED);
        }

        static int getValue(EnumSet<RDMLogin.SupportOptimizedPauseResume> typedValue)
        {
            if (typedValue.contains(SUPPORTED))
                return 1;
            else
                return 0;
        }
    }

    /**
     * Enumeration for support view requests attribute in the login messages. 
     *
     */
    public enum SupportViewRequests
    {
        NOT_SUPPORTED, SUPPORTED;

        static EnumSet<RDMLogin.SupportViewRequests> getViewSupport(int ommvalue)
        {
            if ((ommvalue & 1) != 0)
                return EnumSet.of(SUPPORTED);
            else
                return EnumSet.of(NOT_SUPPORTED);
        }

        static int getValue(EnumSet<RDMLogin.SupportViewRequests> typedValue)
        {
            int retVal = 0;
            if (typedValue.contains(SUPPORTED))
                retVal |= 1;

            return retVal;
        }
    }

    /**
     * Enumeration for support omm post attribute in the login messages. 
     *
     */
    public enum SupportOMMPost
    {
        NOT_SUPPORTED, SUPPORTED;

        static EnumSet<RDMLogin.SupportOMMPost> getPostSupport(int ommvalue)
        {
            if ((ommvalue & 1) != 0)
                return EnumSet.of(SUPPORTED);
            else
                return EnumSet.of(NOT_SUPPORTED);
        }

        static int getValue(EnumSet<RDMLogin.SupportOMMPost> typedValue)
        {
            if (typedValue.contains(SUPPORTED))
                return 1;
            else
                return 0;
        }
    }
}