package com.thomsonreuters.rfa.valueadd.domainrep.rdm.login;

import java.util.EnumSet;
import java.util.Iterator;
import com.reuters.rfa.omm.OMMAttribInfo;
import com.reuters.rfa.omm.OMMData;
import com.reuters.rfa.omm.OMMElementEntry;
import com.reuters.rfa.omm.OMMElementList;
import com.reuters.rfa.omm.OMMEncoder;
import com.reuters.rfa.omm.OMMMsg;
import com.reuters.rfa.omm.OMMPool;
import com.reuters.rfa.omm.OMMTypes;
import com.reuters.rfa.rdm.RDMUser;
import com.thomsonreuters.rfa.valueadd.util.RDMUtil;
import com.thomsonreuters.rfa.valueadd.util.ValueAddException;
import com.thomsonreuters.rfa.valueadd.util.ValueAddMessageKeys;

/**
 * Class representing login request attributes as defined in RDM user guide.
 * <li>Contains login name, role, name type as well as attributes for the login request message.
 * <li>As with all RDM attribute representation, use {@link #getAttribInfo(OMMPool)} to get encoded {@link OMMAttribInfo} from an object of this class.
 * <li>Similarly, use {@link #setAttribInfo(OMMAttribInfo)} or {@link #RDMLoginRequestAttrib(OMMAttribInfo)} to decode {@link OMMAttribInfo} 
 *    into an object of this class.
 * <li>When a field is not set, get method for the field returns default values as specified by the RDM usage guide. 
 *    If there is no default value, get method throws an exception of class ValueAddException.
 * <li>has methods checks if a field is set or not.      
 */
public class RDMLoginRequestAttrib
{
    private String name;
    private boolean hasName;
    private RDMLogin.NameType nameType;
    private boolean hasNameType;

    // attrib
    private EnumSet<RDMLogin.AllowSuspectData> allowSuspectData;
    private String applicationId;
    private String applicationName;
    private EnumSet<RDMLogin.DownloadConnectionConfig> downloadConnectionConfig;
    private String instanceId;
    private String password;
    private String position;
    private EnumSet<RDMLogin.ProvidePermissionExpressions> providePermissionExpressions;
    private EnumSet<RDMLogin.ProvidePermissionProfile> providePermissionProfile;
    private RDMLogin.Role role;
    private EnumSet<RDMLogin.SingleOpen> singleOpen;
    
    private boolean hasAppId;
    private boolean hasAppName;
    private boolean hasPosition;
    private boolean hasPassword;
    private boolean hasInstanceId;
    private boolean hasRole;
    private boolean hasProvidePermissionProfile;
    private boolean hasProvidePermissionExpressions;
    private boolean hasSingleOpen;
    private boolean hasAllowSuspect;
    private boolean hasDownloadConnectionConfig;

    public static final int LOGIN_ATTRIB_ENCODER_SIZE = 1024;

    private static final RDMLogin.NameType DEFAULT_NAME_TYPE = RDMLogin.NameType
            .getNameType(RDMUser.NameType.USER_NAME);
    private static final RDMLogin.Role DEFAULT_ROLE = RDMLogin.Role.CONSUMER;
    private static final EnumSet<RDMLogin.ProvidePermissionProfile> DEFAULT_PROV_PERMISSION_PROFILE = 
        EnumSet.of(RDMLogin.ProvidePermissionProfile.SUPPORTED);
    private static final EnumSet<RDMLogin.ProvidePermissionExpressions> DEFAULT_PROV_PERMISSION_EXPRS = 
        EnumSet.of(RDMLogin.ProvidePermissionExpressions.SUPPORTED);
    private static final EnumSet<RDMLogin.SingleOpen> DEFAULT_SINGLE_OPEN = 
        EnumSet.of(RDMLogin.SingleOpen.SUPPORTED);
    private static final EnumSet<RDMLogin.AllowSuspectData> DEFAULT_ALLOW_SUSPECT_DATA = 
        EnumSet.of(RDMLogin.AllowSuspectData.SUPPORTED);
    private static final EnumSet<RDMLogin.DownloadConnectionConfig> DEFAULT_DOWNLOAD_CONN_CONFIG =  EnumSet.of(RDMLogin.DownloadConnectionConfig.NOT_SUPPORTED);

    public RDMLoginRequestAttrib()
    {
        setRDMDefaultValues();
    }

    /**
     * Decode OMMAttribInfo into this object.
     * @param ommAttribInfo to decode
     */
    public RDMLoginRequestAttrib(OMMAttribInfo ommAttribInfo)
    {
        setRDMDefaultValues();
        decode(ommAttribInfo);
    }
    
    /**
     * 
     * @param loginRequestAttrib
     */
    public RDMLoginRequestAttrib(RDMLoginRequestAttrib loginRequestAttrib)
    {
        if (!loginRequestAttrib.hasName())
            throw new ValueAddException(ValueAddException.ReasonCode.MISSING_REQUIRED_FIELD,
                    ValueAddMessageKeys.FIELD_NOT_SET.format("Name"));
        setRDMDefaultValues();
        setName(loginRequestAttrib.getName());
        if (loginRequestAttrib.hasNameType())
            setNameType(loginRequestAttrib.getNameType());
        if (loginRequestAttrib.hasAllowSuspectData())
            setAllowSuspectData(loginRequestAttrib.getAllowSuspectData());

        if (loginRequestAttrib.hasApplicationId())
            setApplicationId(loginRequestAttrib.getApplicationId());

        if (loginRequestAttrib.hasApplicationName())
            setApplicationName(loginRequestAttrib.getApplicationName());

        if (loginRequestAttrib.hasDownloadStandbyConfig())
            setDownloadConnectionConfig(loginRequestAttrib.getDownloadConnectionConfig());

        if (loginRequestAttrib.hasInstanceId())
            setInstanceId(loginRequestAttrib.getInstanceId());

        if (loginRequestAttrib.hasPassword())
            setPassword(loginRequestAttrib.getPassword());

        if (loginRequestAttrib.hasPosition())
            setPosition(loginRequestAttrib.getPosition());

        if (loginRequestAttrib.hasProvidePermissionExpressions())
            setProvidePermissionExpressions(loginRequestAttrib.getProvidePermissionExpressions());
        if (loginRequestAttrib.hasProvidePermissionProfile())
            setProvidePermissionProfile(loginRequestAttrib.getProvidePermissionProfile());
        if (loginRequestAttrib.hasRole())
            setRole(loginRequestAttrib.getRole());
        if (loginRequestAttrib.hasSingleOpen())
            setSingleOpen(loginRequestAttrib.getSingleOpen());
    }

    /**
     * 
     * @return Login UserName.
     * @throws ValueAddException if name field is not set.
     */
    public String getName()
    {
        if (!hasName)
            throw new ValueAddException(ValueAddException.ReasonCode.MISSING_REQUIRED_FIELD,
                    ValueAddMessageKeys.FIELD_NOT_SET.format("Name"));

        return name;
    }

    /**
     * 
     * @param name
     */
    public void setName(String name)
    {
        this.name = name;
        hasName = true;
    }

    /**
     * 
     * @return Flag indicating presence of name field.
     */
    public boolean hasName()
    {
        return hasName;
    }

    /**
     * 
     * @return NameType. Default USER_NAME if name type field is not set.
     */
    public RDMLogin.NameType getNameType()
    {
        if (!hasNameType)
            return DEFAULT_NAME_TYPE;

        return nameType;
    }

    /**
     * 
     * @param nameType
     */
    public void setNameType(RDMLogin.NameType nameType)
    {
        this.nameType = nameType;
        hasNameType = true;
    }

    /**
     * 
     * @return Flag indicating presence of name type.
     */
    public boolean hasNameType()
    {
        return hasNameType;
    }

    /**
     * 
     * @return set of allow suspect data support flags. Default SUPPORTED flag.
     * 
     */
    public EnumSet<RDMLogin.AllowSuspectData> getAllowSuspectData()
    {
        if (!hasAllowSuspect)
            return DEFAULT_ALLOW_SUSPECT_DATA;
        return allowSuspectData;
    }

    /**
     * 
     * @param allowSuspectData
     */
    public void setAllowSuspectData(EnumSet<RDMLogin.AllowSuspectData> allowSuspectData)
    {
        this.allowSuspectData = allowSuspectData;
        hasAllowSuspect = true;
    }

    /**
     * 
     * @return Flag indicating presence of allow suspect data.
     */
    public boolean hasAllowSuspectData()
    {
        return hasAllowSuspect;
    }

    /**
     * 
     * @return Set of provide permission profile support flags. Default is SUPPORTED. 
     */
    public EnumSet<RDMLogin.ProvidePermissionProfile> getProvidePermissionProfile()
    {
        if (!hasProvidePermissionProfile)
            return DEFAULT_PROV_PERMISSION_PROFILE;

        return providePermissionProfile;
    }

    /**
     * 
     * @param providePermissionProfile
     */
    public void setProvidePermissionProfile(
            EnumSet<RDMLogin.ProvidePermissionProfile> providePermissionProfile)
    {
        this.providePermissionProfile = providePermissionProfile;
        hasProvidePermissionProfile = true;
    }

    /**
     * 
     * @return Flag indicating presence of provide permission profile flag.
     */
    public boolean hasProvidePermissionProfile()
    {
        return hasProvidePermissionProfile;
    }

    /**
     * 
     * @return Set of provide permission expressions flags. Default is SUPPORTED.
     */
    public EnumSet<RDMLogin.ProvidePermissionExpressions> getProvidePermissionExpressions()
    {
        if (!hasProvidePermissionExpressions)
            return DEFAULT_PROV_PERMISSION_EXPRS;
        return providePermissionExpressions;
    }

    /**
     * 
     * @param providePermissionExpressions
     */
    public void setProvidePermissionExpressions(
            EnumSet<RDMLogin.ProvidePermissionExpressions> providePermissionExpressions)
    {
        this.providePermissionExpressions = providePermissionExpressions;
        this.hasProvidePermissionExpressions = true;
    }

    /**
     * 
     * @return Flag indicating presence of provide permission expressions.
     */
    public boolean hasProvidePermissionExpressions()
    {
        return hasProvidePermissionExpressions;
    }

    /**
     * 
     * @return Set of SingleOpen support flags. Default is SUPPORTED.
     */
    public EnumSet<RDMLogin.SingleOpen> getSingleOpen()
    {
        if (!hasSingleOpen)
            return DEFAULT_SINGLE_OPEN;
        return singleOpen;
    }

    /**
     * 
     * @param singleOpen
     */
    public void setSingleOpen(EnumSet<RDMLogin.SingleOpen> singleOpen)
    {
        this.singleOpen = singleOpen;
        hasSingleOpen = true;
    }

    /**
     * 
     * @return Flag indicating presence of single open support flags.
     */
    public boolean hasSingleOpen()
    {
        return hasSingleOpen;
    }

    /**
     * 
     * @return Set of support flags for DownloadConnectionConfig. Default is NOT_SUPPORTED.
     */
    public EnumSet<RDMLogin.DownloadConnectionConfig> getDownloadConnectionConfig()
    {
        if (!hasDownloadConnectionConfig)
            return DEFAULT_DOWNLOAD_CONN_CONFIG;
        return downloadConnectionConfig;
    }

    /**
     * 
     * @param downloadStandbyConfig
     */
    public void setDownloadConnectionConfig(EnumSet<RDMLogin.DownloadConnectionConfig> downloadStandbyConfig)
    {
        this.downloadConnectionConfig = downloadStandbyConfig;
        hasDownloadConnectionConfig = true;
    }

    /**
     * 
     * @return Flag indicating presence of DownloadConnectionConfig.
     */
    public boolean hasDownloadStandbyConfig()
    {
        return hasDownloadConnectionConfig;
    }

    /**
     * 
     * @return ApplicationId.
     * @throws ValueAddException if ApplicationId is not set.
     */
    public String getApplicationId()
    {
        if (hasAppId)
            return applicationId;

        throw new ValueAddException(ValueAddException.ReasonCode.MISSING_OPTIONAL_FIELD,
                ValueAddMessageKeys.FIELD_NOT_SET.format("ApplicationId"));
    }

    /**
     * 
     * @param applicationId
     */
    public void setApplicationId(String applicationId)
    {
        this.applicationId = applicationId;
        if (applicationId != null && applicationId.length() > 0)
            hasAppId = true;
    }

    /**
     * 
     * @return Flag indicating presence of ApplicationId.
     */
    public boolean hasApplicationId()
    {
        return hasAppId;
    }

    /**
     * 
     * @return ApplicationName.
     */
    public String getApplicationName()
    {
        if (hasAppName)
            return applicationName;

        throw new ValueAddException(ValueAddException.ReasonCode.MISSING_OPTIONAL_FIELD,
                ValueAddMessageKeys.FIELD_NOT_SET.format("ApplicationName"));
    }

    /**
     * 
     * @param applicationName
     */
    public void setApplicationName(String applicationName)
    {
        this.applicationName = applicationName;
        if (applicationName != null && applicationName.length() > 0)
            hasAppName = true;
    }

    /**
     * 
     * @return Flag indicating presence of ApplicationName.
     */
    public boolean hasApplicationName()
    {
        return hasAppName;
    }

    /**
     * 
     * @return Position
     * @throws ValueAddException if Position field is not set.
     */
    public String getPosition()
    {
        if (hasPosition)
            return position;

        throw new ValueAddException(ValueAddException.ReasonCode.MISSING_OPTIONAL_FIELD,
                ValueAddMessageKeys.FIELD_NOT_SET.format("Position"));
    }

    /**
     * 
     * @param position
     * 
     */
    public void setPosition(String position)
    {
        this.position = position;
        if (position != null && position.length() > 0)
            hasPosition = true;
    }

    /**
     * 
     * @return Flag indicating presence of Position field.
     */
    public boolean hasPosition()
    {
        return hasPosition;
    }

    /**
     * 
     * @return Password.
     * @throws ValueAddException if Password field is not set.
     */
    public String getPassword()
    {
        if (hasPassword)
            return password;

        throw new ValueAddException(ValueAddException.ReasonCode.MISSING_OPTIONAL_FIELD,
                ValueAddMessageKeys.FIELD_NOT_SET.format("Password"));

    }

    /**
     * 
     * @param password
     */
    public void setPassword(String password)
    {
        this.password = password;
        if (password != null && password.length() > 0)
            hasPassword = true;
    }

    /**
     * 
     * @return Flag indicating presence of password.
     */
    public boolean hasPassword()
    {
        return hasPassword;
    }

    /**
     * 
     * @return InstanceId.
     * @throws ValueAddException if InstanceId field is not set.
     */
    public String getInstanceId()
    {
        if (hasInstanceId)
            return instanceId;

        throw new ValueAddException(ValueAddException.ReasonCode.MISSING_OPTIONAL_FIELD,
                ValueAddMessageKeys.FIELD_NOT_SET.format("InstanceId"));
    }

    /**
     * 
     * @param instanceId
     */
    public void setInstanceId(String instanceId)
    {
        this.instanceId = instanceId;
        if (instanceId != null && instanceId.length() > 0)
            hasInstanceId = true;
    }

    /**
     * 
     * @return Flag indicating presence of InstanceId.
     */
    public boolean hasInstanceId()
    {
        return hasInstanceId;
    }

    /**
     * 
     * @return Login Role.
     * @throws ValueAddException if login role is not defined.
     */
    public RDMLogin.Role getRole()
    {
        if (!hasRole)
            throw new ValueAddException(ValueAddException.ReasonCode.MISSING_OPTIONAL_FIELD,
                    ValueAddMessageKeys.FIELD_NOT_SET.format("Role"));

        return role;
    }

    /**
     * 
     * @param role
     */
    public void setRole(RDMLogin.Role role)
    {
        this.role = role;
        hasRole = true;
    }

    /**
     * 
     * @return Flag indicating presence of role field.
     */
    public boolean hasRole()
    {
        return hasRole;
    }

    /**
     * Clears all previous values and decode OMMAttribInfo into this object.
     * @param ommAttribInfo to decode the login request attributes.
     */
    public void setAttribInfo(OMMAttribInfo ommAttribInfo)
    {
        decode(ommAttribInfo);
    }
    
    /**
     * @param pool from which OMMAttribInfo is acquired.
     * @return encoded OMMAttribInfo object from this object. 
     *         User needs to release the returned OMMAttribInfo into the same pool used to call this method. 
     * @throws ValueAddException if required user name is not set.
     */
    public OMMAttribInfo getAttribInfo(OMMPool pool)
    {
        if (!hasName)
                throw new ValueAddException(ValueAddException.ReasonCode.MISSING_REQUIRED_FIELD,
                    ValueAddMessageKeys.FIELD_NOT_SET.format("Name"));
 
        //there is no way to initialize attribute information for encoding attrib
        //for example, encoder.initialize(OMMTypes.ATTRIB_INFO,...)
        //encoder.encodeAttribInfoInit(attribInfo, OMMTypes.ELEMENT_LIST...)
        //and then encode attrib using encoder.encodeElementList...
        //There is no public setAttrib() on attribinfo interface
        OMMMsg ommMsg = pool.acquireMsg();
        
        //Message type is not used in encoded attrib info. No need to encode REFRESH indication here as well.
        ommMsg.setMsgType(RDMLoginRequest.MessageType.getValue(RDMLoginRequest.MessageType.REQUEST));
        OMMMsg encMsg = encode(pool, ommMsg);
        OMMAttribInfo ommAttribInfo = pool.acquireCopy(encMsg.getAttribInfo(), true);
        pool.releaseMsg(encMsg);
        
        return ommAttribInfo;
    }
    
    /**
     * Clears previously set values to make this object reusable.
     */
    public void clear()
    {
        hasName = false;
        hasNameType = false;

        hasAppId = false;
        hasAppName = false;
        hasPosition = false;
        hasPassword = false;
        hasInstanceId = false;
        hasRole = false;
        hasProvidePermissionProfile = false;
        hasProvidePermissionExpressions = false;
        hasSingleOpen = false;
        hasAllowSuspect = false;
        hasDownloadConnectionConfig = false;
        hasRole = false;
        setRDMDefaultValues();
    }

    OMMMsg encode(OMMPool pool, OMMMsg msg)
    {
        if (!hasName)
            throw new ValueAddException(ValueAddException.ReasonCode.MISSING_REQUIRED_FIELD,
                    ValueAddMessageKeys.FIELD_NOT_SET.format("Name"));

        msg.setAttribInfo(null, name, RDMLogin.NameType.getValue(nameType));
        if (!(hasProvidePermissionProfile || hasProvidePermissionExpressions || hasSingleOpen
                || hasAllowSuspect || hasDownloadConnectionConfig || hasAppId || hasAppName || hasPosition || hasPassword
                || hasRole || hasInstanceId))
        {
            return msg;
        }

        // AttribInfo.Attrib
        OMMEncoder encoder = pool.acquireEncoder();
        encoder.initialize(OMMTypes.MSG, LOGIN_ATTRIB_ENCODER_SIZE);
        encoder.encodeMsgInit(msg, OMMTypes.ELEMENT_LIST, OMMTypes.NO_DATA);
        encodeAttrib(encoder);

        OMMMsg encMsg = (OMMMsg)encoder.acquireEncodedObject();

        pool.releaseMsg(msg);
        pool.releaseEncoder(encoder);

        return encMsg;
    }

    private void encodeAttrib(OMMEncoder encoder)
    {
        encoder.encodeElementListInit(OMMElementList.HAS_STANDARD_DATA, (short)0, (short)0);

        if (hasAppId)
        {
            encoder.encodeElementEntryInit(RDMUser.Attrib.ApplicationId, OMMTypes.ASCII_STRING);
            encoder.encodeString(applicationId, OMMTypes.ASCII_STRING);
        }

        if (hasAppName)
        {
            encoder.encodeElementEntryInit(RDMUser.Attrib.ApplicationName, OMMTypes.ASCII_STRING);
            encoder.encodeString(applicationName, OMMTypes.ASCII_STRING);
        }

        if (hasPosition)
        {
            encoder.encodeElementEntryInit(RDMUser.Attrib.Position, OMMTypes.ASCII_STRING);
            encoder.encodeString(position, OMMTypes.ASCII_STRING);
        }

        if (hasPassword)
        {
            encoder.encodeElementEntryInit(RDMUser.Attrib.Password, OMMTypes.ASCII_STRING);
            encoder.encodeString(password, OMMTypes.ASCII_STRING);
        }

        if (hasProvidePermissionProfile)
        {
            encoder.encodeElementEntryInit(RDMUser.Attrib.ProvidePermissionProfile, OMMTypes.UINT);
            encoder.encodeUInt(RDMLogin.ProvidePermissionProfile
                    .getValue(providePermissionProfile));
        }
        if (hasProvidePermissionExpressions)
        {
            encoder.encodeElementEntryInit(RDMUser.Attrib.ProvidePermissionExpressions,
                                           OMMTypes.UINT);
            encoder.encodeUInt(RDMLogin.ProvidePermissionExpressions
                    .getValue(providePermissionExpressions));
        }
        if (hasRole)
        {
            encoder.encodeElementEntryInit(RDMUser.Attrib.Role, OMMTypes.UINT);
            encoder.encodeUInt(RDMLogin.Role.getValue(role));
        }
        if (hasInstanceId)
        {
            encoder.encodeElementEntryInit(RDMUser.Attrib.InstanceId, OMMTypes.ASCII_STRING);
            encoder.encodeString(instanceId, OMMTypes.ASCII_STRING);
        }
        if (hasSingleOpen)
        {
            encoder.encodeElementEntryInit(RDMUser.Attrib.SingleOpen, OMMTypes.UINT);
            encoder.encodeUInt(RDMLogin.SingleOpen.getValue(singleOpen));
        }
        if (hasAllowSuspect)
        {
            encoder.encodeElementEntryInit(RDMUser.Attrib.AllowSuspectData, OMMTypes.UINT);
            encoder.encodeUInt(RDMLogin.AllowSuspectData.getValue(allowSuspectData));
        }

        if (hasDownloadConnectionConfig)
        {
            encoder.encodeElementEntryInit(RDMUser.Attrib.DownloadConnectionConfig, OMMTypes.UINT);
            encoder.encodeUInt(RDMLogin.DownloadConnectionConfig.getValue(downloadConnectionConfig));
        }
        encoder.encodeAggregateComplete();
    }

    void decode(OMMAttribInfo ommAttribInfo)
    {
        clear();
        if (ommAttribInfo.has(OMMAttribInfo.HAS_ATTRIB)
                && ommAttribInfo.getAttribType() != OMMTypes.ELEMENT_LIST)
            throw new ValueAddException(ValueAddMessageKeys.INVALID_DATA_TYPE.format(OMMTypes.toString(OMMTypes.ELEMENT_LIST), OMMTypes.toString(ommAttribInfo.getType())));
        
        if (!ommAttribInfo.has(OMMAttribInfo.HAS_NAME))
            throw new ValueAddException(ValueAddException.ReasonCode.MISSING_REQUIRED_FIELD,
                    ValueAddMessageKeys.FIELD_NOT_SET.format("Name"));

        if (ommAttribInfo.has(OMMAttribInfo.HAS_NAME_TYPE))
        {
            switch (ommAttribInfo.getNameType())
            {
                case RDMUser.NameType.USER_NAME:
                case RDMUser.NameType.EMAIL_ADDRESS:
                case RDMUser.NameType.USER_TOKEN:
                    break;
                default:
                    throw new ValueAddException(
                            ValueAddMessageKeys.INVALID_NAME_TYPE.format(ommAttribInfo
                                    .getNameType()));
            }
        }

        name = ommAttribInfo.getName();
        hasName = true;

        if (ommAttribInfo.has(OMMAttribInfo.HAS_NAME_TYPE))
        {
            nameType = RDMLogin.NameType.getNameType(ommAttribInfo.getNameType());
            hasNameType = true;
        }
        if (ommAttribInfo.has(OMMAttribInfo.HAS_ATTRIB))
        {
            OMMData attrib = ommAttribInfo.getAttrib();
            if (attrib != null && attrib.getType() == OMMTypes.ELEMENT_LIST)
            {
                OMMElementList elementList = (OMMElementList)attrib;
                for (Iterator<?> iter = elementList.iterator(); iter.hasNext();)
                {
                    OMMElementEntry element = (OMMElementEntry)iter.next();
                    OMMData data = element.getData();
                    if (element.getName().equals(RDMUser.Attrib.ApplicationId))
                    {
                        setApplicationId(data.toString());
                    }
                    else if (element.getName().equals(RDMUser.Attrib.ApplicationName))
                    {
                        setApplicationName(data.toString());
                    }
                    else if (element.getName().equals(RDMUser.Attrib.Position))
                    {
                        setPosition(data.toString());
                    }
                    else if (element.getName().equals(RDMUser.Attrib.Password))
                    {
                        setPassword(data.toString());
                    }
                    else if (element.getName().equals(RDMUser.Attrib.ProvidePermissionProfile))
                    {
                        setProvidePermissionProfile(RDMLogin.ProvidePermissionProfile
                                .getProvidePermissionProfile((int)RDMUtil.getLongValue(data)));
                    }
                    else if (element.getName().equals(RDMUser.Attrib.ProvidePermissionExpressions))
                    {
                        setProvidePermissionExpressions(RDMLogin.ProvidePermissionExpressions
                                .getProvidePermissionExpressions((int)RDMUtil.getLongValue(data)));
                    }
                    else if (element.getName().equals(RDMUser.Attrib.SingleOpen))
                    {
                        setSingleOpen(RDMLogin.SingleOpen.getSingleOpen((int)RDMUtil
                                .getLongValue(data)));
                    }
                    else if (element.getName().equals(RDMUser.Attrib.AllowSuspectData))
                    {
                        setAllowSuspectData(RDMLogin.AllowSuspectData.getAllowSuspectData((int)RDMUtil
                                .getLongValue(data)));
                    }
                    else if (element.getName().equals(RDMUser.Attrib.InstanceId))
                    {
                        setInstanceId(data.toString());
                    }
                    else if (element.getName().equals(RDMUser.Attrib.Role))
                    {
                        setRole(RDMLogin.Role.getRole((int)RDMUtil.getLongValue(data)));
                    }
                    else if (element.getName().equals(RDMUser.Attrib.DownloadConnectionConfig))
                    {
                        setDownloadConnectionConfig(RDMLogin.DownloadConnectionConfig.getDownloadConnectionConfig((int)RDMUtil.getLongValue(data)));
                    }
                }
            }
        }
    }

    private void setRDMDefaultValues()
    {
        nameType = DEFAULT_NAME_TYPE;

        singleOpen = DEFAULT_SINGLE_OPEN;
        allowSuspectData = DEFAULT_ALLOW_SUSPECT_DATA;
        providePermissionExpressions = DEFAULT_PROV_PERMISSION_EXPRS;
        providePermissionProfile = DEFAULT_PROV_PERMISSION_PROFILE;
        downloadConnectionConfig = DEFAULT_DOWNLOAD_CONN_CONFIG;
        role = DEFAULT_ROLE;
    }
}
