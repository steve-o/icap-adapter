package com.thomsonreuters.rfa.valueadd.domainrep.rdm.dictionary;

import com.thomsonreuters.rfa.valueadd.domainrep.DomainType;

/**
 * Enumerations used by request and response messages for {@linkplain DomainType#RDM_DICTIONARY} domain.
 */
public class RDMDictionary
{
    /**
     * Enumerations used to define and select the filtering of the data in a Dictionary.
     * This filtering may be just summary information ({@link #INFO}),
     * or information and minimum data ({@link #MINIMAL}),
     * or everything without descriptions and comments({@link #NORMAL}),
     * or everything ({@link #VERBOSE}).
     */
    public enum Verbosity
    {
        INFO(com.reuters.rfa.rdm.RDMDictionary.Filter.INFO), MINIMAL(
                com.reuters.rfa.rdm.RDMDictionary.Filter.MINIMAL), NORMAL(
                com.reuters.rfa.rdm.RDMDictionary.Filter.NORMAL), VERBOSE(
                com.reuters.rfa.rdm.RDMDictionary.Filter.VERBOSE);

        private Verbosity(int value)
        {
            this.value = value;
        }

        static int getValue(Verbosity dataMask)
        {
            return dataMask.value;
        }

        static Verbosity getDataMask(int filter)
        {
            switch (filter)
            {
                case com.reuters.rfa.rdm.RDMDictionary.Filter.INFO:
                    return Verbosity.INFO;

                case com.reuters.rfa.rdm.RDMDictionary.Filter.MINIMAL:
                    return Verbosity.MINIMAL;

                case com.reuters.rfa.rdm.RDMDictionary.Filter.NORMAL:
                    return Verbosity.NORMAL;

                case com.reuters.rfa.rdm.RDMDictionary.Filter.VERBOSE:
                    return Verbosity.VERBOSE;
                default:
                    return null;
            }
        }

        private int value;
    }

    /**
     * Enumerations for supported dictionary types. 
     */
    public enum DictionaryType
    {
        UNSPECIFIED, RWFFLD, RWFENUM;
    }
}