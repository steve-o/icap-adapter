package com.thomsonreuters.rfa.valueadd.domainrep.rdm.login;

import java.util.Iterator;
import com.reuters.rfa.omm.OMMData;
import com.reuters.rfa.omm.OMMElementEntry;
import com.reuters.rfa.omm.OMMElementList;
import com.reuters.rfa.omm.OMMEncoder;
import com.reuters.rfa.omm.OMMPool;
import com.reuters.rfa.omm.OMMTypes;
import com.reuters.rfa.omm.OMMVector;
import com.reuters.rfa.omm.OMMVectorEntry;
import com.thomsonreuters.rfa.valueadd.util.RDMUtil;
import com.thomsonreuters.rfa.valueadd.util.ValueAddException;
import com.thomsonreuters.rfa.valueadd.util.ValueAddListManager;
import com.thomsonreuters.rfa.valueadd.util.ValueAddMessageKeys;
import com.thomsonreuters.rfa.valueadd.util.ValueAddException.ReasonCode;

/**
 * Representation of RDM login response payload. See RDM Usage guide for more details.
 * <li>Contains {@link ConnectionConfig standby configuration}.
 * <li>Use {@link #getData(OMMPool)} to get encoded OMMElementList payload.
 * <li>Similarly, use {@link #RDMLoginResponsePayload(OMMData)} or {@link #setData(OMMData)} to clear
 * all previous values and decode OMMData into this object.
 */

public class RDMLoginResponsePayload
{
    private ConnectionConfig connectionConfig;
    private boolean hasConnectionConfig;
    
    
    public RDMLoginResponsePayload()
    {

    }
    
    /**
     * Decode omm data. Currently supports decoding of connection config information only.
     * @param data Payload data
     * @throws if data is not valid login response payload.
     */
    public RDMLoginResponsePayload(OMMData data)
    {
        setData(data);
    }

    /**
     * 
     * @param connectionConfig
     */
    public void setConnectionConfig(ConnectionConfig connectionConfig)
    {
        this.connectionConfig = connectionConfig;
        hasConnectionConfig = true;
    }
    
    /**
     * 
     * @return ConnectionConfig.
     * @throws ValueAddException if ConnectionConfig is not set.
     */
    public ConnectionConfig getConnectionConfig()
    {
        if (!hasConnectionConfig)
            throw new ValueAddException(ReasonCode.MISSING_OPTIONAL_FIELD, ValueAddMessageKeys.FIELD_NOT_SET.format("ConnectionConfig"));

        return connectionConfig;
    }

    /**
     * 
     * @return Flag representing presence of connection config.
     */
    public boolean hasConnectionConfig()
    {
        return hasConnectionConfig;
    }
    
    /**
     * Encode login response payload. Currently supports ConnectionConfig only.
     * @param pool - OMMPool to acquire payload data from.
     * @return OMMData representing login response payload.
     */
    public OMMData getData(OMMPool pool)
    {
        if (!hasConnectionConfig)
            throw new ValueAddException(ReasonCode.MISSING_OPTIONAL_FIELD, ValueAddMessageKeys.FIELD_NOT_SET.format("ConnectionConfig"));
        
        if(connectionConfig == null)
            return null;
        
        OMMEncoder encoder = pool.acquireEncoder();
        encoder.initialize(OMMTypes.ELEMENT_LIST, 512);
        encoder.encodeElementListInit(OMMElementList.HAS_STANDARD_DATA, (short)1, (short)0);
        encoder.encodeElementEntryInit("ConnectionConfig", OMMTypes.VECTOR);
        encoder.encodeData(connectionConfig.getData(pool));
        encoder.encodeAggregateComplete();
        
        OMMData data = (OMMElementList)encoder.acquireEncodedObject();
        
        pool.releaseEncoder(encoder);
        
        return data;
    }

    /**
     * 
     * @return Flag indicating presence of login response payload.
     */
    public boolean hasData()
    {
        return hasConnectionConfig;
    }

    /**
     * 
     * @param data OMMData to decode.
     * @throws ValueAddException if data is not valid login response payload.
     */
    public void setData(OMMData data)
    {
        if(data.getType() != OMMTypes.ELEMENT_LIST)
            throw new ValueAddException(ValueAddMessageKeys.INVALID_DATA_TYPE.format(OMMTypes.toString(OMMTypes.ELEMENT_LIST), OMMTypes.toString(data.getType())));
        
        clear();
        OMMElementList el = (OMMElementList)data;
        OMMElementEntry connectionConfigEL = null;
        for (Iterator<?> iter = el.iterator(); iter.hasNext();)
        {
            OMMElementEntry entry = (OMMElementEntry)iter.next();
            if (entry.getName().equals("ConnectionConfig"))
            {
                connectionConfigEL = entry;
                break;
            }
        }
        if (connectionConfigEL == null)
            return;

        if (connectionConfigEL.getDataType() != OMMTypes.VECTOR)
            return;

        OMMVector v = (OMMVector)(connectionConfigEL.getData());
        if (v == null)
            return;
        hasConnectionConfig = true;
        connectionConfig = new ConnectionConfig();
        connectionConfig.setData(v);
    }

    /**
     * Clears the payload information from this object.
     */
    public void clear()
    {
        hasConnectionConfig = false;
    }
    
    /**
     * Connection config is representation of login response payload and contains standby configuration information.
     */
    public static class ConnectionConfig
    {
        private long numStandbyServers;
        private boolean hasNumStandbyServers;
        private ServerList serverList;
        private boolean hasServerList;
        
        /**
         * 
         * @return numStandbyServers
         */
        public long getNumStandbyServers()
        {
            return numStandbyServers;
        }

        /**
         * 
         * @param numStandbyServers
         */
        public void setNumStandbyServers(long numStandbyServers)
        {
            this.numStandbyServers = numStandbyServers;
            this.hasNumStandbyServers = true;
        }

        /**
         * 
         * @return Flag indicating presence of numStandbyServers field.
         */
        public boolean hasNumStandbyServers()
        {
            return hasNumStandbyServers;
        }
        
        /**
         * Decode OMMVector representing ConnectionConfig in the login repsonse.
         * @param vector
         */
        public void setData(OMMVector vector)
        {
            if (vector == null)
                return;

            OMMElementList summaryData = (OMMElementList)(vector.getSummaryData());
            if (summaryData == null)
                return;

            for (Iterator<?> iter = summaryData.iterator(); iter.hasNext();)
            {
                setNumStandbyServers(RDMUtil.getLongValue(((OMMElementEntry)iter.next())
                        .getData()));
            }
            ServerList serverList = new ServerList();
            setServerList(serverList);
            for (Iterator<?> iter = vector.iterator(); iter.hasNext();)
            {
                OMMVectorEntry ve = (OMMVectorEntry)iter.next();

                RDMLoginResponsePayload.Server server = new Server();
                server.decode((OMMElementList)ve.getData());
                serverList.add(server);
            }
        }

        /**
         * Encode ConnectionConfig into OMMVector. 
         * @param pool to acquire OMMVector from. 
         * @return OMMVector representing ConnectionConfig.
         */
        public OMMVector getData(OMMPool pool)
        {
            if (!hasNumStandbyServers)
                throw new ValueAddException(ReasonCode.MISSING_OPTIONAL_FIELD,
                        ValueAddMessageKeys.FIELD_NOT_SET.format("numStandbyServers"));
            if (!hasServerList || serverList == null)// || data.getType() != OMMTypes.ELEMENT_LIST)
                throw new ValueAddException(ReasonCode.MISSING_OPTIONAL_FIELD,
                                            ValueAddMessageKeys.FIELD_NOT_SET.format("ServerList"));
            OMMEncoder encoder = pool.acquireEncoder();
            encoder.initialize(OMMTypes.VECTOR, 512);
            encoder.encodeVectorInit(OMMVector.HAS_SUMMARY_DATA, OMMTypes.ELEMENT_LIST,
                                     serverList.size());
            
            encoder.encodeSummaryDataInit();
            encoder.encodeElementListInit(OMMElementList.HAS_STANDARD_DATA, (short)1, (short)0);
            encoder.encodeElementEntryInit("NumStandbyServers", OMMTypes.UINT);
            encoder.encodeUInt(numStandbyServers);
            encoder.encodeAggregateComplete(); //EL - SummaryData: numstandbyconfig

            for (int i = 0; i < serverList.size(); i++)
            {
                encoder.encodeVectorEntryInit(0, OMMVectorEntry.Action.SET, i, null);
                encoder.encodeElementListInit(OMMElementList.HAS_STANDARD_DATA,
                                              (short)(5 * (serverList.size())), (short)0);
                serverList.get(i).encode(encoder);
                encoder.encodeAggregateComplete();
            }
            encoder.encodeAggregateComplete(); //Vector
            
            OMMVector data = (OMMVector)encoder.acquireEncodedObject();
            
            pool.releaseEncoder(encoder);
            
            return data;
        }

        /**
         * 
         * @return ServerList from the ConnectionConfig.
         * @throws ValueAddException if ServerList is not set.
         */
        public ServerList getServerList()
        {
            if (!hasServerList)
            throw new ValueAddException(ReasonCode.MISSING_OPTIONAL_FIELD,
                                        ValueAddMessageKeys.FIELD_NOT_SET.format("ServerList"));

            return serverList;
        }
        
        /**
         * 
         * @param serverList
         */
        public void setServerList(ServerList serverList)
        {
            this.serverList = serverList;
            hasServerList = true;
        }

        /**
         * 
         * @return Flag indicating presence of server list.
         */
        public boolean hasServerList()
        {
            return hasServerList;
        }
        /**
         * Clears this object.
         */
        public void clear()
        {
            hasNumStandbyServers = false;
            hasServerList = false;
            if(serverList != null)
                serverList.clear();
        }

    }
    
    /**
     * List of {@link Server} for standby connection configuration. 
     */
    public static class ServerList extends ValueAddListManager<Server>
    {
    }

    /**
     * Representation of one Server in the ConnectionConfig.  
     */
    public static class Server
    {
        /**
         * Enumeration representing server type. 
         */
        public enum Type
        {
            ACTIVE(0), STANDBY(1);

            private Type(int type)
            {
                this.type = type;
            }

            public int toInt()
            {
                return type;
            }

            public static Type valueOf(int type)
            {
                switch (type)
                {
                    case 0:
                        return ACTIVE;
                    default:
                        return STANDBY;
                }
            }

            int type;
        }

        private String hostName = null;
        private boolean hasHostName;

        long port = 65535;
        private boolean hasPort;

        Type type = Type.STANDBY;
        private boolean hasType;

        long loadFactor;
        private boolean hasLoadFactor;

        private String systemId;
        private boolean hasSystemId;

        Server()
        {

        }

        /**
         * 
         * @param hostName
         * @param port
         */
        public Server(String hostName, long port)
        {
            this.hostName = hostName;
            this.port = port;
            hasHostName = true;
            hasPort = true;
            setRDMDefaultValue();
        }

        /**
         * 
         * @return Port. Default is 65535.
         */
        public long getPort()
        {
            if (!hasPort)
                return 65535;
            return port;
        }

        /**
         * 
         * @param port
         */
        public void setPort(long port)
        {
            this.port = port;
            hasPort = true;
        }

        /**
         * 
         * @return Flag indicating presence of port.
         */
        public boolean hasPort()
        {
            return hasPort;
        }

        /**
         * 
         * @return Server Type. Default is Standby.
         */
        public Type getType()
        {
            if (!hasType)
                return Type.STANDBY;

            return type;
        }

        /**
         * 
         * @param type - ServerType.
         */
        public void setType(Type type)
        {
            this.type = type;
            hasType = true;
        }

        /**
         * 
         * @return Flag indicating presence of server type.
         */
        public boolean hasType()
        {
            return hasType;
        }

        /**
         * 
         * @return SystemId.
         */
        public String getSystemId()
        {
            return hasSystemId ? systemId : null;
        }

        /**
         * 
         * @param systemId
         */
        public void setSystemId(String systemId)
        {
            this.systemId = systemId;
            hasSystemId = true;
        }

        /**
         * 
         * @return Flag indicating presence of system id.
         */
        public boolean hasSystemId()
        {
            return hasSystemId;
        }

        /**
         * 
         * @return hostName.
         */
        public String getHostName()
        {
            return hasHostName ? hostName : null;
        }

        /**
         * 
         * @param hostName
         */
        public void setHostName(String hostName)
        {
            this.hostName = hostName;
            hasHostName = true;
        }

        /**
         * 
         * @return Flag indicating presence of host name.
         */
        public boolean hasHostName()
        {
            return hasHostName;
        }

        /**
         * 
         * @return Load Factor.
         */
        public Long getLoadFactor()
        {
            if (!hasLoadFactor)
                return null;
            return loadFactor;
        }

        /**
         * 
         * @param loadFactor
         */
        public void setLoadFactor(long loadFactor)
        {
            this.loadFactor = loadFactor;
            hasLoadFactor = true;
        }

        /**
         * 
         * @return Flag indicating presence of load factor.
         */
        public boolean hasLoadFactor()
        {
            return hasLoadFactor;
        }

        /**
         * Sets presence flags to false. Sets default values per RDM usage guide.
         */
        public void clear()
        {
            hasHostName = false;
            hasPort = false;
            hasType = false;
            hasLoadFactor = false;
            hasSystemId = false;
            setRDMDefaultValue();
        }

        void encode(OMMEncoder encoder)
        {
            if (!hasHostName)
                throw new ValueAddException("'Hostname' field not set");

            if (!hasPort)
                throw new ValueAddException("'Port' field not set");

            encoder.encodeElementEntryInit("Hostname", OMMTypes.ASCII_STRING);
            encoder.encodeString(hostName, OMMTypes.ASCII_STRING);
            encoder.encodeElementEntryInit("Port", OMMTypes.UINT);
            encoder.encodeUInt(port);

            if (hasLoadFactor)
            {
                encoder.encodeElementEntryInit("LoadFactor", OMMTypes.UINT);
                encoder.encodeUInt(loadFactor);
            }

            if (hasType)
            {
                encoder.encodeElementEntryInit("ServerType", OMMTypes.ENUM);
                encoder.encodeEnum(type.toInt());
            }

            if (hasSystemId)
            {
                encoder.encodeElementEntryInit("SystemID", OMMTypes.ASCII_STRING);
                encoder.encodeString(systemId, OMMTypes.ASCII_STRING);
            }
        }

        void decode(OMMElementList elementList)
        {
            boolean hasHostName = false;
            boolean hasPort = false;
            for (Iterator<?> inIter = elementList.iterator(); inIter.hasNext();)
            {
                OMMElementEntry entry = (OMMElementEntry)inIter.next();
                if (entry.getName().equals("Hostname"))
                {
                    setHostName(entry.getData().toString());
                    hasHostName = true;
                }
                else if (entry.getName().equals("Port"))
                {
                    setPort(Integer.parseInt(entry.getData().toString()));
                    hasPort = true;
                }
                else if (entry.getName().equals("ServerType"))
                {
                    setType(Type.valueOf(Integer.parseInt(entry.getData().toString())));
                }
                else if (entry.getName().equals("LoadFactor"))
                {
                    setLoadFactor(Integer.parseInt(entry.getData().toString()));
                }
                else if (entry.getName().equals("SystemID"))
                {
                    setSystemId(entry.getData().toString());
                }
            }

            if (!hasHostName)
                throw new ValueAddException(ValueAddMessageKeys.FIELD_NOT_SET.format("HostName"));

            if (!hasPort)
                throw new ValueAddException(ValueAddMessageKeys.FIELD_NOT_SET.format("Port"));
        }

        private void setRDMDefaultValue()
        {
            type = Type.STANDBY;
            loadFactor = 65535;
        }
    }
}