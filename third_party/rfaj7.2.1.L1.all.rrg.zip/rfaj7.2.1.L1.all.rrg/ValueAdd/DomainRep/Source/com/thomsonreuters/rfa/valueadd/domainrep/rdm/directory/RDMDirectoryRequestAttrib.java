package com.thomsonreuters.rfa.valueadd.domainrep.rdm.directory;

import java.util.EnumSet;

import com.reuters.rfa.omm.OMMAttribInfo;
import com.reuters.rfa.omm.OMMMsg;
import com.reuters.rfa.omm.OMMPool;
import com.thomsonreuters.rfa.valueadd.util.ValueAddException;
import com.thomsonreuters.rfa.valueadd.util.ValueAddMessageKeys;
import com.thomsonreuters.rfa.valueadd.util.ValueAddException.ReasonCode;

/**
 * Class representing directory request attributes as defined in RDM user guide.
 * <li>Service Name and Service Id fields are optional and they are not specified, if application intends to 
 * request service information for the entire directory.
 * <li>{@link RDMDirectory.FilterMask} for requesting specific filter is required.
 * <li>As with all RDM attribute representation, use {@link #getAttribInfo(OMMPool)} to get encoded {@link OMMAttribInfo} from an object of this class.
 * <li>Similarly, use {@link #setAttribInfo(OMMAttribInfo)} or {@link #RDMDirectoryRequestAttrib(OMMAttribInfo)} to decode {@link OMMAttribInfo} 
 *    into an object of this class.
 * <li>When a field is not set, get method for the field returns default values as specified by the RDM usage guide. 
 *    If there is no default value, get method throws an exception of class ValueAddException.
 * <li>has methods checks if a field is set or not.      
 */
public class RDMDirectoryRequestAttrib
{
    private String serviceName;
    private boolean hasServiceName = false;

    private int serviceId;
    private boolean hasServiceId;
    
    private EnumSet<RDMDirectory.FilterMask> filterMask = EnumSet.noneOf(RDMDirectory.FilterMask.class);
    private boolean hasFilterMask;


    public RDMDirectoryRequestAttrib()
    {

    }

    /**
     * @param filterMask that is minimally required to create RDMDirectoryRequestAttrib object. 
     */
    public RDMDirectoryRequestAttrib(EnumSet<RDMDirectory.FilterMask> filterMask)
    {
        this.filterMask = filterMask;
        hasFilterMask = true;
    }

    /**
     * Decode OMMAttribInfo into this object.
     * @param ommAttribInfo to decode
     */
    public RDMDirectoryRequestAttrib(OMMAttribInfo ommAttribInfo)
    {
        decode(ommAttribInfo);
    }
    
    /**
     * 
     * @param directoryRequestAttribute
     */
    public RDMDirectoryRequestAttrib(RDMDirectoryRequestAttrib directoryRequestAttribute)
    {
        setFilterMask(directoryRequestAttribute.getFilterMask());

        String serviceName = directoryRequestAttribute.getServiceName();
        if (serviceName != null)
            setServiceName(serviceName);

        Integer serviceID = directoryRequestAttribute.getServiceId();
        if (serviceID != null)
            setServiceId(serviceID);
    }

    /**
     * 
     * @return serviceName.
     * @throws ValueAddException if service name is not present.
     */
    public String getServiceName()
    {
        if (!hasServiceName)
            throw new ValueAddException(ReasonCode.MISSING_OPTIONAL_FIELD,
                    ValueAddMessageKeys.FIELD_NOT_SET.format("ServiceName"));

        return serviceName;
    }

    /**
     * 
     * @param serviceName
     */
    public void setServiceName(String serviceName)
    {
        this.serviceName = serviceName;
        hasServiceName = true;
    }

    /**
     * 
     * @return Boolean flag representing presence of ServiceName.
     */
    public boolean hasServiceName()
    {
        return hasServiceName;
    }
    
    /**
     * 
     * @return serviceId.
     * @throws ValueAddException if service id is not present.
     */
    public int getServiceId()
    {
        if (!hasServiceId)
            throw new ValueAddException(ReasonCode.MISSING_OPTIONAL_FIELD,
                    ValueAddMessageKeys.FIELD_NOT_SET.format("ServiceID"));

        return serviceId;
    }

    /**
     * 
     * @return Boolean flag representing presence of ServiceId.
     */
    public boolean hasServiceId()
    {
        return hasServiceId;
    }
    
    /**
     * 
     * @param serviceId
     */
    public void setServiceId(int serviceId)
    {
        this.serviceId = serviceId;
        hasServiceId = true;
    }

    /**
     * @return Set of filter masks set in directory request.
     * @throws ValueADdException if filter mask field is not set.
     */
    public EnumSet<RDMDirectory.FilterMask> getFilterMask()
    {
        if (!hasFilterMask)
            throw new ValueAddException(ReasonCode.MISSING_REQUIRED_FIELD,
                    ValueAddMessageKeys.FIELD_NOT_SET.format("FilterMask"));
        return filterMask;
    }

    /**
     * 
     * @param filterMask
     */
    public void setFilterMask(EnumSet<RDMDirectory.FilterMask> filterMask)
    {
        this.filterMask = filterMask;
        hasFilterMask = true;
    }

    /**
     * 
     * @return Boolean flag representing presence of FilterMask.
     */
    public boolean hasFilterMask()
    {
        return hasFilterMask;
    }
    
    /**
     * Clears all previous values and decode OMMAttribInfo into this object.
     * @param ommAttribInfo to decode the directory request attributes.
     */
    public void setAttribInfo(OMMAttribInfo ommAttribInfo)
    {
        decode(ommAttribInfo);
    }
    
    /**
     * @param pool from which OMMAttribInfo is acquired.
     * @return encoded OMMAttribInfo object from this object. 
     *         User needs to release the returned OMMAttribInfo into the same pool used to call this method. 
     * @throws ValueAddException if required FilterMask field is not set.
     */
    public OMMAttribInfo getAttribInfo(OMMPool pool)
    {
        if (!hasFilterMask())
            throw new ValueAddException(ReasonCode.MISSING_REQUIRED_FIELD,
                    ValueAddMessageKeys.FIELD_NOT_SET.format("FilterMask"));
        
        OMMAttribInfo ommAI = pool.acquireAttribInfo();
        ommAI.setFilter(RDMDirectory.FilterMask.getValue(filterMask));
        if (hasServiceName)
        {
            ommAI.setServiceName(serviceName);
        }

        if (hasServiceId)
        {
            ommAI.setServiceID(serviceId);
        }

        return ommAI;
    }
    
    /**
     * Clears previously set values to make this object reusable.
     */
    public void clear()
    {
        hasServiceId = false;
        hasServiceName = false;
        hasFilterMask = false;
    }

    private void decode(OMMAttribInfo ommAttribInfo)
    {
        if (!ommAttribInfo.has(OMMAttribInfo.HAS_FILTER))
            throw new ValueAddException(ReasonCode.MISSING_REQUIRED_FIELD,
                                        ValueAddMessageKeys.FIELD_NOT_SET.format("FilterMask"));

        filterMask = RDMDirectory.FilterMask.getDataMask(ommAttribInfo.getFilter());
        hasFilterMask = true;
        if (ommAttribInfo.has(OMMAttribInfo.HAS_SERVICE_NAME))
        {
            serviceName = ommAttribInfo.getServiceName();
            hasServiceName = true;
        }

        if (ommAttribInfo.has(OMMAttribInfo.HAS_SERVICE_ID))
        {
            serviceId = ommAttribInfo.getServiceID();
            hasServiceId = true;
        }
    }

    OMMMsg encode(OMMPool pool, OMMMsg ommMsg)
    {
        if (!hasFilterMask())
            throw new ValueAddException(ReasonCode.MISSING_REQUIRED_FIELD,
                    ValueAddMessageKeys.FIELD_NOT_SET.format("FilterMask"));
        

        OMMAttribInfo newAI = getAttribInfo(pool);
        ommMsg.setAttribInfo(newAI);
        pool.releaseAttribInfo(newAI);

        return ommMsg;
    }
}
