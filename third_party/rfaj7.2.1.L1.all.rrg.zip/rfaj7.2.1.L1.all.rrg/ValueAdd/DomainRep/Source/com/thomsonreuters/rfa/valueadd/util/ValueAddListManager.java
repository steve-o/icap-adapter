package com.thomsonreuters.rfa.valueadd.util;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * Base class for list types in RDM implementation.
 */
public class ValueAddListManager<V> implements Iterable<V>
{
    public void add(V v)
    {
        values.add(v);
    }
    public V get(int index)
    {
        return values.get(index);
    }
    
    public boolean contains(V v)
    {
        return values.contains(v);
    }
    
    public int size()
    {
        return values.size();
    }
    public boolean isEmpty()
    {
        return values.isEmpty();
    }
    public void clear()
    {
        values.clear();
    }
    
    @Override
    public Iterator<V> iterator()
    {
       return values.iterator();
    }
    
    private List<V> values = new ArrayList<V>();
}
