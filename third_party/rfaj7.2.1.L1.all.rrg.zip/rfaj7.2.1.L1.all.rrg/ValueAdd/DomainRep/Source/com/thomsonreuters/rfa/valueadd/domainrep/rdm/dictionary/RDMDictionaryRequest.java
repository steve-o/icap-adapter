package com.thomsonreuters.rfa.valueadd.domainrep.rdm.dictionary;

import java.util.EnumSet;

import com.reuters.rfa.omm.OMMMsg;
import com.reuters.rfa.omm.OMMPool;
import com.reuters.rfa.omm.OMMPriority;
import com.reuters.rfa.omm.OMMTypes;
import com.reuters.rfa.rdm.RDMMsgTypes;
import com.thomsonreuters.rfa.valueadd.domainrep.DomainRequest;
import com.thomsonreuters.rfa.valueadd.domainrep.DomainType;
import com.thomsonreuters.rfa.valueadd.util.ValueAddException;
import com.thomsonreuters.rfa.valueadd.util.ValueAddMessageKeys;

/**
 * Representation of RDM dictionary request message.
 * <li> Contains {@link MessageType#REQUEST Request}, and Close {@link MessageType#CLOSE_REQUEST Close}
 * MessageType, optional priority of the message, and dictionary request attribute.
 * <li>As with any {@link DomainRequest}, use {@link #getMsg(OMMPool)} to get encoded {@link OMMMsg} from an object of this class.
 * <li>Similarly, use {@link #setMsg(OMMMsg)} or {@link #RDMDictionaryRequest(OMMMsg)} to decode {@link OMMMsg} into an object of this class.
 * <li>When a field is not set, get method for the field returns default values as specified by the RDM usage guide. 
 *    If there is no default value, get method throws an exception of class ValueAddException.
 * <li>has methods checks if a field is set or not.        
 */
public class RDMDictionaryRequest extends DomainRequest
{
    private MessageType messageType;
    private EnumSet<IndicationMask> indicationMask = EnumSet.noneOf(IndicationMask.class);

    private RDMDictionaryRequestAttrib dictionaryRequestAttrib;
    private boolean hasDictionaryRequestAttrib;

    private OMMPriority priority;
    private boolean hasPriority;

    /**
     * Constructs a streaming dictionary request ({@link MessageType#REQUEST.
     * Streaming Request can be changed to non-streaming request with 
     * {@link IndicationMask#NONSTREAMING}.
     */
    public RDMDictionaryRequest()
    {
        super(DomainType.RDM_DICTIONARY);
        messageType = MessageType.REQUEST;
        indicationMask = EnumSet.noneOf(IndicationMask.class);
    }

    /**
     * Decode dictionary request message.
     * @param encodedMessage
     */
    public RDMDictionaryRequest(OMMMsg encodedMessage)
    {
        super(DomainType.RDM_DICTIONARY);
        clear();
        setMessageType(MessageType.getMessageType(encodedMessage.getMsgType()));
        decode(encodedMessage);
    }

    /**
     * Encode {@link RDMDictionaryRequest} and return encoded {@link OMMMsg}.
     * Caller is expected to return the message back into the same pool.
     * @param pool - OMMMsg is acquired from the pool used when this method is called.
     * @return OMMMsg - encoded OMMMsg. 
     */
    public OMMMsg getMsg(OMMPool pool)
    {
        return encode(pool);
    }

    /**
     * Decode dictionary response message represented in OMMMsg into this object.
     * Before decoding the encoded dictionary response message, 
     * this method first clears any previous values stored for this object.
     * @param ommEncodedMessage - Encoded dictionary response message.
     * @throws {@link ValueAddException} if OMMMsg is not valid dictionary response message. 
     */
    public void setMsg(OMMMsg ommEncodedMessage)
    {
        clear();
        decode(ommEncodedMessage);
    }

    /**
     * @return MessageType set or decoded before. 
     * Returns default {@link MessageType#REQUEST} when message type is not set. 
     */
    public MessageType getMessageType()
    {
        return messageType;
    }

    /**
     * 
     * @param messageType
     */
    public void setMessageType(MessageType messageType)
    {
        this.messageType = messageType;
    }

    /**
     * 
     * @return Priority.
     * @throws ValueAddException if priority is not set.
     */
    public OMMPriority getPriority()
    {
        if (!hasPriority)
            throw new ValueAddException(ValueAddException.ReasonCode.MISSING_OPTIONAL_FIELD,
                    ValueAddMessageKeys.FIELD_NOT_SET.format("Priority"));
        return priority;
    }

    /**
     * Set priority from priority class and priority count.
     * @param priorityClass
     * @param priorityCount
     */
    public void setPriority(byte priorityClass, int priorityCount)
    {
        priority = OMMPriority.create(priorityClass, priorityCount);
        hasPriority = true;
    }

    /**
     *
     * @param ommPriority
     */
    public void setPriority(OMMPriority ommPriority)
    {
        this.priority = ommPriority;
        hasPriority = true;
    }

    /**
     * 
     * @return Flag indication presence of priority.
     */
    public boolean hasPriority()
    {
        return hasPriority;
    }

    /**
     * 
     * @return RDMDictionaryRequestAttrib
     * @throws ValueAddException if attribute is not set.
     */
    public RDMDictionaryRequestAttrib getAttrib()
    {
        if (hasDictionaryRequestAttrib)
            return dictionaryRequestAttrib;

        throw new ValueAddException(ValueAddException.ReasonCode.MISSING_OPTIONAL_FIELD,
                ValueAddMessageKeys.FIELD_NOT_SET.format("DictionaryRequestAttrib"));
    }
    
    /**
     * 
     * @param dictionaryRequestAttrib
     */
    public void setAttrib(RDMDictionaryRequestAttrib dictionaryRequestAttrib)
    {
        this.dictionaryRequestAttrib = dictionaryRequestAttrib;
        hasDictionaryRequestAttrib = true;
    }
    
    /**
     * 
     * @return Flag indicating presence of attribute.
     */
    public boolean hasAttrib()
    {
        return hasDictionaryRequestAttrib;
    }

    /**
     * Clears attribute and sets presence flags to false and message type to streaming request.
     */
    public void clear()
    {
        if (dictionaryRequestAttrib != null)
            dictionaryRequestAttrib.clear();
        hasDictionaryRequestAttrib = false;
        hasPriority = false;
        messageType = MessageType.REQUEST;
        indicationMask = EnumSet.noneOf(IndicationMask.class);
    }

    private void decode(OMMMsg ommMsg)
    {
        if (!isValidMsg(ommMsg))
            throw new ValueAddException(ValueAddMessageKeys.NOT_VALID_MSG.format("Dictionary"));

        if (ommMsg.has(OMMMsg.HAS_PRIORITY) && ommMsg.getPriority() != null)
        {
            priority = OMMPriority.create(ommMsg.getPriority().getPriorityClass(), ommMsg
                    .getPriority().getCount());
            hasPriority = true;
        }
        if (ommMsg.has(OMMTypes.ATTRIB_INFO))
        {
            dictionaryRequestAttrib = new RDMDictionaryRequestAttrib(ommMsg.getAttribInfo());
            hasDictionaryRequestAttrib = true;
        }
        setIndications(ommMsg);
    }

    private boolean isValidMsg(OMMMsg encodedMessage)
    {
        if (encodedMessage == null)
            return false;

        if (encodedMessage.getMsgModelType() != RDMMsgTypes.DICTIONARY)
            return false;

        return true;
    }

    private OMMMsg encode(OMMPool pool)
    {
        OMMMsg msg = pool.acquireMsg();
        msg.setMsgType(MessageType.getValue(getMessageType()));
        msg.setMsgModelType(DomainType.getValue(getDomainType()));

        if (hasPriority)
            msg.setPriority(priority);

        if (!indicationMask.isEmpty())
            msg.setIndicationFlags(IndicationMask.getValue(indicationMask));

        if (hasDictionaryRequestAttrib && dictionaryRequestAttrib != null)
            return dictionaryRequestAttrib.encode(pool, msg);

        return msg;
    }
    
    /**
     * @return Set of {@link IndicationMask IndicationMask}.
     *         Empty EnumSet if indication mask is not set. 
     */
    public EnumSet<IndicationMask> getIndicationMask()
    {
        return indicationMask;
    }

    /**
     * 
     * @param indicationMask
     */
    public void setIndicationMask(EnumSet<IndicationMask> indicationMask)
    {
         this.indicationMask = indicationMask;
    }
    
    private void setIndications(OMMMsg msg)
    {
        if (msg.isSet(OMMMsg.Indication.REFRESH))
        {
            indicationMask.add(IndicationMask.REFRESH);
        }
        
        if (msg.isSet(OMMMsg.Indication.NONSTREAMING))
        {
            indicationMask.add(IndicationMask.NONSTREAMING);
        }
    }
    
    /**
     * Indication mask for dictionary request.
     * See RDM Usage guide for more details.
     */
    public enum IndicationMask
    {
        /**
         * Indication flag to indicate that a refresh is requested.
         */
        REFRESH,
        
        /**
         * Indication flag to indicate a non streaming request (i.e. no updates). 
         * Typically used in conjunction with {@link IndicationMask#REFRESH} to request a refresh. 
         * Update may still be received if the refresh is a multi-part refresh. However,
         * the stream will be closed when the refresh is complete.
         */
        NONSTREAMING;
        
        static EnumSet<IndicationMask> getIndicationMask(int ommvalue)
        {
            EnumSet<IndicationMask> list = EnumSet.noneOf(IndicationMask.class);
            if ((ommvalue & OMMMsg.Indication.REFRESH) != 0)
                list.add(REFRESH);
            return list;
        }

        static int getValue(EnumSet<IndicationMask> typedValue)
        {
            int indicationMask = 0;
            if (typedValue.contains(REFRESH))
                indicationMask |= OMMMsg.Indication.REFRESH;
            if (typedValue.contains(NONSTREAMING))
                indicationMask |= OMMMsg.Indication.NONSTREAMING;
            return indicationMask;
        }
    }
    
    /**
     * Enumerations representing message types used for dictionary request.
     */
    public enum MessageType
    {
        @Deprecated STREAMING_REQUEST(OMMMsg.MsgType.STREAMING_REQ),
        @Deprecated NON_STREAMING_REQUEST(OMMMsg.MsgType.NONSTREAMING_REQ), 
        @Deprecated PRIORITY_REQUEST(OMMMsg.MsgType.PRIORITY_REQ),
        
        /**
         * Consumer request. 
         */
        REQUEST(OMMMsg.MsgType.REQUEST), 
        
        /**
         * Consumer request to close a stream.
         */
        CLOSE_REQUEST(OMMMsg.MsgType.CLOSE_REQ), 
        
        /**
         * Generic bidirectional message that can be sent or received by OMM Consumers or OMM Providers.
         * This message must be sent on an existing stream.  
         */
        GENERIC(OMMMsg.MsgType.GENERIC);

        private MessageType(int value)
        {
            this.value = (byte)value;
        }

        public static byte getValue(MessageType messageType)
        {
            return messageType.value;
        }

        @SuppressWarnings("deprecation")
        public static MessageType getMessageType(byte value)
        {
            switch (value)
            {
                case OMMMsg.MsgType.STREAMING_REQ:
                    return STREAMING_REQUEST;
                case OMMMsg.MsgType.NONSTREAMING_REQ:
                    return NON_STREAMING_REQUEST;
                case OMMMsg.MsgType.PRIORITY_REQ:
                    return PRIORITY_REQUEST;
                case OMMMsg.MsgType.REQUEST:
                    return REQUEST;
                case OMMMsg.MsgType.CLOSE_REQ:
                    return CLOSE_REQUEST;
                case OMMMsg.MsgType.GENERIC:
                    return GENERIC;
                default:
                    throw new ValueAddException(
                            ValueAddMessageKeys.UNSUPPORTED_MESSAGE_TYPE.format(value));
            }
        }

        private byte value;
    }
}
