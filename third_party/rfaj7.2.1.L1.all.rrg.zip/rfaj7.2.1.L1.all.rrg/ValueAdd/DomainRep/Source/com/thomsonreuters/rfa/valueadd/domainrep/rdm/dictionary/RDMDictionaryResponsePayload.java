package com.thomsonreuters.rfa.valueadd.domainrep.rdm.dictionary;

import com.reuters.rfa.omm.OMMData;
import com.reuters.rfa.omm.OMMSeries;
import com.reuters.rfa.omm.OMMTypes;
import com.thomsonreuters.rfa.valueadd.util.ValueAddException;
import com.thomsonreuters.rfa.valueadd.util.ValueAddMessageKeys;

/**
 * Representation of RDM dictionary response payload. See RDM Usage guide for more details.
 * <li>Use {@link #getData()} to get encoded OMMSeries payload.
 * <li>Similarly, use {@link #RDMDictionaryResponsePayload(OMMData)} or {@link #setData(OMMData)} to clear
 * all previous values and decode OMMData into this object.
 */
public class RDMDictionaryResponsePayload
{
    private OMMSeries data;
    private boolean hasData;

    public RDMDictionaryResponsePayload()
    {

    }

    /**
     * @param data - OMMSeries representing dictionary response payload.
     * @throws ValueAddException if data is not OMMSeries.  
     */
    public RDMDictionaryResponsePayload(OMMData data)
    {
        setData(data);
    }

    /**
     * 
     * @param data - OMMSeries representing dictionary response payload.
     * @throws ValueAddException if data is not OMMSeries.
     */
    public void setData(OMMData data)
    {
        if (data.getType() != OMMTypes.SERIES)
            throw new ValueAddException(ValueAddMessageKeys.INVALID_DATA_TYPE.format(OMMTypes.toString(OMMTypes.SERIES), OMMTypes.toString(data.getType())));
        this.data = (OMMSeries)data;
        this.hasData = true;
    }

    /**
     * 
     * @return OMMSeries representing dictionary response payload.
     * @throws ValueAddException if data is not OMMSeries.
     */
    public OMMData getData()
    {
        if (!hasData)
            throw new ValueAddException(ValueAddException.ReasonCode.MISSING_OPTIONAL_FIELD,
                ValueAddMessageKeys.FIELD_NOT_SET.format("Payload"));
        return data;
    }

    /**
     * 
     * @return Flag indicating presence of payload data.
     */
    public boolean hasData()
    {
        return hasData;
    }

    /**
     * Clears presence flags and payload data.
     */
    public void clear()
    {
        data = null;
        hasData = false;
    }
}
