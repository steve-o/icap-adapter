package com.thomsonreuters.rfa.valueadd.util;

public class ValueAddException extends RuntimeException
{
    private static final long serialVersionUID = 7964938558554062481L;
    private ReasonCode reasonCode = ReasonCode.NOT_SET;

    public enum ReasonCode
    {
        MISSING_REQUIRED_FIELD, MISSING_OPTIONAL_FIELD, NOT_SET;
    }

    public ReasonCode getReasonCode()
    {
        return reasonCode;
    }

    public ValueAddException(String errorText)
    {
        super(errorText);
    }

    public ValueAddException(ReasonCode reasonCode, String errorText)
    {
        super(errorText);
        this.reasonCode = reasonCode;
    }
}
