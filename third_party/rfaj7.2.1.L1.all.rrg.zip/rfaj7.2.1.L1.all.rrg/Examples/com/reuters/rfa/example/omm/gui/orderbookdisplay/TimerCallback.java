package com.reuters.rfa.example.omm.gui.orderbookdisplay;

public interface TimerCallback
{
    public void processTimer();

}
