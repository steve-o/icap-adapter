package com.reuters.rfa.example.omm.gui.viewer;

import java.util.Iterator;


import com.reuters.rfa.dictionary.FieldDictionary;
import com.reuters.rfa.omm.OMMState;
import com.reuters.rfa.omm.OMMTypes;

/**
 * Adapt an {@link com.reuters.rfa.omm.OMMFieldList OMMFieldList} into a
 * <code>TableModel</code> that can be used by used by a <code>JTable</code>.
 */
public class FieldListTableModel extends FadingTableModel
{
    /**
	 * 
	 */
    private static final long serialVersionUID = 1L;
    FieldListValues _fieldListValues;
    FieldDictionary _dictionary;
    boolean _vertical;

    public FieldListTableModel(FieldDictionary dictionary, boolean vert)
    {
        _dictionary = dictionary;
        _vertical = vert;
    }

    @Override
    public String getColumnName(int columnIndex)
    {
        String retVal = "<Title>";

        if (_vertical) {
            if (columnIndex == 0) {
                retVal = "FID";
            } else if (columnIndex == 1) {
                retVal = "Name";
            } else if (columnIndex == 2) {
                retVal = "Value";
            } else {
                retVal = "Encoded Len / Max Len";
            }            
        } else {
        FieldValue field = null;
        Iterator<FieldValue> iterator = _fieldListValues.iterator();
            for (int i = 0; i <= columnIndex; i++) {
                field = (FieldValue) iterator.next();
    }

            if (field != null) 
                retVal = field.getName();
        }

        return retVal;
    }

    @Override
    public int getColumnCount()
    {
        if (_vertical)
            return 4; 
        return _fieldListValues.size();
    }

    @Override
    public int getRowCount()
    {
        if (_vertical)
            return _fieldListValues.size();
        return 1;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex)
    {
        return (_vertical) ? getVertValueAt(rowIndex, columnIndex) : getRowValueAt(rowIndex,
                                                                                   columnIndex);
    }

    private String expandedEnumValue(FieldValue field, Object enumVal) {
        return enumVal
                + "->\""
                + _dictionary.expandedValueFor(field.getFieldId(), Integer.parseInt(field.getStringValue()))
                + "\"";
    }

    private Object getVertValueAt(int rowIndex, int columnIndex)
    {
        FieldValue field = null;
        Iterator<FieldValue> iterator = _fieldListValues.iterator();
        for (int i = 0; i <= rowIndex; i++)
            field = (FieldValue)iterator.next();

        Object retVal = "<appError!>";

        if (field != null) {
            if (columnIndex == 0) {
                retVal = String.format("%05d", field.getFieldId());
            } else if (columnIndex == 1) {
                retVal = field.getName();
            } else if (columnIndex == 2) {
                retVal = field.getStringValue();
                if ((!field.isBlank()) && (field.getOMMType() == OMMTypes.ENUM))
                    retVal = expandedEnumValue(field, retVal);
            } else if (columnIndex == 3) {
                retVal = " " + field.getEncodedLength() + " / " + field.getMaxLength();
            }
        }

        return retVal;
    }

    private Object getRowValueAt(int rowIndex, int columnIndex)
    {
        FieldValue field = null;

        String val = "";
        if (_fieldListValues.size() > 0 ) {
        Iterator<FieldValue> iterator = _fieldListValues.iterator();
        for (int i = 0; i <= columnIndex; i++)
            field = (FieldValue)iterator.next();

            if (field != null) {
                val = field.getStringValue();

                if ( (!field.isBlank()) && (field.getOMMType() == OMMTypes.ENUM) )
                    val = expandedEnumValue(field, val);
            }
        }
        
        return val;
    }

    public void processClear()
    {
        fireTableStructureChanged();
        fireTableDataChanged();
    }

    public void resizeColumns()
    {
    }

    @Override
    public void fade()
    {
        if (_fieldListValues == null)
            return;
        int i = 0;
        for (Iterator<FieldValue> iter = _fieldListValues.iterator(); iter.hasNext();)
        {
            FieldValue value = (FieldValue)iter.next();
            if (value.fade())
            {
                if (_vertical)
                    fireTableCellUpdated(i, 2); 
                else
                    fireTableRowsUpdated(_fieldListValues._row, _fieldListValues._row);
            }
            i++;
        }
    }

    @Override
    public boolean isSuspect()
    {
        return _fieldListValues.getDataState() == OMMState.Data.SUSPECT;
    }

    @Override
    public boolean isUpdated(int rowIndex, int columnIndex)
    {
        if (columnIndex != 2) 
            return false;
        Iterator<FieldValue> iter = _fieldListValues.iterator();
        int i = 0;
        while (iter.hasNext())
        {
            FieldValue v = (FieldValue)iter.next();
            if (i == rowIndex)
                return v.isUpdated();
            i++;
        }
        return false;
    }

}
