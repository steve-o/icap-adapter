package com.reuters.rfa.example.utility.gui;

public interface Status
{
    public void setStatus(String status);
}
