package com.thomsonreuters.rfa.valueadd.admin;

/**
 * Configuration for interactive provider core. Adds interactive core specific configuration to base class - CoreConfig.
 * @see CoreConfig
 */
public class ProviderInteractiveCoreConfig extends CoreConfig
{
    private String listenerName = "";

    /**
     * Initializes ProviderInteractiveCoreConfig with default values.
     */
    public ProviderInteractiveCoreConfig()
    {
        setSessionName("RSSLNameSpace::ProviderInteractive");
        setCoreName("ProviderInteractive");
    }
    
    /**
     * 
     * @return Listener name
     */
    public String getListenerName()
    {
        return listenerName;
    }

    /**
     * Sets the listener name for the configured connection within the session.
     * @param listenerName the name specifying a connection to listen.
     */
    public void setListenerName(String listenerName)
    {
        this.listenerName = listenerName;
    }

    /**
     * Clears all configuration values set by the user and sets them to default values.
     */
    public void clear()
    {
        super.clear();
        setSessionName("RSSLNameSpace::ProviderInteractive");
        setCoreName("ProviderInteractive");
        listenerName = "";
    }

    public String toString()
    {
        StringBuilder buffer = new StringBuilder(super.toString());
        buffer.append(", Listener name: " + listenerName);
        return buffer.toString();
    }
}
