package com.thomsonreuters.rfa.valueadd.admin;

import com.reuters.rfa.omm.OMMMsg;
import com.reuters.rfa.omm.OMMPool;

/**
 * Configuration for non interactive provider core. Adds non interactive core specific configuration to base class - CoreConfig.
 * @see CoreConfig
 */
public class ProviderNonInteractiveCoreConfig extends CoreConfig
{
    private OMMMsg rdmLoginRequest;
    private OMMPool pool;
    private boolean OMMConnectionEventInterest;

    /**
     * Initializes ProviderNonInteractiveCoreConfig with default values.
     */
    public ProviderNonInteractiveCoreConfig()
    {
        pool = OMMPool.create();
        setSessionName("RSSLNameSpace::ProviderNonInteractive");
        setCoreName("ProviderNonInteractive");
        OMMConnectionEventInterest = false;
    }

    /**
     * 
     * @return Login request message used by ProviderNonInteractiveCore. If ProviderNonInteractiveCore uses default login request, this method returns null.
     */
    public OMMMsg getRDMLoginRequest()
    {
        return rdmLoginRequest;
    }
    
    /**
     * Sets Login request message to be used by ProviderNonInteractiveCore.
     * @param encodedLoginRequestMsg 
     */
    public void setRDMLoginRequest(OMMMsg encodedLoginRequestMsg)
    {
        this.rdmLoginRequest = pool.acquireCopy(encodedLoginRequestMsg, false);
    }

    /**
     * 
     * @return Indication if ProviderNonInteractiveCore interested in receiving OMM Connection Events.
     */
    public boolean getOMMConnectionEventInterest()
    {
        return OMMConnectionEventInterest;
    }

    /**
     * 
     * @param connectionEventInterest - Flag to ProviderNonInteractiveCore to indicate interest in receiving OMM Connection Events. 
     */
    public void setOMMConnectionEventInterest(boolean connectionEventInterest)
    {
        this.OMMConnectionEventInterest = connectionEventInterest;
    }

    /**
     * Clears all configuration values set by the user and sets them to default values.
     */
    public void clear()
    {
        super.clear();
        setSessionName("RSSLNameSpace::ProviderNonInteractive");
        setCoreName("ProviderNonInteractive");
        if (rdmLoginRequest != null)
            pool.releaseMsg(rdmLoginRequest);
        rdmLoginRequest = null;
        OMMConnectionEventInterest = false;
    }

    public String toString()
    {
        StringBuilder buffer = new StringBuilder(super.toString());
        buffer.append(", Login Request set by user? " + rdmLoginRequest != null);
        buffer.append(", Interested in OMMConnectionEvents? " + OMMConnectionEventInterest);
        return buffer.toString();
    }
}