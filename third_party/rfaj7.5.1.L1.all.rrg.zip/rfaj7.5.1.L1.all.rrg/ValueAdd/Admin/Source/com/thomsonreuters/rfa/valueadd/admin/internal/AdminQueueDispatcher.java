package com.thomsonreuters.rfa.valueadd.admin.internal;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.TimeUnit;

import com.reuters.rfa.common.DispatchException;
import com.reuters.rfa.common.EventQueue;

public class AdminQueueDispatcher
{
    private ExecutorService executor;
    private EventQueue queue;
    private String name;
    private int dispatchTimeOutMillis;

    public AdminQueueDispatcher(String name, EventQueue queue, int dispatchTimeOutMillis)
    {
        this.name = name;
        this.queue = queue;
        executor = Executors.newSingleThreadExecutor(new SimpleThreadFactory());
        this.dispatchTimeOutMillis = dispatchTimeOutMillis;
    }

    class SimpleThreadFactory implements ThreadFactory
    {
        public Thread newThread(Runnable r)
        {
            Thread t = new Thread(r, name);
            if (t.isDaemon())
                t.setDaemon(false);
            if (t.getPriority() != Thread.NORM_PRIORITY)
                t.setPriority(Thread.NORM_PRIORITY);

            return t;
        }
    }

    public void stop(int joinTimeout)
    {
        executor.shutdown(); // Disable new tasks from being submitted
        try
        {
            // Wait a while for existing tasks to terminate
            if (!executor.awaitTermination(joinTimeout, TimeUnit.MILLISECONDS))
            {
                executor.shutdownNow(); // Cancel currently executing tasks
                // Wait a while for tasks to respond to being cancelled
                if (!executor.awaitTermination(joinTimeout, TimeUnit.MILLISECONDS))
                    System.err.println("Pool did not terminate");
            }
        }
        catch (InterruptedException ie)
        {
            // (Re-)Cancel if current thread also interrupted
            executor.shutdownNow();
            // Preserve interrupt status
            Thread.currentThread().interrupt();
        }
    }

    public void start()
    {
        executor.execute(new DispatchTask());
    }

    protected boolean isRunning()
    {
        return !executor.isShutdown();
    }

    class DispatchTask implements Runnable
    {
        public void run()
        {
            while (isRunning() && queue.isActive())
            {
                try
                {
                    queue.dispatch(dispatchTimeOutMillis);
                }
                catch (DispatchException e)
                {
                    break;
                }
                catch (RuntimeException re)
                {
                    re.printStackTrace();
                    break;
                }
            }
        }
    }

}
