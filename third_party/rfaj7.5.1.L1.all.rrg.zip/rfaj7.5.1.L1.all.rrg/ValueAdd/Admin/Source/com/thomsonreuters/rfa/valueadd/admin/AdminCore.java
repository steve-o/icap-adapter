package com.thomsonreuters.rfa.valueadd.admin;

import java.util.concurrent.atomic.AtomicReference;
import java.util.logging.ConsoleHandler;
import java.util.logging.Handler;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.reuters.rfa.common.Context;
import com.reuters.rfa.common.DispatchException;
import com.reuters.rfa.common.EventQueue;
import com.reuters.rfa.config.ConfigUtil;
import com.reuters.rfa.session.Session;
import com.thomsonreuters.rfa.valueadd.admin.internal.AdminEventSource;
import com.thomsonreuters.rfa.valueadd.admin.internal.AdminQueueDispatcher;
import com.thomsonreuters.rfa.valueadd.admin.internal.AdminState;
import com.thomsonreuters.rfa.valueadd.util.ValueAddException;
import com.thomsonreuters.rfa.valueadd.util.ValueAddLogger;
import com.thomsonreuters.rfa.valueadd.util.ValueAddMessageKeys;

/**
 * Base class providing common functionality for Consumer, Interactive Provider and NonInteractive Provider core interfaces. 
 * <p> It encapsulate event queue for all response events. If it is configured to have its own dispatching thread, it 
 * starts this thread during initialization, periodically dispatching from the event queue.
 * <p> Optionally, when it is not configured for dispatching thread, it also provides functionality to dispatch
 * event queue in application thread space.
 */
public abstract class AdminCore
{
    AdminEventSource eventSource;
    EventQueue queue;
    AtomicReference<AdminState> state = new AtomicReference<AdminState>(AdminState.NONE);
    Logger adminLogger = Logger.getLogger(ValueAddLogger.LoggerNames.ADMIN_LOGGER);
    private CoreConfig config;
    private Session session;
    private AdminQueueDispatcher queueDispatcher;

    /**
     * Dispatch next event from the event queue in caller's thread of control. Wait for timeOutMillis milliseconds if no event exists.
     * @param timeOutMillis how long (in milliseconds) to wait for an event, or Dispatchable.INFINITE_WAIT or Dispatchable.NO_WAIT.
     * @return The number of events left on the queue after or -1 if the timeout expired and there were no events to be dispatched.
     * @throws DispatchException - Error during dispatching
     * @throws ValueAddException - If core is configured for dispatching in internal thread.
     */
    final public int dispatchEvent(int timeOutMillis) throws DispatchException
    {
        ensureInitializedState();

        if (!config.useInternalThread() && queue != null)
            return queue.dispatch(timeOutMillis);

        throw new ValueAddException(ValueAddMessageKeys.NO_DISPATCH_ALLOWED.format());
    }

    /**
     * 
     * @return Name of admin module core.
     */
    final public String getCoreName()
    {
        return config == null ? null : config.getCoreName();
    }
    
    protected AdminCore()
    {
        adminLogger = Logger.getLogger(ValueAddLogger.LoggerNames.ADMIN_LOGGER);
    }

    void initialize(int eventSourceType, CoreConfig config)
    {
        if(config.getRFAConfigDb() != null)
            Context.initialize(config.getRFAConfigDb());
        else
            Context.initialize();
        
        initRFALogger(config.getRFALogLevel());
        initAdminLogger(config.getAdminLogLevel(), config.getAdminLogFile());
        this.config = config;
        
        if(config.getUseDeprecatedRequestMsgs() == false)
        {
            // prior to acquiring the session, update the provider connection
            // to use the request message type (OMMMsg.MsgType.REQUEST) rather 
            // than the deprecated request message types (see OMMMsg.MsgType).
            ConfigUtil.useDeprecatedRequestMsgs(config.getSessionName(), false);
        }
        
        session = Session.acquire(config.getSessionName());
        if (session == null)
        {
            Context.uninitialize();
            throw new ValueAddException(ValueAddMessageKeys.COULD_NOT_ACQUIRE_SESSION.format());
        }

        eventSource = new AdminEventSource(session, eventSourceType, config);
        queue = EventQueue.create("ValueAdd Response Queue");
        queueDispatcher = new AdminQueueDispatcher("ValueAdd Dispatch Thread", queue,
                config.getDispatchTimeout());

        if (config.useInternalThread())
            start();
    }
    
    void uninitialize()
    {
        ensureInitializedState();

        stop();

        if (queue != null)
            queue.deactivate();
        if (eventSource != null)
            eventSource.cleanup();
        if (session != null)
            session.release();
        ValueAddLogger.cleanup(adminLogger);
        Context.uninitialize();
    }
    
    final protected void ensureInitializedState()
    {
        if (state.get() != AdminState.INITIALIZED)
            throw new ValueAddException(ValueAddMessageKeys.NOT_INITIALIZED.format());
    }

    private void initAdminLogger(Level logLevel, String fileName)
    {
        String logFileName = (fileName != null && fileName.length() != 0 && fileName.compareToIgnoreCase("console") != 0)? fileName:"console";
        ValueAddLogger.initialize(logLevel == null ? Level.INFO : logLevel, logFileName);
    }

    private void initRFALogger(Level logLevel)
    {
        if (logLevel != null)
        {
            // Enable debug logging
            Logger logger = Logger.getLogger("com.reuters.rfa");
            logger.setLevel(logLevel);
            Handler[] handlers = logger.getHandlers();

            if (handlers.length == 0)
            {
                Handler handler = new ConsoleHandler();
                handler.setLevel(logLevel);
                logger.addHandler(handler);
            }

            for (int index = 0; index < handlers.length; index++)
            {
                handlers[index].setLevel(logLevel);
            }
        }
    }

    private void start()
    {
        queueDispatcher.start();
    }

    private void stop()
    {
        if (queueDispatcher != null)
            queueDispatcher.stop(10);
    }
}
