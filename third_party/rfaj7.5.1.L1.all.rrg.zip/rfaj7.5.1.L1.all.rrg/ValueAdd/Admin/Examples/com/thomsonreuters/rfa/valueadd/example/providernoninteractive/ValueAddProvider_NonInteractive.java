package com.thomsonreuters.rfa.valueadd.example.providernoninteractive;

import java.net.InetAddress;
import java.util.logging.Level;

import com.reuters.rfa.common.Context;
import com.reuters.rfa.omm.OMMMsg;
import com.thomsonreuters.rfa.valueadd.admin.ProviderNonInteractiveCore;
import com.thomsonreuters.rfa.valueadd.admin.ProviderNonInteractiveCoreConfig;
import com.thomsonreuters.rfa.valueadd.example.utility.CommandLine;

/**
 * <p>
 * This is a main class to run ValueAddProvider_NonInteractive application.
 * </p>
 * <p>Initializes ProviderNonInteractiveCore with login requests.
 * <p>ProviderNonInteractiveCore dispatches response events in its dispatch thread. ProviderNonInteractiveCore can be configured not to use internal dispatching
 * thread. In this case, application is responsible for dispatches events in its own thread using {@link ProviderNonInteractiveCore#dispatchEvent(int)} interface.  
 * <p>Extends ProviderNonInteractiveCore to handle admin and item events.
 * <p>Cleans up uninitializing ProviderNonInteractiveCore.
 *
 * @see ProviderNonInteractiveExt
 * @see ProviderNonInteractiveEncoder
 * @see DataProvider
 */
public class ValueAddProvider_NonInteractive
{
    DataProvider dataProvider;
    boolean isLoggedIn;
    String className = "ValueAddProvider_NonInteractive";
    ProviderNonInteractiveExt providerNonInteractive; // Extension to value add non interactive provider core to process
                           // login responses
    ProviderNonInteractiveEncoder requestResponseEncoder;

    ValueAddProvider_NonInteractive()
    {
        System.out.println("*****************************************************************************");
        System.out.println("*          Begin Java VA Provider Non-Interactive Demo Program              *");
        System.out.println("*****************************************************************************");
    }

    /**
     * Initializes the non interactive provider application.
     * <p>Creates ProviderNonInteractiveCoreConfig, configures administrative requests - login and initializes ProviderNonInteractiveCore with these admin requests.
     * <p>Creating admin requests and configuring ProviderNonInteractiveCore with these requests is optional.
     * <p>ProviderNonInteractiveCore can be initialized without specifying any admin requests. For example,
     * <p>
     * <code>
     * ProviderNonInteractiveCore provNonInteractiveCore = new ProviderNonInteractiveCore(); <br>
     * provNonInteractiveCore.initialize();<br>
     * </code>
     * OR <br>
     * <code>
     * ProviderNonInteractiveCore provNonInteractiveCore = new ProviderNonInteractiveCore(); <br>
     * ProviderNonInteractiveCoreConfig config = new ProviderNonInteractiveCoreConfig()<br>
     * config.setSessionName(...); <br>
     * provNonInteractiveCore.initialize(config);<br>
     * </code>
     * @see ProviderNonInteractiveCore#initialize()
     * @see ProviderNonInteractiveCore#initialize(ProviderNonInteractiveCoreConfig)
     */
    public void init()
    {
        System.out.println(className + ": Initializing...");
        requestResponseEncoder = new ProviderNonInteractiveEncoder();
        providerNonInteractive = new ProviderNonInteractiveExt(this);
        dataProvider = new DataProvider(this);

        ProviderNonInteractiveCoreConfig config = new ProviderNonInteractiveCoreConfig();
        config.setSessionName(CommandLine.variable("provSession"));
        if(CommandLine.booleanVariable("debug"))
        {
            config.setRFALogLevel(Level.FINE);
            config.setAdminLogLevel(Level.FINE);
            config.setAdminLogFile(CommandLine.variable("logfile"));
        }
        OMMMsg loginReqMsg = requestResponseEncoder
                .encodeLoginRequest(CommandLine.variable("user"), CommandLine.variable("position"),
                                    CommandLine.variable("application"));
        config.setRDMLoginRequest(loginReqMsg);
        requestResponseEncoder.pool.releaseMsg(loginReqMsg);
        providerNonInteractive.initialize(config);
        System.out.println(className + ": Initializing...done");
    }

    /**
     * Cleans up application resources by un-initializing ProviderNonInteractiveCore.
     * <p> Exits the application after cleanup.
     */
    public void cleanup()
    {
        System.out.println(className + ": cleaning up resources....");
        if (dataProvider != null)
            dataProvider.cleanup();
        providerNonInteractive.uninitialize();
        requestResponseEncoder.cleanup();
        System.out.println(className + ": cleaning up resources....done");
        System.exit(0);
    }

    /**
     * Runs the application for specified runTime seconds.
     * Events are dispatched by ProviderNonInteractiveCore in its dispatch thread. 
     * ProviderNonInteractiveCore can be configured not to use internal dispatching thread. 
     * In this case, application is responsible for dispatches events in its own thread using {@link ProviderNonInteractiveCore#dispatchEvent(int)} interface.  
     */
    void run()
    {
        int runTime  = CommandLine.intVariable("runTime");
        // By default, all events are dispatched from value add admin's
        // dispatching thread
        // if application wants to dispatch events in its own thread, configure
        // admin module
        // during initialization to not use dispatching thread to dispatch
        // events.
        // i.e. do coreconfig.useInternalThread(false) in init and use commented
        // out code below.

        // Dispatching by dispatching thread in the value add admin.
        try
        {
            Thread.sleep(runTime * 1000);
        }
        catch (InterruptedException de)
        {
            de.printStackTrace();
        }

        // Dispatching from application thread.
        /*
         * long startTime = System.currentTimeMillis(); while
         * ((System.currentTimeMillis() - startTime) < runTime * 1000) { try {
         * if(providerNonInteractive != null) providerNonInteractive.dispatchEvent(1000); }
         * catch(DispatchException de) { de.printStackTrace(); } }
         */

        System.out.println(Context.string());
        System.out.println(className + ": " + runTime + " seconds elapsed, " + getClass().toString()
                + " exiting");
    }

    // Initializes command line options used by the application
    static void addCommandLineOptions()
    {
        CommandLine.addOption("debug", false, "enable debug tracing");
        CommandLine.addOption("provSession", "RSSLNameSpace::ProviderNonInteractive",
                              "Provider session.  Defaults to RSSLNameSpace::ProviderNonInteractive");
        CommandLine.addOption("itemName", "TRI.N", "List of items to open separated by ','.");
        CommandLine.addOption("serviceName", "NI_PUB",
                           "Service name for the SrcDirectory response.  Defaults to DIRECT_FEED");
        CommandLine.addOption("updateInterval", 5, "Update interval.  Defaults to 5 seconds.");
        CommandLine.addOption("updateRate", 1, "Update rate per interval.  Defaults to 1/interval.");
        CommandLine.addOption("runTime", 600, "Run time of the application.  Defaults to 600 secs.");

        String username = "guest";
        try
        {
            username = System.getProperty("user.name");
        }
        catch (Exception e)
        {
        }
        String defaultPosition = "1.1.1.1/net";
        try
        {
            defaultPosition = InetAddress.getLocalHost().getHostAddress() + "/"
                    + InetAddress.getLocalHost().getHostName();
        }
        catch (Exception e)
        {
        }
        CommandLine.addOption("user", username, "DACS username for login");
        CommandLine.addOption("position", defaultPosition, "DACS position for login");
        CommandLine.addOption("application", "256", "DACS application ID for login");
        CommandLine.addOption("logfile", "console", "Log file for the value add library. Defaults to console");
    }

    public static void main(String argv[])
    {
        addCommandLineOptions();
        CommandLine.setArguments(argv);

        ValueAddProvider_NonInteractive demo = new ValueAddProvider_NonInteractive();
        demo.init();
        demo.run();
        demo.cleanup();
    }
}
