package com.thomsonreuters.rfa.valueadd.example.utility;

import java.lang.reflect.Field;
import java.util.Iterator;

import com.reuters.rfa.omm.OMMAttribInfo;
import com.reuters.rfa.omm.OMMData;
import com.reuters.rfa.omm.OMMElementEntry;
import com.reuters.rfa.omm.OMMElementList;
import com.reuters.rfa.omm.OMMFilterEntry;
import com.reuters.rfa.omm.OMMFilterList;
import com.reuters.rfa.omm.OMMMap;
import com.reuters.rfa.omm.OMMMapEntry;
import com.reuters.rfa.omm.OMMMsg;
import com.reuters.rfa.omm.OMMTypes;
import com.reuters.rfa.omm.OMMVector;
import com.reuters.rfa.omm.OMMVectorEntry;

public final class ExampleUtil
{
    public static void dumpAttribDataElements(OMMAttribInfo ai)
    {
        if (ai.getAttribType() == OMMTypes.NO_DATA)
            return;

        OMMElementList elementList = (OMMElementList)ai.getAttrib();

        for (Iterator<?> iter = elementList.iterator(); iter.hasNext();)
        {
            OMMElementEntry element = (OMMElementEntry)iter.next();
            OMMData data = element.getData(); // Get the data from the
                                              // ElementEntry.
            System.out.println(element.getName() + ": " + data.toString());
        }
    }

    public static void duplicateAttribInfoHeader(OMMAttribInfo srcai, OMMAttribInfo destai)
            throws Exception
    {
        Field[] fields = OMMAttribInfo.class.getDeclaredFields();

        try
        {
            for (int i = 0; i < fields.length; i++)
            {
                Field f = fields[i];
                if (f.getType() != Integer.TYPE)
                    continue;

                int value = f.getInt(null);
                System.out.println(f.getName());

                if (srcai.has(value))
                {
                    System.out.println("--> found " + f.getName());
                    switch (value)
                    {
                        case OMMAttribInfo.HAS_SERVICE_NAME:
                            destai.setServiceName(srcai.getServiceName());
                            break;
                        case OMMAttribInfo.HAS_NAME:
                            destai.setName(srcai.getName());
                            break;
                        case OMMAttribInfo.HAS_NAME_TYPE:
                            destai.setNameType(srcai.getNameType());
                            break;
                        case OMMAttribInfo.HAS_FILTER:
                            destai.setFilter(srcai.getFilter());
                            break;
                        case OMMAttribInfo.HAS_ID:
                            destai.setId(srcai.getId());
                            break;
                        case OMMAttribInfo.HAS_ATTRIB:
                        {
                            System.out.println("ai data pending.....");
                            break;
                        }
                        default:
                            throw new Exception("Missing copy method for AttribInfo flag");
                    }
                }
            }
        }
        catch (IllegalAccessException e)
        {
            e.printStackTrace();
        }
    }

    /*
     * get service name from OMMMsg
     */
    public static String getServiceNameFromOMMMsg(OMMMsg ommMsg)
    {
        String serviceName = null;

        if (ommMsg.has(OMMMsg.HAS_ATTRIB_INFO))
        {
            OMMAttribInfo ai = ommMsg.getAttribInfo();

            if (ai.has(OMMAttribInfo.HAS_SERVICE_NAME))
            {
                serviceName = ai.getServiceName();
            }
        }

        return serviceName;
    }

    public static void dumpCommandArgs()
    {
        // dump command line arguments
        String commandLineString = CommandLine.getConfiguration();

        System.out.println("Input/Default Configuration");
        System.out.println("======================");
        System.out.println(commandLineString);
        System.out.println("======================");
    }

    /*
     * sleep
     */
    public static void slowDown(int duration)
    {
        try
        {
            Thread.sleep(duration);
        }
        catch (InterruptedException e)
        {
            e.printStackTrace();
        }
    }

    public static String mapFlagsString(OMMMap data)
    {
        StringBuilder buf = new StringBuilder(60);

        if (data.has(OMMMap.HAS_DATA_DEFINITIONS))
        {
            buf.append("HAS_DATA_DEFINITIONS");
        }

        if (data.has(OMMMap.HAS_SUMMARY_DATA))
        {
            if (buf.length() != 0)
                buf.append(" | ");

            buf.append("HAS_SUMMARY_DATA");
        }

        if (data.has(OMMMap.HAS_PERMISSION_DATA_PER_ENTRY))
        {
            if (buf.length() != 0)
                buf.append(" | ");

            buf.append("HAS_PERMISSION_DATA_PER_ENTRY");
        }

        if (data.has(OMMMap.HAS_TOTAL_COUNT_HINT))
        {
            if (buf.length() != 0)
                buf.append(" | ");

            buf.append("HAS_TOTAL_COUNT_HINT");
        }

        if (data.has(OMMMap.HAS_KEY_FIELD_ID))
        {
            if (buf.length() != 0)
                buf.append(" | ");

            buf.append("HAS_KEY_FIELD_ID");
        }
        return buf.toString();
    }

    public static String mapEntryFlagsString(OMMMapEntry data)
    {
        StringBuilder buf = new StringBuilder(60);

        if (data.has(OMMMapEntry.HAS_PERMISSION_DATA))
        {
            buf.append("HAS_PERMISSION_DATA");
        }
        return buf.toString();
    }

    public static String vectorFlagsString(OMMVector data)
    {
        StringBuilder buf = new StringBuilder(60);

        if (data.has(OMMVector.HAS_DATA_DEFINITIONS))
        {
            buf.append("HAS_DATA_DEFINITIONS");
        }

        if (data.has(OMMVector.HAS_SUMMARY_DATA))
        {
            if (buf.length() != 0)
                buf.append(" | ");

            buf.append("HAS_SUMMARY_DATA");
        }

        if (data.has(OMMVector.HAS_PERMISSION_DATA_PER_ENTRY))
        {
            if (buf.length() != 0)
                buf.append(" | ");

            buf.append("HAS_PERMISSION_DATA_PER_ENTRY");
        }

        if (data.has(OMMVector.HAS_TOTAL_COUNT_HINT))
        {
            if (buf.length() != 0)
                buf.append(" | ");

            buf.append("HAS_TOTAL_COUNT_HINT");
        }

        if (data.has(OMMVector.HAS_SORT_ACTIONS))
        {
            if (buf.length() != 0)
                buf.append(" | ");

            buf.append("HAS_SORT_ACTIONS");
        }
        return buf.toString();
    }

    public static String filterListFlagsString(OMMFilterList data)
    {
        StringBuilder buf = new StringBuilder(60);

        if (data.has(OMMFilterList.HAS_PERMISSION_DATA_PER_ENTRY))
        {
            buf.append("HAS_PERMISSION_DATA_PER_ENTRY");
        }

        if (data.has(OMMFilterList.HAS_TOTAL_COUNT_HINT))
        {
            if (buf.length() != 0)
                buf.append(" | ");

            buf.append("HAS_TOTAL_COUNT_HINT");
        }
        return buf.toString();
    }

    public static String vectorEntryFlagsString(OMMVectorEntry data)
    {
        StringBuilder buf = new StringBuilder(60);

        if (data.has(OMMVectorEntry.HAS_PERMISSION_DATA))
        {
            buf.append("HAS_PERMISSION_DATA");
        }
        return buf.toString();
    }

    public static String filterEntryFlagsString(OMMFilterEntry data)
    {
        StringBuilder buf = new StringBuilder(60);

        if (data.has(OMMFilterEntry.HAS_PERMISSION_DATA))
        {
            buf.append("HAS_PERMISSION_DATA");
        }
        if (data.has(OMMFilterEntry.HAS_DATA_FORMAT))
        {
            if (buf.length() != 0)
                buf.append(" | ");

            buf.append("HAS_DATA_FORMAT");
        }
        return buf.toString();
    }

    public static boolean isNumeric(String value)
    {
        try
        {
            Integer.parseInt(value);
        }
        catch (NumberFormatException e)
        {
            return false;
        }
        return true;
    }

}
