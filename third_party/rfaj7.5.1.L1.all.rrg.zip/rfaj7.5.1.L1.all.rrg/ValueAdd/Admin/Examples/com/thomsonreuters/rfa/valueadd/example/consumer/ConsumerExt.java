package com.thomsonreuters.rfa.valueadd.example.consumer;

import java.util.Iterator;
import java.util.logging.Logger;

import com.reuters.rfa.common.Event;
import com.reuters.rfa.common.Handle;
import com.reuters.rfa.common.QualityOfService;
import com.reuters.rfa.omm.OMMMsg;
import com.reuters.rfa.rdm.RDMMsgTypes;
import com.reuters.rfa.session.omm.OMMConnectionEvent;
import com.reuters.rfa.session.omm.OMMItemEvent;
import com.thomsonreuters.rfa.valueadd.admin.ConsumerCore;
import com.thomsonreuters.rfa.valueadd.domainrep.rdm.dictionary.RDMDictionaryResponse;
import com.thomsonreuters.rfa.valueadd.domainrep.rdm.dictionary.RDMDictionary;
import com.thomsonreuters.rfa.valueadd.domainrep.rdm.directory.RDMDirectoryResponse;
import com.thomsonreuters.rfa.valueadd.domainrep.rdm.directory.RDMDirectoryResponsePayload;
import com.thomsonreuters.rfa.valueadd.domainrep.rdm.directory.RDMDirectory;
import com.thomsonreuters.rfa.valueadd.domainrep.rdm.directory.Service;
import com.thomsonreuters.rfa.valueadd.domainrep.rdm.login.RDMLoginResponse;
import com.thomsonreuters.rfa.valueadd.example.utility.GenericOMMParser;
import com.thomsonreuters.rfa.valueadd.util.RDMUtil;
import com.thomsonreuters.rfa.valueadd.util.ValueAddException;

/**
 * Implementation for processing of events from {@link ConsumerCore}.
 */
public class ConsumerExt extends ConsumerCore
{
    boolean hasOpenedRequest;
    private ValueAddConsumer consumerApp;

    DictionaryManager dictMgr;
    ItemManager itemManager;
    Logger logger = Logger.getLogger("com.reuters.valueadd.example.consumer");

    public ConsumerExt(ValueAddConsumer consumerApp)
    {
        this.consumerApp = consumerApp;
        dictMgr = new DictionaryManager(consumerApp);
        itemManager = new ItemManager(consumerApp);
    }

    @Override
    // Receive either completion event or non omm item event for admin domain
    // (login, directory, dictionary)
    public void processUnknownEvent(Event event)
    {
        System.out.println("Received event: " + event);
    }

    @Override
    public void processOMMItemEvent(OMMItemEvent ommItemEvent)
    {
        OMMMsg respMsg = ommItemEvent.getMsg();
        if (respMsg.getMsgModelType() == RDMMsgTypes.LOGIN)
        {
            GenericOMMParser.parse(respMsg);
            processLoginResp(respMsg);
        }
        else if (respMsg.getMsgModelType() == RDMMsgTypes.DICTIONARY)
        {
            processDictionary(respMsg, ommItemEvent.getHandle());
        }
        else if (respMsg.getMsgModelType() == RDMMsgTypes.DIRECTORY)
        {
            GenericOMMParser.parse(respMsg);
            processDirectory(respMsg, ommItemEvent.getHandle());
        }
        else
        {
            GenericOMMParser.parse(respMsg);
        }
    }

    @Override
    public void processOMMConnectionEvent(OMMConnectionEvent event)
    {
        System.out.println("OMM Connection event: " + event);
    }

    public void processDirectory(OMMMsg respMsg, Handle handle)
    {
        try
        {
            RDMDirectoryResponse dirResp = new RDMDirectoryResponse(respMsg);
            if (dirResp.hasPayload())
            {
                RDMDirectoryResponsePayload payload = dirResp.getPayload();

                if (payload.hasServiceList())
                {
                    Iterator<Service> serviceIter = payload.getServiceList().iterator();
                    while (serviceIter.hasNext())
                    {
                        Service service = serviceIter.next();
                        if (service.hasInfoFilter())
                        {
                            service.getInfoFilter();
                        }
                        if (service.hasStateFilter())
                        {
                            Service.StateFilter state = service.getStateFilter();
                            if (state.getAcceptingRequests())
                                logger.info("Service: '" + service.getServiceName()
                                        + "' is accepting requests.");
                            else
                                logger.info("Service: '" + service.getServiceName()
                                        + "' is not accepting requests.");
                        }
                    }
                }
            }
        }
        catch (ValueAddException de)
        {
            de.printStackTrace();
        }
    }

    public void processDictionary(OMMMsg respMsg, Handle handle)
    {
        RDMDictionaryResponse dictResp = new RDMDictionaryResponse(respMsg);
        if (dictResp.getMessageType() == RDMDictionaryResponse.MessageType.REFRESH_RESP)
        {
            if (dictResp.getAttrib().getVerbosity() == RDMDictionary.Verbosity.INFO)
            {
                GenericOMMParser.parse(respMsg);
                dictMgr.processDictionaryInfo(dictResp, handle);
            }
            else
            {
                dictMgr.processFullDictionary(dictResp, handle);
            }
        }
    }

    public void sendItemRequest()
    {
        if (!hasOpenedRequest)
        {
            itemManager.sendRequest();
            hasOpenedRequest = true;
        }
    }

    private void processLoginResp(OMMMsg respMsg)
    {
        try
        {
            RDMLoginResponse lresp = new RDMLoginResponse(respMsg);
            if (RDMUtil.isLoginRejected(lresp))
            {
                System.out.println("Login has been denied / rejected / closed.");
                System.out.println("Preparing to clean up and exiting...");
                consumerApp.cleanup(1);
            }
            if (!consumerApp.waitForDictDownload && RDMUtil.isLoginSucessful(lresp))
            {
                // no need to wait for dictionary to be downloaded.
                sendItemRequest();
            }
        }
        catch (ValueAddException de)
        {
            de.printStackTrace();
            consumerApp.cleanup(1);
        }
    }

       // cleanup directory, dictionary, item manager instances.
    public void cleanup()
    {
        if (itemManager != null)
            itemManager.cleanup();

        super.uninitialize();
    }

    void dumpState(Service.StateFilter stateBlock)
    {
        System.out.println("    STATE: ");
        if (stateBlock.hasServiceUp())
            System.out.println("        ServiceState: " + stateBlock.getServiceUp());
        if (stateBlock.hasAcceptingRequests())
            System.out.println("        AcceptingRequests: "
                    + (stateBlock.getAcceptingRequests() ? "Yes" : "No"));
        if (stateBlock.hasStatus())
            System.out.println("        Status:  " + stateBlock.getStatus().toString());
    }

    // Prints data for a single service to stdout
    void dumpInfo(Service.InfoFilter infoBlock)
    {
        System.out.println("Service: " + infoBlock.getServiceName());

        System.out.println("    INFO: ");
        if (infoBlock.hasVendor())
            System.out.println("        Vendor: " + infoBlock.getVendor());
        if (infoBlock.hasIsSource())
            System.out.println("        IsSource: " + (infoBlock.getIsSource() ? "true" : "false"));

        if (infoBlock.hasCapabilityList())
        {
            System.out.println("        Capabilities: ");
            for (RDMDirectory.Capability capability : infoBlock.getCapabilityList())
            {
                dumpCapability(capability);
            }
        }

        if (infoBlock.hasDictionaryProvidedList())
        {
            System.out.println("        DictionariesProvided: ");
            for (String dictProv : infoBlock.getDictionaryProvidedList())
            {
                System.out.println("                " + dictProv);
            }
        }

        if (infoBlock.hasDictionaryUsedList())
        {
            System.out.println("        DictionariesProvided: ");
            for (String dictUsed : infoBlock.getDictionaryUsedList())
            {
                System.out.println("                " + dictUsed);
            }
        }

        if (infoBlock.hasQosList())
        {
            System.out.println("        QoS: ");
            for (QualityOfService qos : infoBlock.getQosList())
            {
                System.out.println("                " + qos.toString());
            }
        }

        if (infoBlock.hasItemList())
            System.out.println("        ItemList: " + infoBlock.getItemList());
    }

    void dumpCapability(RDMDirectory.Capability capability)
    {
        System.out.print("\t\t\t\t");
        System.out.println(capability);
    }
}
