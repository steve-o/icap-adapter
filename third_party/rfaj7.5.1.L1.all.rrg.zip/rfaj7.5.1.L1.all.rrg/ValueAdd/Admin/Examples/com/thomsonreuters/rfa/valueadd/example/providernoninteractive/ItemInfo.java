package com.thomsonreuters.rfa.valueadd.example.providernoninteractive;

import com.reuters.rfa.common.Token;

/**
 * ItemInfo is a class that contains all the relevant information regarding to
 * an item. It is used as the source of canned data for the ValueAddProvider_NonInteractive.
 * 
 */
class ItemInfo
{
    String name;

    double trdPrice = 10.0000;
    double bid = 9.8000;
    double ask = 10.2000;
    long acvol = 100;
    Token token;

    public void setToken(Token t)
    {
        token = t;
    }

    public Token getToken()
    {
        return token;
    }

    public void setName(String name)
    {
        this.name = name;
    }

    public String getName()
    {
        return name;
    }

    public double getTradePrice1()
    {
        return trdPrice;
    }

    public double getBid()
    {
        return bid;
    }

    public double getAsk()
    {
        return ask;
    }

    public long getACVol1()
    {
        return acvol;
    }

    public void increment()
    {
        if ((trdPrice >= 100.0000) || (bid >= 100.0000) || (ask >= 100.0000))
        {
            // reset prices
            trdPrice = 10.0000;
            bid = 9.8000;
            ask = 10.2000;
        }
        else
        {
            trdPrice += 0.0500; // 0.0500
            bid += 0.0500; // 0.0500
            ask += 0.0500; // 0.0500
        }

        if (acvol < 1000000)
            acvol += 50;
        else
            acvol = 100;
    }

}
