package com.thomsonreuters.rfa.valueadd.example.providerinteractive;

import java.util.HashMap;
import java.util.Iterator;

import com.reuters.rfa.common.Event;
import com.reuters.rfa.common.Handle;
import com.reuters.rfa.common.Token;
import com.reuters.rfa.omm.OMMAttribInfo;
import com.reuters.rfa.omm.OMMMsg;
import com.reuters.rfa.omm.OMMPriority;
import com.reuters.rfa.rdm.RDMMsgTypes;
import com.reuters.rfa.session.omm.OMMCmdErrorEvent;
import com.reuters.rfa.session.omm.OMMListenerEvent;
import com.reuters.rfa.session.omm.OMMSolicitedItemEvent;
import com.thomsonreuters.rfa.valueadd.admin.ProviderInteractiveCore;
import com.thomsonreuters.rfa.valueadd.domainrep.rdm.dictionary.RDMDictionaryRequest;
import com.thomsonreuters.rfa.valueadd.domainrep.rdm.directory.RDMDirectoryRequest;
import com.thomsonreuters.rfa.valueadd.domainrep.rdm.login.RDMLoginRequest;
import com.thomsonreuters.rfa.valueadd.example.utility.CommandLine;
import com.thomsonreuters.rfa.valueadd.example.utility.GenericOMMParser;

/**
 * Implementation for processing of events from {@link ProviderInteractiveCore}.
 */
public class ProviderInteractiveExt extends ProviderInteractiveCore
{
    private ValueAddProvider_Interactive providerApp;
    private Handle timerHandle;
    private HashMap<Token, ItemInfo> itemReqTable;
    private int updateInterval, updateRate;
    private String serviceName;

    public ProviderInteractiveExt(ValueAddProvider_Interactive mainApp)
    {
        this.providerApp = mainApp;
        itemReqTable = new HashMap<Token, ItemInfo>();
        readConfiguration();
    }

    protected void readConfiguration()
    {
        updateInterval = CommandLine.intVariable("updateInterval");
        updateRate = CommandLine.intVariable("updateRate");
        serviceName = CommandLine.variable("serviceName");
    }

    @Override
    public void processOMMSolicitedItemEvent(OMMSolicitedItemEvent event)
    {
        OMMMsg msg = event.getMsg();

        switch (msg.getMsgModelType())
        {
            case RDMMsgTypes.LOGIN: // Reuters defined domain message model -
                                    // LOGIN
                processLoginRequest(event);
                break;
            case RDMMsgTypes.DIRECTORY:
                processDirectoryRequest(event); // Reuters defined domain
                                                // message
                                                // model - DIRECTORY
                break;
            case RDMMsgTypes.DICTIONARY:
                processDictionaryRequest(event);// Reuters defined domain
                                                // message
                                                // model - DICTIONARY
                break;
            default: // All other reuters defined domain message model or
                     // customer's
                     // domain message model are considered items.
                processItemRequest(event);
                ;
        }
    }

    @SuppressWarnings("deprecation")
    public void processItemRequest(OMMSolicitedItemEvent itemEvent)
    {
        System.out.println("OMMSolicitedItemEvent received");
        OMMMsg msg = itemEvent.getMsg();
        Token rq = itemEvent.getRequestToken(); // Token is associated for each
                                                // unique request.
        ItemInfo itemInfo = itemReqTable.get(rq); // See if we have an ItemInfo
                                                  // associated with the token.

        Handle hd = itemEvent.getHandle();

        switch (msg.getMsgType())
        {
            case OMMMsg.MsgType.REQUEST:
            {
                boolean refreshRequested = msg.isSet(OMMMsg.Indication.REFRESH);
                String name = msg.getAttribInfo().getName();
                if (itemInfo == null)
                {
                    // New request. Send a REFRESH_RESP regardless of REFRESH indication flag.
                    refreshRequested = true;
                    
                    itemInfo = new ItemInfo();
                    itemInfo.setName(name);
                    if (msg.isSet(OMMMsg.Indication.ATTRIB_INFO_IN_UPDATES))
                        itemInfo.setAttribInUpdates(true);
                    
                    if (msg.isSet(OMMMsg.Indication.NONSTREAMING))
                    {
                        System.out.println();
                        System.out.println("Received non-streaming item request for "
                                + msg.getAttribInfo().getServiceName() + ":" + name);
                    }
                    else
                    {
                        itemInfo.setHandle(itemEvent.getHandle());
                        itemReqTable.put(rq, itemInfo);
                        itemInfo.setPriorityCount(1);
                        itemInfo.setPriorityClass(1);
                        System.out.println();
                        System.out.println("Received item request for "
                                + msg.getAttribInfo().getServiceName() + ":" + name);
                    }
                }
                else
                {
                    // Re-issue request
                    if(msg.isSet(OMMMsg.Indication.NONSTREAMING))
                    {
                        System.out.println("Received non-streaming request on a reissue, ignoring");
                        GenericOMMParser.parse(msg);
                        return;
                    }
                    
                    System.out.println("Received item reissue for "
                            + msg.getAttribInfo().getServiceName() + ":" + name);
                }
                
                GenericOMMParser.parse(msg);
 
                if (msg.has(OMMMsg.HAS_PRIORITY)) // Check if the streaming request
                                                  // has priority.
                {
                    OMMPriority priority = msg.getPriority();
                    itemInfo.setPriorityClass(priority.getPriorityClass());
                    itemInfo.setPriorityCount(priority.getCount());
                }
                
                if(!refreshRequested)
                    return; // no refresh requested, we're finished.
                
                break;
            }
            case OMMMsg.MsgType.STREAMING_REQ:
            case OMMMsg.MsgType.NONSTREAMING_REQ:
            case OMMMsg.MsgType.PRIORITY_REQ:
                System.out.println("Received deprecated message type of "
                        + OMMMsg.MsgType.toString(msg.getMsgType())
                        + ", not supported. ");
                return;
            case OMMMsg.MsgType.CLOSE_REQ:
            {
                itemInfo = itemReqTable.get(rq);
                if (itemInfo != null)
                    System.out.println("Item close request: " + itemInfo.getName());
                itemReqTable.remove(rq);
                if (itemReqTable.isEmpty())
                    unRegisterTimer(timerHandle);
                return;
            }
            case OMMMsg.MsgType.GENERIC:
                System.out.println("Received generic message type, not supported. ");
                return;
            case OMMMsg.MsgType.POST:
                System.out.println("Received post message type, not supported. ");
                return;
            default:
                System.out.println("ERROR: Received unexpected message type. " + msg.getMsgType());
                return;
        }

        // This section is similar to sendUpdates() function, with additional
        // fields. Please see sendUpdates for detailed description.
        if (msg.getMsgModelType() == RDMMsgTypes.MARKET_PRICE)
        {

            OMMMsg marketPriceMsg = providerApp.providerInteractiveEncoder.encodeMarketPriceImage(msg, hd,
                                                                                   itemInfo);
            if (submitMsg(itemEvent.getRequestToken(), marketPriceMsg, null) > 0)
            {
                System.out.println("Reply sent");
            }
            else
            {
                System.err.println("Trying to submit for an item with an inactive handle.");
                itemReqTable.remove(rq); // removes the reference to the Token
                                         // associated for the item and its
                                         // ItemInfo.
            }
            providerApp.providerInteractiveEncoder.pool.releaseMsg(marketPriceMsg);
            if (itemReqTable.size() == 1)
                registerTimer();

        }
        else
        {
            System.out.println("Request other than MARKET_PRICE");
            System.out.println("Currently, OMMProviderDemo supports MARKET_PRICE only");
        }
    }

    @SuppressWarnings("deprecation")
    public void processDictionaryRequest(OMMSolicitedItemEvent itemEvent)
    {
        OMMMsg reqMsg = itemEvent.getMsg();
        GenericOMMParser.parse(reqMsg);
        RDMDictionaryRequest dictReq = new RDMDictionaryRequest(reqMsg);
        Token dictToken = itemEvent.getRequestToken();
        // OMMAttribInfo will be in the streaming and nonstreaming request.
        switch (dictReq.getMessageType())
        {
            case REQUEST:
                System.out.println("Dictionary request received");
                break;
            case STREAMING_REQUEST:
            case NON_STREAMING_REQUEST:
            case PRIORITY_REQUEST:
                System.out.println("Received deprecated message type of "
                        + dictReq.getMessageType().toString() + " for dictionary, not supported. ");
                return;

            case CLOSE_REQUEST:
                // RFA internally will clean up the item.
                // Application has placed the directory on its item info lookup
                // table, so no cleanup is needed here.
                System.out.println("dictionary close request");
                return;
            case GENERIC:
                System.out.println("Received generic message type, not supported. ");
                return;
            default:
                System.out.println("ERROR: Received unexpected message type. "
                        + dictReq.getMessageType());
                return;
        }

        OMMMsg dictResp = providerApp.providerInteractiveEncoder.encodeDictionaryImage(dictReq,
                                                                        providerApp.dictCache);
        if (submitMsg(dictToken, dictResp, null) == 0)
            System.err.println("Trying to submit for an item with an inactive handle.");
        
        providerApp.providerInteractiveEncoder.pool.releaseMsg(dictResp);
    }

    @SuppressWarnings("deprecation")
    public void processDirectoryRequest(OMMSolicitedItemEvent itemEvent)
    {
        OMMMsg reqMsg = itemEvent.getMsg();
        RDMDirectoryRequest dirReq = new RDMDirectoryRequest(reqMsg);
        Token dirToken = itemEvent.getRequestToken();

        switch (dirReq.getMessageType())
        {
            case REQUEST:
            {
                OMMMsg dirRespMsg = providerApp.providerInteractiveEncoder
                        .encodeDirectoryImage(serviceName, dirReq);
                if (submitMsg(dirToken, dirRespMsg, null) > 0)
                    System.out.println("Directory reply sent");
                else
                    System.err.println("Trying to submit for an item with an inactive handle.");
                providerApp.providerInteractiveEncoder.pool.releaseMsg(dirRespMsg);
                return;
            }
            case STREAMING_REQUEST:
            case NON_STREAMING_REQUEST:
            case PRIORITY_REQUEST:
                System.out.println("Received deprecated message type of "
                        + dirReq.getMessageType().toString() + " for directory, not supported. ");
                return;
            case CLOSE_REQUEST:
                // RFA internally will clean up the item.
                // Application has placed the directory on its item info lookup
                // table, so no cleanup is needed here.
                System.out.println("Directory close request");
                return;
            case GENERIC:
                System.out.println("Received generic message type, not supported. ");
                return;
            default:
                System.out.println("ERROR: Received unexpected message type. "
                        + dirReq.getMessageType());
                return;
        }
    }

    @SuppressWarnings("deprecation")
    public void processLoginRequest(OMMSolicitedItemEvent itemEvent)
    {
        RDMLoginRequest loginReq = new RDMLoginRequest(itemEvent.getMsg());
        OMMAttribInfo ommLoginAI = itemEvent.getMsg().getAttribInfo();
        Token loginToken = itemEvent.getRequestToken();
        switch (loginReq.getMessageType())
        {

            case REQUEST:
            {
                System.out.println("Login request received");

                // note that this application does not keep track of login
                // requests,
                // so it does not differentiate between a new request and a
                // reissue.

                // assumes attribInfo is present in login request message.
                OMMMsg loginRespMsg = providerApp.providerInteractiveEncoder
                        .encodeLoginImage(ommLoginAI);
                if (submitMsg(loginToken, loginRespMsg, null) == 0)
                {
                    System.err
                            .println("Trying to submit for an Login response msg with an inactive handle/");
                }
                providerApp.providerInteractiveEncoder.pool.releaseMsg(loginRespMsg);
                return;
            }
            case STREAMING_REQUEST:
            case PRIORITY_REQUEST:
                System.out.println("Received deprecated message type of "
                        + loginReq.getMessageType().toString() + " for login, not supported. ");
                return;
            case CLOSE_REQUEST:
                // Closing the Login stream should cause items associated with
                // that login to be closed. Consumer application does not
                // have to send closes for individual items if the application
                // is also closing the login.
                // Current, the application does not have the association
                // between the login handle and the Token for that login.
                System.out.println("Logout received");
                return;
            case GENERIC:
                System.out.println("Received generic message type, not supported. ");
                return;
            default:
                System.out.println("ERROR: Received unexpected message type. "
                        + loginReq.getMessageType());
                return;
        }

    }

    @Override
    // Called by super class when event that is not client disconnect or
    // solicited request is received e.g. timer event
    public void processUnknownEvent(Event event)
    {
        if (event.getType() == Event.TIMER_EVENT)
            sendUpdates();
        else
            System.out.println("Received event: " + event);
    }

    private void sendUpdates()
    {
        ItemInfo itemInfo = null;

        Iterator<Token> iter = itemReqTable.keySet().iterator();
        while (iter.hasNext())
        {
            Token rq = iter.next();
            itemInfo = itemReqTable.get(rq);
            if (itemInfo == null || itemInfo.isPaused()) // Do not send update
                                                         // for the paused item.
                continue;

            for (int i = 0; i < updateRate; i++)
            {
                itemInfo.increment(); // increment the canned data information
                                      // for this item.

                OMMMsg updateMsg = providerApp.providerInteractiveEncoder.encodeMarketPriceUpdate(serviceName,
                                                                                   itemInfo);
                // Note the closure of the submit is null. Any closure set by
                // the application must be long lived memory.
                if (submitMsg(rq, updateMsg, null) == 0)
                {
                    System.err.println("Trying to submit for an item with an inactive handle.");
                    iter.remove();
                    break; // break out the for loop to get next request token
                }

                providerApp.providerInteractiveEncoder.pool.releaseMsg(updateMsg);
            }
        }
    }

    private void registerTimer()
    {
        if (timerHandle == null)
        {
            timerHandle = registerTimer(updateInterval * 1000, true, true, null);
        }
    }

    @Override
    public void processOMMCmdErrorEvent(OMMCmdErrorEvent errorEvent)
    {
        System.out.println("Received OMMCmd ERROR EVENT for id: " + errorEvent.getCmdID() + "  "
                + errorEvent.getStatus().getStatusText());

    }

    @Override
    public void processOMMListenerEvent(OMMListenerEvent listenerEvent)
    {
        System.out.print("Received OMM LISTENER EVENT: " + listenerEvent.getListenerName());
        System.out.println("  " + listenerEvent.getStatus().toString());
    }

    public void cleanup()
    {
        super.uninitialize();
    }
}
