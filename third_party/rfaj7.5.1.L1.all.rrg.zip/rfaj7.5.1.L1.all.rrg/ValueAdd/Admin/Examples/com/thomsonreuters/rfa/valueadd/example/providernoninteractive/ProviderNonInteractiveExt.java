package com.thomsonreuters.rfa.valueadd.example.providernoninteractive;

import com.reuters.rfa.common.Event;
import com.reuters.rfa.omm.OMMMsg;
import com.reuters.rfa.rdm.RDMMsgTypes;
import com.reuters.rfa.session.omm.OMMCmdErrorEvent;
import com.reuters.rfa.session.omm.OMMConnectionEvent;
import com.reuters.rfa.session.omm.OMMItemEvent;
import com.thomsonreuters.rfa.valueadd.admin.ProviderNonInteractiveCore;
import com.thomsonreuters.rfa.valueadd.domainrep.rdm.login.RDMLoginResponse;
import com.thomsonreuters.rfa.valueadd.example.utility.GenericOMMParser;
import com.thomsonreuters.rfa.valueadd.util.RDMUtil;

/**
 * Implementation for processing of events from {@link ProviderNonInteractiveCore}.
 */
public class ProviderNonInteractiveExt extends ProviderNonInteractiveCore
{
    ValueAddProvider_NonInteractive niProviderApp;
    private boolean isLoggedIn;

    ProviderNonInteractiveExt(ValueAddProvider_NonInteractive niProviderApp)
    {
        this.niProviderApp = niProviderApp;
    }

    @Override
    // Called by admin module when non-command error event is received or when
    // for events, received in response to login
    // request, non omm item event or completion event is received.
    public void processUnknownEvent(Event event)
    {
        if (event.getType() == Event.TIMER_EVENT)
        {
            if (niProviderApp.dataProvider != null)
                niProviderApp.dataProvider.sendUpdates();
        }
        else
        {
            System.out.println("Received event: " + event);
        }
    }

    @Override
    public void processOMMCmdErrorEvent(OMMCmdErrorEvent event)
    {
        System.out.println("CMD Error:" + event);
    }
    
    @Override
    public void processOMMConnectionEvent(OMMConnectionEvent event)
    {
        System.out.println("OMM Connection event: " + event);
    }

    @Override
    public void processOMMItemEvent(OMMItemEvent ommItemEvent)
    {
        OMMMsg respMsg = ommItemEvent.getMsg();
        if (respMsg.getMsgModelType() == RDMMsgTypes.LOGIN)
        {
            GenericOMMParser.parse(respMsg);
            processLoginResp(respMsg);
        }
        else
        {
            GenericOMMParser.parse(respMsg);
        }
    }

    private void processLoginResp(OMMMsg respMsg)
    {
        RDMLoginResponse loginResp = new RDMLoginResponse(respMsg);
        if (RDMUtil.isLoginSucessful(loginResp))
        {
            if (!isLoggedIn)
            {
                System.out.println("login successful...");
                niProviderApp.dataProvider.processLoginSuccessful();
                isLoggedIn = true;
            }
        }
        else
        {
            if (isLoggedIn)
            {
                System.out.println("Login is failed.  Stop publishing until relogin successful.");
                if (niProviderApp.dataProvider != null)
                    niProviderApp.dataProvider.processLoginFail();
                isLoggedIn = false;
            }
        }
    }
}
