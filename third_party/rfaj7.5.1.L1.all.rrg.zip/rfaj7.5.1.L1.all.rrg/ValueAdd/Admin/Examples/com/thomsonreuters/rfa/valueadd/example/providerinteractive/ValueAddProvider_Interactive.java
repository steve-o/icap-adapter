package com.thomsonreuters.rfa.valueadd.example.providerinteractive;

import java.util.logging.Level;

import com.reuters.rfa.common.Context;
import com.reuters.rfa.dictionary.DictionaryException;
import com.thomsonreuters.rfa.valueadd.admin.ClientSessionTreatment;
import com.thomsonreuters.rfa.valueadd.admin.ProviderInteractiveCore;
import com.thomsonreuters.rfa.valueadd.admin.ProviderInteractiveCoreConfig;
import com.thomsonreuters.rfa.valueadd.domainrep.rdm.dictionary.RDMDictionaryCache;
import com.thomsonreuters.rfa.valueadd.domainrep.rdm.dictionary.RDMDictionary;
import com.thomsonreuters.rfa.valueadd.example.utility.CommandLine;

/**
 * <p>
 * This is a main class to run ValueAddProvider_Interactive application.
 * <p>Initializes ProviderInteractiveCore by opening listening socket for client sessions and optionally register interest for OMM command errors.
 * <p>ProviderInteractiveCore dispatches response events in its dispatch thread. ProviderInteractiveCore can be configured not to use internal dispatching
 * thread. In this case, application is responsible for dispatches events in its own thread using {@link ProviderInteractiveCore#dispatchEvent(int)} interface.  
 * <p>Extends ProviderInteractiveCore to handle admin and item events.
 * <p>Cleans up uninitializing ProviderInteractiveCore.
 *
 * @see ProviderInteractiveExt
 * @see ProviderInteractiveEncoder
 */
public class ValueAddProvider_Interactive
{
    RDMDictionaryCache dictCache = new RDMDictionaryCache();

    ProviderInteractiveExt providerInteractive;
    ProviderInteractiveEncoder providerInteractiveEncoder;
    private String className = getClass().getSimpleName();

    public ValueAddProvider_Interactive()
    {
        System.out.println("*****************************************************************************");
        System.out.println("*          Begin Java VA Provider Interactive Application                   *");
        System.out.println("*****************************************************************************");
    }

    /**
     * Initializes the interactive provider application.
     * <p>Creates ProviderInteractiveCoreConfig, configures administrative requests for listener events, cmd errors
     * <p>Initializes ProviderInteractiveCore with these admin requests.
     * <p>Creating admin requests and configuring ProviderInteractiveCore with these requests is optional.
     * <p>ProviderInteractiveCore can be initialized without specifying any admin requests. For example,
     * <p>
     * <code>
     * ProviderInteractiveCore providerInteractiveCore = new ProviderInteractiveCore(); <br>
     * providerInteractiveCore.initialize();<br>
     * </code>
     * OR <br>
     * <code>
     * ProviderInteractiveCore providerInteractiveCore = new ProviderInteractiveCore(); <br>
     * ProviderInteractiveCoreConfig config = new ProviderInteractiveCoreConfig()<br>
     * config.setSessionName(...); <br>
     * providerInteractiveCore.initialize(config);<br>
     * </code>
     * @see ProviderInteractiveCore#initialize()
     * @see ProviderInteractiveCore#initialize(ProviderInteractiveCoreConfig)
     */
    public void init()
    {
        System.out.println(className + ": Initializing...");
        providerInteractiveEncoder = new ProviderInteractiveEncoder();
        providerInteractive = new ProviderInteractiveExt(this);
        loadDictionary();
        ProviderInteractiveCoreConfig config = new ProviderInteractiveCoreConfig();
        config.setSessionName(CommandLine.variable("provSession"));
        config.setUseDeprecatedRequestMsgs(false); // don't use deprecated request MessageTypes.
        if(CommandLine.booleanVariable("debug"))
        {
            config.setRFALogLevel(Level.FINE);
            config.setAdminLogLevel(Level.FINE);
            config.setAdminLogFile(CommandLine.variable("logfile"));
        }
        providerInteractive.initialize(config);

        // let provider admin module handle client sessions
        providerInteractive.setClientSessionTreatment(CommandLine.booleanVariable("acceptSession") ? ClientSessionTreatment.ACCEPT
                                                : ClientSessionTreatment.REJECT, null);
        System.out.println(className + ": Initialization complete, waiting for client sessions");
    }
    
    private void loadDictionary()
    {
        try
        {
            dictCache.load(CommandLine.variable("rdmFieldDictionary"),
                           RDMDictionary.DictionaryType.RWFFLD);
            dictCache.load(CommandLine.variable("enumType"),
                           RDMDictionary.DictionaryType.RWFENUM);
        }
        catch (DictionaryException e)
        {
            System.out.println(className + ": dictionary read error: " + e.getMessage());
            if (e.getCause() != null)
                System.err.println(": " + e.getCause().getMessage());
            System.exit(-1);
        }
    }

    /**
     * Runs the application for specified runTime seconds.
     * Events are dispatched by ProviderInteractiveCore in its dispatch thread. 
     * ProviderInteractiveCore can be configured not to use internal dispatching thread. 
     * In this case, application is responsible for dispatches events in its own thread using {@link ProviderInteractiveCore#dispatchEvent(int)} interface.  
     */
    public void run()
    {
        int runTime = CommandLine.intVariable("runTime");
        // By default, all events/request messages from provider app are
        // dispatched from value add admin's dispatching thread
        // if application wants to dispatch events in its own thread, configure
        // admin module
        // during initialization to not use dispatching thread to dispatch
        // events.
        // i.e. do coreconfig.useInternalThread(false) in init and use commented
        // out code below.

        // Dispatching by dispatching thread in the value add admin.
        try
        {
            Thread.sleep(runTime * 1000);
        }
        catch (InterruptedException de)
        {
            de.printStackTrace();
        }

        // Dispatching from application thread.
        /*
         * long startTime = System.currentTimeMillis(); while
         * ((System.currentTimeMillis() - startTime) < runTime * 1000) { try {
         * if(providerInteractive != null) providerInteractive.dispatchEvent(1000); }
         * catch(DispatchException de) { de.printStackTrace(); } }
         */

        System.out.println(Context.string());
        System.out.println(className + ": " + runTime + " seconds elapsed, " + getClass().toString()
                + " exiting");
    }

    /**
     * Cleans up application resources by un-initializing ProviderInteractiveCore.
     * <p> Exits the application after cleanup.
     */
    public void cleanup()
    {
        System.out.println(className + ": Cleaning up resources....");
        providerInteractive.cleanup();
        providerInteractiveEncoder.cleanup();
        System.out.println(className + ": Cleaning up resources....done");
        System.exit(0);
    }

    static void addCommandLineOptions()
    {
        CommandLine.addOption("debug", false, "enable debug tracing");
        CommandLine.addOption("provSession", "RSSLNameSpace::ProviderInterative",
                              "Provider session.  Defaults to RSSLNameSpace::ProviderInterative");
        CommandLine.addOption("listenerName", "",
                           "Unique name that specifies a connection to listen.  Defaults to \"\" ");
        CommandLine.addOption("serviceName", "DIRECT_FEED",
                           "Service name for the SrcDirectory response.  Defaults to DIRECT_FEED");
        CommandLine.addOption("rdmFieldDictionary", "etc/RDM/RDMFieldDictionary",
                           "RDMField dictionary name and location.  Defaults to etc/RDM/RDMFieldDictionary");
        CommandLine.addOption("enumType", "etc/RDM/enumtype.def",
                           "RDMEnum dictionary name and location.  Defaults to etc/RDM/enumtype.def");
        CommandLine.addOption("acceptSession", "true",
                              "Accept all client sessions?. Defaults to true");
        CommandLine.addOption("updateInterval", 1, "Update interval.  Defaults to 1 seconds.");
        CommandLine.addOption("updateRate", 2,
                              "Update rate per interval.  Defaults to 2 update /interval.");
        CommandLine.addOption("runTime", 600, "Run time of the application.  Defaults to 600 secs.");
        CommandLine.addOption("logfile", "console", "Log file for the value add library. Defaults to console");
    }

    public static void main(String argv[])
    {
        addCommandLineOptions();
        CommandLine.setArguments(argv);

        ValueAddProvider_Interactive demo = new ValueAddProvider_Interactive();

        // Defaults the run time of the application to 600.
        demo.init();
        demo.run();
        demo.cleanup();
    }
}
