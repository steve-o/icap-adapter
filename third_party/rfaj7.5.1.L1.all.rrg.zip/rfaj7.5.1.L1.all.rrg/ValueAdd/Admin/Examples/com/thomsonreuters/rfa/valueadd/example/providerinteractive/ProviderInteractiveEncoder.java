package com.thomsonreuters.rfa.valueadd.example.providerinteractive;

import java.util.EnumSet;

import com.reuters.rfa.common.Handle;
import com.reuters.rfa.common.QualityOfService;
import com.reuters.rfa.omm.OMMAttribInfo;
import com.reuters.rfa.omm.OMMEncoder;
import com.reuters.rfa.omm.OMMFieldList;
import com.reuters.rfa.omm.OMMMsg;
import com.reuters.rfa.omm.OMMNumeric;
import com.reuters.rfa.omm.OMMPool;
import com.reuters.rfa.omm.OMMState;
import com.reuters.rfa.omm.OMMTypes;
import com.reuters.rfa.rdm.RDMInstrument;
import com.reuters.rfa.rdm.RDMMsgTypes;
import com.thomsonreuters.rfa.valueadd.domainrep.ResponseStatus;
import com.thomsonreuters.rfa.valueadd.domainrep.rdm.dictionary.RDMDictionaryCache;
import com.thomsonreuters.rfa.valueadd.domainrep.rdm.dictionary.RDMDictionaryRequest;
import com.thomsonreuters.rfa.valueadd.domainrep.rdm.dictionary.RDMDictionaryRequestAttrib;
import com.thomsonreuters.rfa.valueadd.domainrep.rdm.dictionary.RDMDictionaryResponse;
import com.thomsonreuters.rfa.valueadd.domainrep.rdm.dictionary.RDMDictionaryResponseAttrib;
import com.thomsonreuters.rfa.valueadd.domainrep.rdm.dictionary.RDMDictionaryResponsePayload;
import com.thomsonreuters.rfa.valueadd.domainrep.rdm.dictionary.RDMDictionary;
import com.thomsonreuters.rfa.valueadd.domainrep.rdm.directory.RDMDirectoryRequest;
import com.thomsonreuters.rfa.valueadd.domainrep.rdm.directory.RDMDirectoryRequestAttrib;
import com.thomsonreuters.rfa.valueadd.domainrep.rdm.directory.RDMDirectoryResponse;
import com.thomsonreuters.rfa.valueadd.domainrep.rdm.directory.RDMDirectoryResponseAttrib;
import com.thomsonreuters.rfa.valueadd.domainrep.rdm.directory.RDMDirectoryResponsePayload;
import com.thomsonreuters.rfa.valueadd.domainrep.rdm.directory.RDMDirectory;
import com.thomsonreuters.rfa.valueadd.domainrep.rdm.directory.Service;
import com.thomsonreuters.rfa.valueadd.domainrep.rdm.login.RDMLoginResponse;
import com.thomsonreuters.rfa.valueadd.domainrep.rdm.login.RDMLoginResponseAttrib;
import com.thomsonreuters.rfa.valueadd.example.utility.Rounding;


/**
 * Utility class for encoding login refresh, directory refresh, dictionary refresh, market price update and market price refresh
 * messages.
 */
public class ProviderInteractiveEncoder
{
    OMMPool pool;
    private OMMEncoder encoder;

    public ProviderInteractiveEncoder()
    {
        this.pool = OMMPool.create();
        encoder = pool.acquireEncoder();
        encoder.initialize(OMMTypes.MSG, 2000);
    }

    public OMMMsg encodeLoginImage(OMMAttribInfo loginAttribInfo)
    {
        RDMLoginResponse loginRespMsg = new RDMLoginResponse();

        loginRespMsg.setMessageType(RDMLoginResponse.MessageType.REFRESH_RESP);
        RDMLoginResponseAttrib loginRespAttribInfo = new RDMLoginResponseAttrib(loginAttribInfo);
        loginRespMsg.setAttrib(loginRespAttribInfo);
        loginRespMsg.setIndicationMask(EnumSet.of(RDMLoginResponse.IndicationMask.REFRESH_COMPLETE));
        loginRespMsg.setRespStatus(new ResponseStatus(OMMState.Stream.OPEN, OMMState.Data.OK, OMMState.Code.NONE,"login accepted"));
        loginRespMsg.setIsRefreshSolicited(true);

        return loginRespMsg.getMsg(pool);
    }

    public OMMMsg encodeDirectoryImage(String serviceName, RDMDirectoryRequest dirReq)
    {
        RDMDirectoryResponse dirResp = new RDMDirectoryResponse();
        RDMDirectoryResponsePayload payload = new RDMDirectoryResponsePayload();
        dirResp.setPayload(payload);
        dirResp.setMessageType(RDMDirectoryResponse.MessageType.REFRESH_RESP);
        byte streamState;
        if (dirReq.getIndicationMask().contains(RDMDirectoryRequest.IndicationMask.NONSTREAMING))
            // Stream state could be OPEN or NONSTREAMING for a non-streaming request
            streamState = OMMState.Stream.NONSTREAMING; 
        else
            streamState = OMMState.Stream.OPEN;
        dirResp.setResponseStatus(new ResponseStatus(streamState, OMMState.Data.OK, OMMState.Code.NONE,""));
        dirResp.setIndicationMask(EnumSet.of(RDMDirectoryResponse.IndicationMask.REFRESH_COMPLETE));
        dirResp.setIsRefreshSolicited(true);

        RDMDirectoryRequestAttrib dirReqAI = dirReq.getAttrib();

        RDMDirectory.ServiceList list = new RDMDirectory.ServiceList();

        dirResp.getPayload().setServiceList(list);

        Service.StateFilter upstate = new Service.StateFilter(true);
        upstate.setAcceptingRequests(true);
        upstate.setStatus(new ResponseStatus(OMMState.Stream.OPEN, OMMState.Data.OK,
                OMMState.Code.NONE, ""));

        Service.StateFilter downstate = new Service.StateFilter(true);
        downstate.setAcceptingRequests(false);
        downstate.setStatus(new ResponseStatus(OMMState.Stream.OPEN, OMMState.Data.OK,
                OMMState.Code.NONE, ""));

        // DF_ONE
        Service service2 = populateServiceResp("DF_ONE", dirReq, downstate);
        service2.setServiceName("DF_ONE");
        service2.setAction(RDMDirectory.ServiceAction.ADD);
        list.add(service2);

        // direct_feed
        Service service = populateServiceResp(serviceName, dirReq, upstate);
        service.setServiceName(serviceName);
        service.setAction(RDMDirectory.ServiceAction.ADD);
        list.add(service);

        RDMDirectoryResponseAttrib dirRespAI = new RDMDirectoryResponseAttrib();
        dirRespAI.setFilterMask(dirReqAI.getFilterMask());
        dirResp.setAttrib(dirRespAI);

        return dirResp.getMsg(pool);
    }

    private Service populateServiceResp(String svcName, RDMDirectoryRequest dirReq,
            Service.StateFilter state)
    {
        Service service = new Service();
        
        RDMDirectoryRequestAttrib dirReqAI = dirReq.getAttrib();
        // Only encode the service info if the application had asked for the
        // information.
        if (dirReqAI.getFilterMask().contains(RDMDirectory.FilterMask.INFO))
        {
            Service.InfoFilter info = new Service.InfoFilter(svcName);
            info.setFilterAction(RDMDirectory.FilterAction.SET);
            info.setVendor("Reuters");
            info.setIsSource(true);
            RDMDirectory.CapabilityList capabilityList = new RDMDirectory.CapabilityList();
            capabilityList.add(RDMDirectory.Capability.DICTIONARY);
            capabilityList.add(RDMDirectory.Capability.MARKET_PRICE);
            info.setCapabilityList(capabilityList);

            RDMDirectory.DictionaryProvidedList dictProv = new RDMDirectory.DictionaryProvidedList();
            dictProv.add("RWFFld");
            dictProv.add("RWFEnum");

            info.setDictionaryProvidedList(dictProv);

            RDMDirectory.DictionaryUsedList dictUsed = new RDMDirectory.DictionaryUsedList();
            dictUsed.add("RWFFld");
            dictUsed.add("RWFEnum");

            info.setDictionaryUsedList(dictUsed);

            RDMDirectory.QosList qos = new RDMDirectory.QosList();
            qos.add(QualityOfService.QOS_REALTIME_TICK_BY_TICK);
            info.setQosList(qos);

            service.setInfoFilter(info);
        }

        // Only encode the service state information if the application had
        // asked for the information.
        if (dirReqAI.getFilterMask().contains(RDMDirectory.FilterMask.STATE))
        {
            service.setStateFilter(state);
        }

        return service;
    }

    public OMMMsg encodeDictionaryImage(RDMDictionaryRequest dictReq, RDMDictionaryCache dictCache)
    {
        byte streamState = OMMState.Stream.OPEN;
        if (dictReq.getIndicationMask().contains(RDMDictionaryRequest.IndicationMask.NONSTREAMING))
            streamState = OMMState.Stream.NONSTREAMING; // Stream state could be
                                                        // OPEN or NONSTREAMING
                                                        // for non-streaming
                                                        // request.
        else
            streamState = OMMState.Stream.OPEN;
        RDMDictionaryRequestAttrib dictReqAI = dictReq.getAttrib();
        String name = dictReqAI.getDictionaryName();
        RDMDictionaryResponse dictResp = new RDMDictionaryResponse();
        RDMDictionaryResponseAttrib dictAttribInfo = new RDMDictionaryResponseAttrib();
        dictAttribInfo.setVerbosity(dictReqAI.getVerbosity());
        dictAttribInfo.setDictionaryName(dictReqAI.getDictionaryName());
        if(dictReqAI.hasServiceId())
            dictAttribInfo.setServiceId(dictReqAI.getServiceId());
        else if(dictReqAI.hasServiceName())
            dictAttribInfo.setServiceName(dictReqAI.getServiceName());
        dictResp.setAttrib(dictAttribInfo);
        RDMDictionaryResponsePayload payload = null;
        if (name.equalsIgnoreCase("rwffld"))
        {
            payload = dictCache.getDictionary(pool, RDMDictionary.DictionaryType.RWFFLD);

        }
        else
        {
            payload = dictCache.getDictionary(pool, RDMDictionary.DictionaryType.RWFENUM);
        }
        dictResp.setPayload(payload);
        dictResp.setMessageType(RDMDictionaryResponse.MessageType.REFRESH_RESP);
        dictResp.setResponseStatus(new ResponseStatus(streamState, OMMState.Data.OK, OMMState.Code.NONE,""));
        dictResp.setIndicationMask(EnumSet.of(RDMDictionaryResponse.IndicationMask.REFRESH_COMPLETE));
        dictResp.setIsRefreshSolicited(true);
        return dictResp.getMsg(pool);
    }

    public OMMMsg encodeMarketPriceUpdate(String serviceName, ItemInfo itemInfo)
    {
        encoder.initialize(OMMTypes.MSG, 500); // The size is an
                                               // estimate. The size
                                               // MUST be large enough
                                               // for the entire
                                               // message.
                                               // If size is not large
                                               // enough, RFA will throw
                                               // out exception related
                                               // to buffer usage.
        OMMMsg outmsg = pool.acquireMsg();
        outmsg.setMsgType(OMMMsg.MsgType.UPDATE_RESP); // Set the
                                                       // message type
                                                       // to be an
                                                       // update
                                                       // response.
        outmsg.setMsgModelType(RDMMsgTypes.MARKET_PRICE);
        outmsg.setIndicationFlags(OMMMsg.Indication.DO_NOT_CONFLATE);
        outmsg.setRespTypeNum(RDMInstrument.Update.QUOTE);

        Handle hd = itemInfo.getHandle();

        // pass version info
        if (hd != null)
        {
            outmsg.setAssociatedMetaInfo(hd);
        }

        if (itemInfo.getAttribInUpdates()) // check if the original
                                           // request for this item
                                           // asked for attrib info to
                                           // be included in the
                                           // updates.
        {
            outmsg.setAttribInfo(serviceName, itemInfo.getName(), RDMInstrument.NameType.RIC);

            // Initialize message encoding with the update response
            // message.
            // No data is contained in the OMMAttribInfo, so use NO_DATA
            // for the data type of OMMAttribInfo
            // There will be data encoded to the update response message
            // (and we know it is FieldList), so
            // use FIELD_List for the data type of the update response
            // message.
            encoder.encodeMsgInit(outmsg, OMMTypes.NO_DATA, OMMTypes.FIELD_LIST);
        }
        else
            // Since no attribInfo is requested in the updates, don't
            // set attribInfo into the update response message.
            // No OMMAttribInfo in the message defaults to NO_DATA for
            // OMMAttribInfo.
            // There will be data encoded to the update response message
            // (and we know it is FieldList), so
            // use FIELD_List for the data type of the update response
            // message.
            encoder.encodeMsgInit(outmsg, OMMTypes.NO_DATA, OMMTypes.FIELD_LIST);

        // Initialize the field list encoding.
        // Specifies that this field list has only standard data (data
        // that is not defined in a DataDefinition)
        // DictionaryId is set to 0. This means the data encoded in this
        // message used dictionary identified by id equal to 0.
        // Field list number is set to 1. This identifies the field list
        // (in case for caching in the application or downstream
        // components).
        // Data definition id is set to 0 since standard data does not
        // use data definition.
        // Large data is set to false. This is used since updates in
        // general are not large in size. (If unsure, use true)
        encoder.encodeFieldListInit(OMMFieldList.HAS_STANDARD_DATA, (short)0, (short)1, (short)0);

        // TRDPRC_1
        encoder.encodeFieldEntryInit((short)6, OMMTypes.REAL);
        double value = itemInfo.getTradePrice1();
        long longValue = Rounding.roundDouble2Long(value, OMMNumeric.EXPONENT_NEG4);
        encoder.encodeReal(longValue, OMMNumeric.EXPONENT_NEG4);
        // BID
        encoder.encodeFieldEntryInit((short)22, OMMTypes.REAL);
        value = itemInfo.getBid();
        longValue = Rounding.roundDouble2Long(value, OMMNumeric.EXPONENT_NEG4);
        encoder.encodeReal(longValue, OMMNumeric.EXPONENT_NEG4);
        // ASK
        encoder.encodeFieldEntryInit((short)25, OMMTypes.REAL);
        value = itemInfo.getAsk();
        longValue = Rounding.roundDouble2Long(value, OMMNumeric.EXPONENT_NEG4);
        encoder.encodeReal(longValue, OMMNumeric.EXPONENT_NEG4);
        // ACVOL_1
        encoder.encodeFieldEntryInit((short)32, OMMTypes.REAL);
        encoder.encodeReal(itemInfo.getACVol1(), OMMNumeric.EXPONENT_0);

        encoder.encodeAggregateComplete(); // Complete the FieldList.

        return (OMMMsg)encoder.acquireEncodedObject();
    }

    public OMMMsg encodeMarketPriceImage(OMMMsg reqMsg, Handle handle, ItemInfo itemInfo)
    {
        OMMMsg outmsg = null;
        if (reqMsg.getMsgType() == OMMMsg.MsgType.REQUEST)
        {
            outmsg = pool.acquireMsg();
            outmsg.setMsgType(OMMMsg.MsgType.REFRESH_RESP); // Set the message
                                                            // type to be
                                                            // refresh response.
            outmsg.setMsgModelType(reqMsg.getMsgModelType()); // Set the message
                                                              // model type to
                                                              // be
                                                              // the type
                                                              // requested.
            // pass version info
            if (handle != null)
            {
                outmsg.setAssociatedMetaInfo(handle);
            }

            outmsg.setIndicationFlags(OMMMsg.Indication.REFRESH_COMPLETE);
            outmsg.setItemGroup(2); // Set the item group to be 2. Indicates the
                                    // item will be in group 2.
            // Set the state of the item stream.
            if (reqMsg.isSet(OMMMsg.Indication.NONSTREAMING))
            {
                // NONSTREAMING for non-streaming request
                // Indicate the stream is nonstreaming and the data provided is
                // OK.
                outmsg.setState(OMMState.Stream.NONSTREAMING, OMMState.Data.OK, OMMState.Code.NONE,
                                "OK");
            }
            else
            {
                // Indicate the stream is streaming (Stream.OPEN) and the data
                // provided is OK.
                outmsg.setState(OMMState.Stream.OPEN, OMMState.Data.OK, OMMState.Code.NONE, "OK");
            }
        }
        else
        {
            return null;
        }

        if (reqMsg.getMsgModelType() == RDMMsgTypes.MARKET_PRICE)
        {
            outmsg.setIndicationFlags(OMMMsg.Indication.REFRESH_COMPLETE);
            
            if(reqMsg.isSet(OMMMsg.Indication.REFRESH))
                outmsg.setRespTypeNum(OMMMsg.RespType.SOLICITED);
            else
                outmsg.setRespTypeNum(OMMMsg.RespType.UNSOLICITED);
            
            outmsg.setAttribInfo(reqMsg.getAttribInfo());
            encoder.initialize(OMMTypes.MSG, 1000);
            encoder.encodeMsgInit(outmsg, OMMTypes.NO_DATA, OMMTypes.FIELD_LIST);

            encoder.encodeFieldListInit(OMMFieldList.HAS_STANDARD_DATA | OMMFieldList.HAS_INFO,
                                        (short)0, (short)1, (short)0);
            // RDNDISPLAY
            encoder.encodeFieldEntryInit((short)2, OMMTypes.UINT);
            encoder.encodeUInt(100L);
            // RDN_EXCHID
            encoder.encodeFieldEntryInit((short)4, OMMTypes.ENUM);
            encoder.encodeEnum(155);
            // DIVIDEND_DATE
            encoder.encodeFieldEntryInit((short)38, OMMTypes.DATE);
            encoder.encodeDate(2006, 12, 25);
            // TRDPRC_1
            encoder.encodeFieldEntryInit((short)6, OMMTypes.REAL);
            double value = itemInfo.getTradePrice1();
            long longValue = Rounding.roundDouble2Long(value, OMMNumeric.EXPONENT_NEG4);
            encoder.encodeReal(longValue, OMMNumeric.EXPONENT_NEG4);
            // BID
            encoder.encodeFieldEntryInit((short)22, OMMTypes.REAL);
            value = itemInfo.getBid();
            longValue = Rounding.roundDouble2Long(value, OMMNumeric.EXPONENT_NEG4);
            encoder.encodeReal(longValue, OMMNumeric.EXPONENT_NEG4);
            // ASK
            encoder.encodeFieldEntryInit((short)25, OMMTypes.REAL);
            value = itemInfo.getAsk();
            longValue = Rounding.roundDouble2Long(value, OMMNumeric.EXPONENT_NEG4);
            encoder.encodeReal(longValue, OMMNumeric.EXPONENT_NEG4);

            // ACVOL_1
            encoder.encodeFieldEntryInit((short)32, OMMTypes.REAL);
            encoder.encodeReal(itemInfo.getACVol1(), OMMNumeric.EXPONENT_0);
            // ASK_TIME
            encoder.encodeFieldEntryInit((short)267, OMMTypes.TIME);
            encoder.encodeTime(19, 12, 23, 0);

            encoder.encodeAggregateComplete();

            OMMMsg encodedMsg = (OMMMsg)encoder.acquireEncodedObject();
            pool.releaseMsg(outmsg);
            return encodedMsg;
        }
        else
        {
            if (outmsg != null)
                pool.releaseMsg(outmsg);
            return null;
        }
    }

    public void cleanup()
    {
        if (encoder != null && pool != null)
            pool.releaseEncoder(encoder);
        if (pool != null)
            pool.destroy();
        pool = null;
        encoder = null;
    }
}
