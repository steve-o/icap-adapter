package com.thomsonreuters.rfa.valueadd.domainrep.rdm.login;

import java.util.EnumSet;

import com.reuters.rfa.omm.OMMData;
import com.reuters.rfa.omm.OMMEncoder;
import com.reuters.rfa.omm.OMMMsg;
import com.reuters.rfa.omm.OMMPool;
import com.reuters.rfa.omm.OMMTypes;
import com.reuters.rfa.rdm.RDMMsgTypes;
import com.thomsonreuters.rfa.valueadd.domainrep.DomainResponse;
import com.thomsonreuters.rfa.valueadd.domainrep.DomainType;
import com.thomsonreuters.rfa.valueadd.domainrep.ResponseStatus;
import com.thomsonreuters.rfa.valueadd.util.ValueAddException;
import com.thomsonreuters.rfa.valueadd.util.ValueAddMessageKeys;
import com.thomsonreuters.rfa.valueadd.util.ValueAddException.ReasonCode;

/**
 * Representation of RDM login response message.
 * <li>As with all RDM response message representation, use {@link #getMsg(OMMPool)} to get encoded {@link OMMMsg} from the object of this class.
 * <li>Similarly, use {@link #setMsg(OMMMsg)} or {@link #RDMLoginResponse(OMMMsg)} to decode {@link OMMMsg} into object of this class.
 * <li>When a field is not set, get method for the field returns default values as specified by the RDM usage guide. 
 *    If there is no default value, get method throws an exception of class ValueAddException.
 * <li>has methods checks if a field is set or not.   
 * @see MessageType
 * @see IndicationMask
 * @see ResponseStatus
 * @see RDMLoginResponseAttrib
 * @see RDMLoginResponsePayload
 */
public class RDMLoginResponse extends DomainResponse
{
    private MessageType messageType;
    
    private boolean isRefreshSolicited;
    private boolean hasIsRefreshSolicited;

    private long seqNum;
    private boolean hasSeqNum;

    private long secondarySeqNum;
    private boolean hasSecondarySeqNum;
 
    private EnumSet<IndicationMask> indicationMask = EnumSet.noneOf(IndicationMask.class);
    
    private ResponseStatus respStatus = new ResponseStatus();
    private boolean hasRespStatus;
    
    private RDMLoginResponseAttrib loginResponseAttrib;
    private boolean hasLoginResponseAttrib;
    private RDMLoginResponsePayload payload;
    private boolean hasPayload;

    private static final int ENCODER_SIZE = 1024;

    /**
     * Constructor to create {@link MessageType#REFRESH_RESP login refresh response}.
     */
    public RDMLoginResponse()
    {
        super(DomainType.RDM_LOGIN);
        indicationMask = EnumSet.noneOf(IndicationMask.class);
        messageType = MessageType.REFRESH_RESP;
    }

    /**
     * Create an {@link RDMLoginResponse} object by decoding login response OMMMsg.
     * @throws {@link ValueAddException} if OMMMsg is not valid login response message. 
     */
    public RDMLoginResponse(OMMMsg msg)
    {
        super(DomainType.RDM_LOGIN);
        indicationMask = EnumSet.noneOf(IndicationMask.class);
        decode(msg);
    }

    /**
     * Encode {@link RDMLoginResponse} and return encoded {@link OMMMsg}.
     * Caller is expected to return the message back into the same pool.
     * @param pool - OMMMsg is acquired from the pool used when this method is called.
     * @return OMMMsg - encoded OMMMsg. 
     */
    public OMMMsg getMsg(OMMPool pool)
    {
        return encode(pool);
    }

    /**
     * Decode login response message represented in OMMMsg into this object.
     * Before decoding the encoded login response message, 
     * this method first clears any previous values stored for this object.
     * @param ommEncodedMessage - Encoded login response message.
     * @throws {@link ValueAddException} if OMMMsg is not valid login response message. 
     */
    public void setMsg(OMMMsg ommEncodedMessage)
    {
        clear();
        decode(ommEncodedMessage);
    }

    /**
     * @return MessageType set or decoded before. 
     * Returns default {@link MessageType#REFRESH_RESP} when message type is not set. 
     */
    public MessageType getMessageType()
    {
        return messageType;
    }

    /**
     * 
     * @param messageType
     */
    public void setMessageType(MessageType messageType)
    {
        this.messageType = messageType;
    }

    
    private OMMMsg encode(OMMPool pool)
    {
        OMMMsg msg = pool.acquireMsg();
        msg.setMsgType(MessageType.getValue(getMessageType()));
        msg.setMsgModelType(DomainType.getValue(getDomainType()));

        //For login refresh, REFRESH_COMPLETE is always set.
        if(getMessageType() == MessageType.REFRESH_RESP)
        {
            int intIndMask = OMMMsg.Indication.REFRESH_COMPLETE;
            if (!indicationMask.isEmpty())
                intIndMask |= IndicationMask.getValue(indicationMask);
        
            msg.setIndicationFlags(intIndMask);
        }
        else
        {
            if (!indicationMask.isEmpty())
                msg.setIndicationFlags(IndicationMask.getValue(indicationMask));
        }
       
        if (hasRespStatus && respStatus != null)
        {
            msg.setState(respStatus.getStreamState(), respStatus.getDataState(),
                         respStatus.getCode(), respStatus.getText());
        }
        
        if (hasSeqNum)
            msg.setSeqNum(seqNum);
        if (hasSecondarySeqNum)
            msg.setSeqNum(secondarySeqNum);

        if (hasIsRefreshSolicited)
            msg.setRespTypeNum(hasIsRefreshSolicited && isRefreshSolicited ? OMMMsg.RespType.SOLICITED : OMMMsg.RespType.UNSOLICITED);
              
        if (hasLoginResponseAttrib && loginResponseAttrib != null)
            msg = loginResponseAttrib.encode(pool, msg);

        // Payload
        OMMData payloadData = null;
        if (payload != null && hasPayload == true && payload.hasData() && (payloadData = payload.getData(pool)) != null)
        {
            OMMEncoder encoder = pool.acquireEncoder();
            encoder.initialize(OMMTypes.MSG, ENCODER_SIZE);
            encoder.encodeMsgInit(msg, OMMTypes.ELEMENT_LIST, payloadData.getType());
            encoder.encodeData(payloadData);
            OMMMsg encMsgPayload = (OMMMsg)encoder.acquireEncodedObject();

            pool.releaseMsg(msg);
            pool.releaseEncoder(encoder);

            // this message will be owned by the caller and after caller is done
            // with the message,
            // message needs to be returned to the same pool that is passed to
            // get encoded message.

            return encMsgPayload;
        }
        return msg;
    }

    private boolean isValidMsg(OMMMsg ommMsg)
    {
        if (ommMsg == null)
            return false;

        if (ommMsg.getMsgModelType() != RDMMsgTypes.LOGIN)
            return false;

        return true;
    }

    private void decode(OMMMsg ommMsg)
    {
        if (!isValidMsg(ommMsg))
            throw new ValueAddException(ValueAddMessageKeys.NOT_VALID_MSG.format("Login Response"));

        if (ommMsg.getMsgType() == OMMMsg.MsgType.REFRESH_RESP
                && !ommMsg.isSet(OMMMsg.Indication.REFRESH_COMPLETE))
        {
            throw new ValueAddException(ReasonCode.MISSING_REQUIRED_FIELD,
                    ValueAddMessageKeys.FIELD_NOT_SET.format("RefreshComplete Indication"));
        }
        setMessageType(MessageType.getMessageType(ommMsg.getMsgType()));
        setIndications(ommMsg);

        if(ommMsg.has(OMMMsg.HAS_RESP_TYPE_NUM))
            setIsRefreshSolicited(ommMsg.getRespTypeNum() == OMMMsg.RespType.SOLICITED);
        
        if (ommMsg.has(OMMMsg.HAS_STATE))
        {
            setRespStatus(new ResponseStatus(ommMsg.getState()));
        }
        if (ommMsg.has(OMMMsg.HAS_SEQ_NUM))
            setSequenceNum(ommMsg.getSeqNum());
        if (ommMsg.has(OMMMsg.HAS_SECONDARY_SEQ_NUM))
            setSecondarySequenceNum(ommMsg.getSecondarySeqNum());

        if (ommMsg.getDataType() != OMMTypes.NO_DATA)
        {
            payload = new RDMLoginResponsePayload();
            payload.setData(ommMsg.getPayload());
            hasPayload = true;
        }

        if (ommMsg.has(OMMMsg.HAS_ATTRIB_INFO))
        {
            loginResponseAttrib = new RDMLoginResponseAttrib(ommMsg.getAttribInfo());
            hasLoginResponseAttrib = true;
        }
    }

    /**
     * Makes all presence flags false and clears response attribute and payload.
     */
    public void clear()
    {
        super.clear();
        hasRespStatus = false;
        hasIsRefreshSolicited = false;
        hasSeqNum = false;
        hasSecondarySeqNum = false;
        
        payload = null;
        hasPayload = false;

        if (loginResponseAttrib != null)
            loginResponseAttrib.clear();
        hasLoginResponseAttrib = false;
        indicationMask = EnumSet.noneOf(IndicationMask.class);
        messageType = MessageType.REFRESH_RESP;
    }

    /**
     * 
     * @param loginResponseAttrib
     */
    public void setAttrib(RDMLoginResponseAttrib loginResponseAttrib)
    {
        this.loginResponseAttrib = loginResponseAttrib;
        hasLoginResponseAttrib = true;
    }

    /**
     * @return RDMLoginResponseAttrib
     * @throws ValueAddException if RDMLoginResponseAttrib is not set.
     */
    public RDMLoginResponseAttrib getAttrib()
    {
        if (hasLoginResponseAttrib)
            return loginResponseAttrib;

        throw new ValueAddException(ReasonCode.MISSING_OPTIONAL_FIELD,
                ValueAddMessageKeys.FIELD_NOT_SET.format("LoginResponseAttrib"));
    }

    /**
     * @return Flag indicating presence of Attributes.
     */
    public boolean hasAttrib()
    {
        return hasLoginResponseAttrib;
    }

    /**
     * 
     * @return LoginResponsePayload.
     * @throws ValueAddException if Payload is not set.
     */
    public RDMLoginResponsePayload getPayload()
    {
        if (hasPayload)
            return payload;

        throw new ValueAddException(ReasonCode.MISSING_OPTIONAL_FIELD,
                ValueAddMessageKeys.FIELD_NOT_SET.format("Payload"));
    }

    /**
     * 
     * @param loginRespPayload
     */
    public void setPayload(RDMLoginResponsePayload loginRespPayload)
    {
        hasPayload = true;
        payload = loginRespPayload;
    }

    /**
     * 
     * @return Flag indicating presence of login payload.
     */
    public boolean hasPayload()
    {
        return hasPayload;
    }
    
    /**
     * 
     * @return SequenceNumber
     * @throws ValueAddException if SequenceNumber is not set.
     */
    public Long getSequenceNum()
    {
        if (!hasSeqNum)
            throw new ValueAddException(ValueAddException.ReasonCode.MISSING_OPTIONAL_FIELD,
                    ValueAddMessageKeys.FIELD_NOT_SET.format("SequenceNumber"));

        return seqNum;
    }

    /**
     * 
     * @param sequenceNumber
     */
    public void setSequenceNum(long sequenceNumber)
    {
        this.seqNum = sequenceNumber;
        hasSeqNum = true;
    }

    /**
     * 
     * @return Flag indicating presence of SequenceNumber.
     */
    public boolean hasSequenceNum()
    {
        return hasSeqNum;
    }

    /**
     * 
     * @return SecondarySequenceNumber
     * @throws ValueAddException if SecondarySequenceNumber is not set.
     */
    public Long getSecondarySequenceNum()
    {
        if (!hasSecondarySeqNum)
            throw new ValueAddException(ValueAddException.ReasonCode.MISSING_OPTIONAL_FIELD,
                    ValueAddMessageKeys.FIELD_NOT_SET.format("SecondarySequenceNumber"));
        return secondarySeqNum;
    }

    /**
     * 
     * @param secondarySequenceNumber
     */
    public void setSecondarySequenceNum(long secondarySequenceNumber)
    {
        this.secondarySeqNum = secondarySequenceNumber;
        hasSecondarySeqNum = true;
    }

    /**
     * 
     * @return Flag indicating presence of secondarySequenceNumber.
     */
    public boolean hasSecondarySequenceNum()
    {
        return hasSecondarySeqNum;
    }

    /**
     * 
     * @return ResponseStatus.
     * @throws ValueAddException if ResponseStatus is not set.
     */
    public ResponseStatus getRespStatus()
    {
        if (!hasRespStatus)
            throw new ValueAddException(ValueAddException.ReasonCode.MISSING_OPTIONAL_FIELD,
                    ValueAddMessageKeys.FIELD_NOT_SET.format("ResponseStatus"));
        return respStatus;
    }

    /**
     * 
     * @param responseStatus
     */
    public void setRespStatus(ResponseStatus responseStatus)
    {
        this.hasRespStatus = true;
        this.respStatus = responseStatus;
    }

    /**
     * 
     * @return Flag indicating presence of ResponseStatus.
     */
    public boolean hasRespStatus()
    {
        return hasRespStatus;
    }

    /**
     * 
     * @return True if this is a refresh solicited message.
     * @throws ValueAddException when field is not set.
     */
    public boolean getIsRefreshSolicited()
    {
        if (!hasIsRefreshSolicited)
            throw new ValueAddException(ValueAddException.ReasonCode.MISSING_OPTIONAL_FIELD,
                    ValueAddMessageKeys.FIELD_NOT_SET.format("IsRefreshSolicited"));

        return isRefreshSolicited;
    }
    
    /**
     * 
     * @param isRefreshSolicited
     */
    public void setIsRefreshSolicited(boolean isRefreshSolicited)
    {
        this.isRefreshSolicited = isRefreshSolicited;
        hasIsRefreshSolicited = true;
    }
    
    /**
     * 
     * @return Flag indicating presence of IsRefreshSolicited.
     */
    public boolean hasIsRefreshSolicited()
    {
        return hasIsRefreshSolicited;
    }

    /**
     * 
     * @return Set of IndicationMask for the login response.
     *         Empty EnumSet if indication masks is not set.
     */
    public EnumSet<IndicationMask> getIndicationMask()
    {
        return indicationMask;
    }
    
    /**
     * 
     * @param indicationMask
     */
    public void setIndicationMask(EnumSet<IndicationMask> indicationMask )
    {
        this.indicationMask = indicationMask;
    }
    
    /**
     * Indication mask enumerations for login response.
     */
    public enum IndicationMask
    {
        REFRESH_COMPLETE,
        CLEAR_CACHE;

        static EnumSet<IndicationMask> getIndicationMask(int ommvalue)
        {
            EnumSet<IndicationMask> list = EnumSet.noneOf(IndicationMask.class);
            if ((ommvalue & OMMMsg.Indication.REFRESH_COMPLETE) != 0)
                list.add(REFRESH_COMPLETE);
            if ((ommvalue & OMMMsg.Indication.CLEAR_CACHE) != 0)
                list.add(CLEAR_CACHE);
             return list;
        }

        static int getValue(EnumSet<IndicationMask> typedValue)
        {
            int indicationMask = 0;
            
            if (typedValue.contains(REFRESH_COMPLETE))
                indicationMask |= OMMMsg.Indication.REFRESH_COMPLETE;
            if (typedValue.contains(CLEAR_CACHE))
                indicationMask |= OMMMsg.Indication.CLEAR_CACHE;
           
            return indicationMask;
        }
    }
    
    private void setIndications(OMMMsg msg)
    {
        if (msg.isSet(OMMMsg.Indication.CLEAR_CACHE))
        {
            indicationMask.add(IndicationMask.CLEAR_CACHE);
        }

        if (msg.isSet(OMMMsg.Indication.REFRESH_COMPLETE))
        {
            indicationMask.add(IndicationMask.REFRESH_COMPLETE);
        }
    }
    
    /**
     * Message type enumerations for RDM login response messages. 
     */
    public enum MessageType
    {
        REFRESH_RESP(OMMMsg.MsgType.REFRESH_RESP), STATUS_RESP(OMMMsg.MsgType.STATUS_RESP), 
        GENERIC(OMMMsg.MsgType.GENERIC);

        private MessageType(int value)
        {
            this.value = (byte)value;
        }

        public static byte getValue(MessageType messageType)
        {
            return messageType.value;
        }

        public static MessageType getMessageType(byte value)
        {
            switch (value)
            {
                case OMMMsg.MsgType.REFRESH_RESP:
                    return REFRESH_RESP;
                case OMMMsg.MsgType.STATUS_RESP:
                    return STATUS_RESP;
                case OMMMsg.MsgType.GENERIC:
                    return GENERIC;
                default:
                    throw new ValueAddException(ValueAddMessageKeys.UNSUPPORTED_MESSAGE_TYPE.format(OMMMsg.MsgType.toString(value)));
            }
        }

        private byte value;
    }
}