package com.thomsonreuters.rfa.valueadd.domainrep;

/**
 * 
 * Base class for all RDM request and response messages.
 *
 */
public abstract class Domain
{
    private DomainType domainType;
 
    protected Domain(DomainType domain)
    {
        this.domainType = domain;
    }

    public DomainType getDomainType()
    {
        return domainType;
    }

   

    protected void clear()
    {
       //no op
    }
}
