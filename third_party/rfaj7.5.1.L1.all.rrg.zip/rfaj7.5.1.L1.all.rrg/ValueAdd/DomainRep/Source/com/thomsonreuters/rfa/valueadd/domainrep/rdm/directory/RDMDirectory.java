package com.thomsonreuters.rfa.valueadd.domainrep.rdm.directory;

import java.util.EnumSet;

import com.reuters.rfa.common.QualityOfService;
import com.reuters.rfa.omm.OMMFilterEntry;
import com.reuters.rfa.omm.OMMMapEntry;
import com.reuters.rfa.rdm.RDMMsgTypes;
import com.thomsonreuters.rfa.valueadd.domainrep.DomainType;
import com.thomsonreuters.rfa.valueadd.util.ValueAddException;
import com.thomsonreuters.rfa.valueadd.util.ValueAddListManager;
import com.thomsonreuters.rfa.valueadd.util.ValueAddMessageKeys;

/**
 * Enumerations used by request and response messages for {@linkplain DomainType#RDM_DIRECTORY} domain.
 * Defines lists for Capability, DictionaryProvided, DictionaryUsed, RFA's QualityOfService and
 * {@link Service}.
 */
public class RDMDirectory
{
    /**
     * Enumerations of actions that directory response message can use
     * to notify add,delete or updating of a service.
     */
    public enum ServiceAction
    {
        UPDATE(OMMMapEntry.Action.UPDATE), ADD(OMMMapEntry.Action.ADD), DELETE(OMMMapEntry.Action.DELETE);

        private byte value;

        private ServiceAction(byte value)
        {
            this.value = value;
        }

        byte getValue()
        {
            return value;
        }

        static ServiceAction getAction(byte encodedValue)
        {
            switch (encodedValue)
            {
                case 1:
                    return UPDATE;
                case 2:
                    return ADD;
                case 3:
                    return DELETE;
                default:
                    return ADD;
            }
        }
    }

    /**
     * Enumerations representing filter id of a service filter in the
     * directory response message.
     */
    public enum FilterId
    {
        INFO(com.reuters.rfa.rdm.RDMService.FilterId.INFO), STATE(
                com.reuters.rfa.rdm.RDMService.FilterId.STATE), GROUP(
                com.reuters.rfa.rdm.RDMService.FilterId.GROUP), LOAD(
                com.reuters.rfa.rdm.RDMService.FilterId.LOAD), DATA(
                com.reuters.rfa.rdm.RDMService.FilterId.DATA), LINK(
                com.reuters.rfa.rdm.RDMService.FilterId.LINK);

        private int value;

        private FilterId(int value)
        {
            this.value = value;
        }

        int getValue()
        {
            return value;
        }

        static FilterId getFilterId(int value)
        {
            switch (value)
            {
                case 1:
                    return INFO;
                case 2:
                    return STATE;
                case 3:
                    return GROUP;
                case 4:
                    return LOAD;
                case 5:
                    return DATA;
                case 6:
                    return LINK;
                default:
                    throw new ValueAddException(ValueAddMessageKeys.INVALID_FILTER_ID.format(value));
            }
        }
    }

    /**
     * Actions used by a service in directory response message to set, update or
     * clear a service filter.
     */
    public enum FilterAction
    {
        UPDATE(OMMFilterEntry.Action.UPDATE), SET(OMMFilterEntry.Action.SET), CLEAR(
                OMMFilterEntry.Action.CLEAR);

        private byte value;

        private FilterAction(byte value)
        {
            this.value = value;
        }

        static byte getValue(FilterAction filterAction)
        {
            return filterAction.value;
        }

        static FilterAction getFilterAction(byte value)
        {
            switch (value)
            {
                case 1:
                    return UPDATE;
                case 2:
                    return SET;
                case 3:
                    return CLEAR;
                default:
                    return SET;
            }
        }
    }

    /**
     * Representation of filter flags to request or check existence of
     * the filters in a service entry in directory message.  
     * FilterMask flag is present in Attribute information of a
     * directory request and response message.
     * Use {@link EnumSet} to select subset or all of filter masks.
     */
    public enum FilterMask
    {
        INFO(com.reuters.rfa.rdm.RDMService.Filter.INFO), 
        STATE(com.reuters.rfa.rdm.RDMService.Filter.STATE), 
        GROUP(com.reuters.rfa.rdm.RDMService.Filter.GROUP), 
        LOAD(com.reuters.rfa.rdm.RDMService.Filter.LOAD), 
        DATA(com.reuters.rfa.rdm.RDMService.Filter.DATA), 
        LINK(com.reuters.rfa.rdm.RDMService.Filter.LINK);

        private FilterMask(int value)
        {
            this.value = value;
        }

        static int getValue(EnumSet<FilterMask> dataMasks)
        {
            int retVal = 0;
            for (FilterMask dataMask : dataMasks)
            {
                retVal |= dataMask.value;
            }
            return retVal;
        }

        static EnumSet<FilterMask> getDataMask(int filter)
        {
            EnumSet<FilterMask> dataMaskSet = EnumSet.noneOf(FilterMask.class);
            for (FilterMask dataMask : FilterMask.values())
                if ((filter & dataMask.value) == dataMask.value)
                    dataMaskSet.add(dataMask);
            return dataMaskSet;
        }

        private int value;
    }

    /**
     * Constants to represent capabilities that service can provide.
     * Capabilities {@link RDMMsgTypes#LOGIN Login} and
     * {@link RDMMsgTypes#DIRECTORY Directory} are not included as item can be
     * requested from a service only after login. See RDM Usage Guide for
     * details.
     */
    public final static class Capability
    {
        public static Capability DICTIONARY = new Capability(RDMMsgTypes.DICTIONARY);
        public static Capability MARKET_PRICE = new Capability(RDMMsgTypes.MARKET_PRICE);
        public static Capability MARKET_BY_ORDER = new Capability(RDMMsgTypes.MARKET_BY_ORDER);
        public static Capability MARKET_BY_PRICE = new Capability(RDMMsgTypes.MARKET_BY_PRICE);
        public static Capability MARKET_MAKER = new Capability(RDMMsgTypes.MARKET_MAKER);
        public static Capability SYMBOL_LIST = new Capability(RDMMsgTypes.SYMBOL_LIST);
        public static Capability YIELD_CURVE = new Capability(RDMMsgTypes.YIELD_CURVE);

        private short value;

        public static Capability CUSTOM_DOMAIN(short value)
        {
            return getCapability(value);
        }

        private Capability(short value)
        {
            this.value = value;
        }

        short getValue()
        {
            return value;
        }

        static Capability getCapability(long value)
        {
            switch ((int)value)
            {
                case RDMMsgTypes.DICTIONARY:
                    return DICTIONARY;
                case RDMMsgTypes.MARKET_PRICE:
                    return MARKET_PRICE;
                case RDMMsgTypes.MARKET_MAKER:
                    return MARKET_MAKER;
                case RDMMsgTypes.SYMBOL_LIST:
                    return SYMBOL_LIST;
                case RDMMsgTypes.MARKET_BY_ORDER:
                    return MARKET_BY_ORDER;
                case RDMMsgTypes.MARKET_BY_PRICE:
                    return MARKET_BY_PRICE;
                case RDMMsgTypes.YIELD_CURVE:
                	return YIELD_CURVE;
                default:
                    if (value > RDMMsgTypes.MAX_RESERVED && value <= RDMMsgTypes.MAX_VALUE)
                        return new Capability((short)value);

                    throw new ValueAddException(
                            ValueAddMessageKeys.INVALID_DIRECTORY_CAPABILITY.format(value));
            }
        }

        public String toString()
        {
            return (value < RDMMsgTypes.SYMBOL_LIST) ? RDMMsgTypes.toString(value) : "CUSTOM: "
                    + value;
        }
    }

    /**
     * List that manages capabilities defined in RDMService.InfoFilter.
     */
    public static class CapabilityList extends ValueAddListManager<Capability>
    {
    }

    /**
     * List that manages dictionaries provided field in RDMService.InfoFilter.
     */
    public static class DictionaryProvidedList extends ValueAddListManager<String>
    {
    }

    /**
     * List that manages dictionaries used field for a RDMService.InfoFilter.
     */
    public static class DictionaryUsedList extends ValueAddListManager<String>
    {
    }

    /**
     * List that manages QualityOfService field for a RDMService.InfoFilter.
     */
    public static class QosList extends ValueAddListManager<QualityOfService>
    {
    }

    /**
     * List that manages Service. Use with
     * {@link RDMDirectoryResponsePayload}.
     */
    public static class ServiceList extends ValueAddListManager<Service>
    {
    }
}
