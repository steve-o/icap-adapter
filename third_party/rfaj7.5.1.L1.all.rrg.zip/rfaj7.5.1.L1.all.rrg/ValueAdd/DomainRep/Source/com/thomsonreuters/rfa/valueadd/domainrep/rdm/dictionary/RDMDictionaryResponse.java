package com.thomsonreuters.rfa.valueadd.domainrep.rdm.dictionary;

import java.util.EnumSet;
import java.util.Iterator;

import com.reuters.rfa.dictionary.DictionaryException;
import com.reuters.rfa.omm.OMMData;
import com.reuters.rfa.omm.OMMElementEntry;
import com.reuters.rfa.omm.OMMElementList;
import com.reuters.rfa.omm.OMMEncoder;
import com.reuters.rfa.omm.OMMMsg;
import com.reuters.rfa.omm.OMMNumeric;
import com.reuters.rfa.omm.OMMPool;
import com.reuters.rfa.omm.OMMSeries;
import com.reuters.rfa.omm.OMMTypes;
import com.reuters.rfa.rdm.RDMMsgTypes;
import com.thomsonreuters.rfa.valueadd.domainrep.DomainResponse;
import com.thomsonreuters.rfa.valueadd.domainrep.DomainType;
import com.thomsonreuters.rfa.valueadd.domainrep.ResponseStatus;
import com.thomsonreuters.rfa.valueadd.util.ValueAddException;
import com.thomsonreuters.rfa.valueadd.util.ValueAddMessageKeys;

/**
 * Representation of RDM dictionary response message.
 * <li>As with all RDM response message representation, use {@link #getMsg(OMMPool)} to get encoded {@link OMMMsg} from the object of this class.
 * <li>Similarly, use {@link #setMsg(OMMMsg)} or {@link #RDMDictionaryResponse(OMMMsg)} to decode {@link OMMMsg} into object of this class.
 * <li>When a field is not set, get method for the field returns default values as specified by the RDM usage guide. 
 *    If there is no default value, get method throws an exception of class ValueAddException.
 * <li>has methods checks if a field is set or not.   
 * @see MessageType
 * @see IndicationMask
 * @see ResponseStatus
 * @see RDMDictionaryResponseAttrib
 * @see RDMDictionaryResponsePayload
 */
public class RDMDictionaryResponse extends DomainResponse
{
    private MessageType messageType;
    
    private boolean isRefreshSolicited;
    private boolean hasIsRefreshSolicited;

    private long seqNum;
    private boolean hasSeqNum;

    private long secondarySeqNum;
    private boolean hasSecondarySeqNum;
 
    private EnumSet<IndicationMask> indicationMask = EnumSet.noneOf(IndicationMask.class);
   
    private ResponseStatus respStatus = new ResponseStatus();
    private boolean hasRespStatus;
    
    private RDMDictionaryResponseAttrib dictionaryResponseAttrib;
    private boolean hasDictionaryResponseAttrib;

    private RDMDictionaryResponsePayload payload = new RDMDictionaryResponsePayload();
    private boolean hasPayload;

    /**
     * Construct an empty dictionary refresh message with RDM default values.
     */
    public RDMDictionaryResponse()
    {
        super(DomainType.RDM_DICTIONARY);
        indicationMask = EnumSet.noneOf(IndicationMask.class);
        messageType = MessageType.REFRESH_RESP;
    }

    /**
     * Decode the dictionary response message.
     * @param encodedMessage
     * @throws ValueAddException if OMMMsg is not a valid dictionary response message.
     */
    public RDMDictionaryResponse(OMMMsg encodedMessage)
    {
        super(DomainType.RDM_DICTIONARY);
        clear();
        indicationMask = EnumSet.noneOf(IndicationMask.class);
        decode(encodedMessage);
    }

    /**
     * Decode the dictionary response message.
     * @param encodedMessage
     * @throws ValueAddException if OMMMsg is not a valid dictionary response message.
     */
    public void setMsg(OMMMsg encodedMessage)
    {
        clear();
        decode(encodedMessage);
    }

    /**
     * Encode {@link RDMDictionaryResponse} and return encoded {@link OMMMsg}.
     * Caller is expected to return the message back into the same pool.
     * @param pool - OMMMsg is acquired from the pool used when this method is called.
     * @return OMMMsg - encoded OMMMsg. 
     */
    public OMMMsg getMsg(OMMPool pool)
    {
        OMMMsg msg = encode(pool);
        if (!hasPayload || payload == null)
            return msg;

        if (dictionaryResponseAttrib.getVerbosity() == RDMDictionary.Verbosity.INFO)
        {
            return encodeDictionaryInfo(pool, msg);
        }
        else
        {
            return encodeFullDictionary(pool, msg);
        }
    }
    
    
    /**
     * @return MessageType set or decoded before. 
     * Returns default {@link MessageType#REFRESH_RESP} when message type is not set. 
     */
    public MessageType getMessageType()
    {
        return messageType;
    }

    /**
     * 
     * @param messageType
     */
    public void setMessageType(MessageType messageType)
    {
        this.messageType = messageType;
    }


    /**
     * 
     * @return RDMDictionaryResponsePayload
     * @throws ValueAddException if RDMDictionaryResponsePayload is not set.
     */
    public RDMDictionaryResponsePayload getPayload()
    {
        if (hasPayload)
            return payload;
        throw new ValueAddException(ValueAddException.ReasonCode.MISSING_OPTIONAL_FIELD,
                ValueAddMessageKeys.FIELD_NOT_SET.format("Payload"));
    }

    /**
     * 
     * @param dictPayload
     */
    public void setPayload(RDMDictionaryResponsePayload dictPayload)
    {
        this.payload = dictPayload;
        hasPayload = true;
    }

    /**
     * 
     * @return Flag indicating presence of RDMDictionaryResponsePayload.
     */
    public boolean hasPayload()
    {
        return hasPayload;
    }

    /**
     * 
     * @param dictionaryResponseAttrib
     */
    public void setAttrib(RDMDictionaryResponseAttrib dictionaryResponseAttrib)
    {
        this.dictionaryResponseAttrib = dictionaryResponseAttrib;
        hasDictionaryResponseAttrib = true;
    }

    /**
     * 
     * @return RDMDictionaryResponseAttrib
     * @throws ValueAddException if RDMDictionaryResponseAttrib is not set.
     */
    public RDMDictionaryResponseAttrib getAttrib()
    {
        if (hasDictionaryResponseAttrib)
            return dictionaryResponseAttrib;

        throw new ValueAddException(ValueAddException.ReasonCode.MISSING_OPTIONAL_FIELD,
                ValueAddMessageKeys.FIELD_NOT_SET.format("DictionaryResponseAttrib"));
    }

    /**
     * 
     * @return Flag indicating presence of RDMDictionaryResponseAttrib.
     */
    public boolean hasAttrib()
    {
        return hasDictionaryResponseAttrib;
    }

    /**
     * 
     * @return SequenceNumber
     * @throws ValueAddException if SequenceNumber is not set.
     */
    public long getSequenceNum()
    {
        if (!hasSeqNum)
            throw new ValueAddException(ValueAddException.ReasonCode.MISSING_OPTIONAL_FIELD,
                                        ValueAddMessageKeys.FIELD_NOT_SET.format("SequenceNumber"));

        return seqNum;
    }

    /**
     * 
     * @param sequenceNumber
     */
    public void setSequenceNum(long sequenceNumber)
    {
        this.seqNum = sequenceNumber;
        hasSeqNum = true;
    }
    
    /**
     * 
     * @return Flag indicating presence of sequenceNumber.
     */
    public boolean hasSequenceNum()
    {
        return hasSeqNum;
    }

    /**
     * 
     * @return SecondarySequenceNumber
     * @throws ValueAddException if SecondarySequenceNumber is not set.
     */
    public long getSecondarySequenceNum()
    {
        if (!hasSecondarySeqNum)
            throw new ValueAddException(ValueAddException.ReasonCode.MISSING_OPTIONAL_FIELD,
                                        ValueAddMessageKeys.FIELD_NOT_SET.format("SecondarySequenceNumber"));
        return secondarySeqNum;
    }

    /**
     * 
     * @param secondarySequenceNumber
     */
    public void setSecondarySequenceNum(long secondarySequenceNumber)
    {
        this.secondarySeqNum = secondarySequenceNumber;
        hasSecondarySeqNum = true;
    }

    /**
     * 
     * @return Flag indicating presence of SecondarySequenceNumber
     */
    public boolean hasSecondarySequenceNum()
    {
        return hasSecondarySeqNum;
    }

    /**
     * 
     * @return ResponseStatus
     * @throws ValueAddException if ResponseStatus is not set.
     */
    public ResponseStatus getResponseStatus()
    {
        if (!hasRespStatus)
            throw new ValueAddException(ValueAddException.ReasonCode.MISSING_OPTIONAL_FIELD,
                                        ValueAddMessageKeys.FIELD_NOT_SET.format("ResponseStatus"));
        return respStatus;
    }

    /**
     * 
     * @param responseStatus
     */
    public void setResponseStatus(ResponseStatus responseStatus)
    {
        this.hasRespStatus = true;
        this.respStatus = responseStatus;
    }

    /**
     * 
     * @return Flag indicating presence of ResponseStatus.
     */
    public boolean hasResponseStatus()
    {
        return hasRespStatus;
    }
    
    /**
     * @return if Dictionary refresh response is solicited.
     * @throws if IsRefreshSolicited field is not set.
     */
    public boolean getIsRefreshSolicited()
    {
        if (!hasIsRefreshSolicited)
            throw new ValueAddException(ValueAddException.ReasonCode.MISSING_OPTIONAL_FIELD,
                    ValueAddMessageKeys.FIELD_NOT_SET.format("IsRefreshSolicited"));

        return isRefreshSolicited;
    }
    
    /**
     * 
     * @param isRefreshSolicited
     */
    public void setIsRefreshSolicited(boolean isRefreshSolicited)
    {
        this.isRefreshSolicited = isRefreshSolicited;
        hasIsRefreshSolicited = true;
    }
    
    /**
     * 
     * @return Flag indication presence of isRefreshSolicited.
     */
    public boolean hasIsRefreshSolicited()
    {
        return hasIsRefreshSolicited;
    }
    
    /**
     * 
     * @return Set of IndicationMask for dictionary response.
     *         Empty EnumSet when indication mask is not set.
     */
    public EnumSet<IndicationMask> getIndicationMask()
    {
        return indicationMask;
    }
    
    /**
     * 
     * @param indicationMask
     */
    public void setIndicationMask(EnumSet<IndicationMask> indicationMask )
    {
        this.indicationMask = indicationMask;
    }
    
    /**
     * Sets all presence flags to false and MessageType to REFRESH_RESP. Clears attribute information.
     */
    public void clear()
    {
        super.clear();
        hasRespStatus = false;
        hasIsRefreshSolicited = false;
        hasSeqNum = false;
        hasSecondarySeqNum = false;
        hasPayload = false;
        indicationMask = EnumSet.noneOf(IndicationMask.class);
        if (dictionaryResponseAttrib != null)
            dictionaryResponseAttrib.clear();
        if(payload != null)
            payload.clear();
        hasDictionaryResponseAttrib = false;
        messageType = MessageType.REFRESH_RESP;
    }

    private OMMMsg encodeDictionaryInfo(OMMPool pool, OMMMsg ommMsg)
    {
        OMMData payloadData = null;
        if (!hasPayload || payload == null || !payload.hasData() || (payloadData = payload.getData()) == null)
            return ommMsg;
        OMMEncoder encoder = pool.acquireEncoder();
        encoder.initialize(OMMTypes.MSG, 1024);
        encoder.encodeMsgInit(ommMsg, OMMTypes.NO_DATA, OMMTypes.SERIES);
        encoder.encodeSeriesInit(OMMSeries.HAS_SUMMARY_DATA | OMMSeries.HAS_TOTAL_COUNT_HINT,
                                 OMMTypes.ELEMENT_LIST, 0);

        encodeSummaryData(encoder, (OMMSeries)payloadData);
        encoder.encodeAggregateComplete(); // series
        OMMMsg encMsg = (OMMMsg)encoder.acquireEncodedObject();
        pool.releaseEncoder(encoder);
        pool.releaseMsg(ommMsg);

        return encMsg;
    }

    private OMMMsg encodeFullDictionary(OMMPool pool, OMMMsg msg)
    {
        OMMData payloadData = null;
        if (!hasPayload || payload == null || !payload.hasData() || (payloadData = payload.getData()) == null)
            return msg;

        OMMSeries dictPayloadData = (OMMSeries)payloadData;
        // full dictionary
        OMMEncoder encoder = pool.acquireEncoder();

        boolean growEncoderFlag = false;
        int encoderSize = dictPayloadData.getEncodedLength() + msg.getEncodedLength() + 1000;
        do
        {
            try
            {
                encoder.initialize(OMMTypes.MSG, encoderSize);
                encoder.encodeMsgInit(msg, OMMTypes.NO_DATA, OMMTypes.SERIES);
                encoder.encodeData(dictPayloadData);
                growEncoderFlag = false;
            }
            catch (IndexOutOfBoundsException ie)
            {
                // Not enough room, need to grow the encoderSize.
                growEncoderFlag = true;
                encoderSize = (int)(encoderSize * 1.1);
            }
        }
        while (growEncoderFlag);

        OMMMsg encMsg = (OMMMsg)encoder.acquireEncodedObject();
        pool.releaseEncoder(encoder);
        pool.releaseMsg(msg);

        return encMsg;
    }

    private void encodeSummaryData(OMMEncoder encoder, OMMSeries dictPayloadData)
    {
        if (!dictPayloadData.has(OMMSeries.HAS_SUMMARY_DATA))
            return;

        short dictionaryId = -1;
        int dictionaryType = -1;
        String version = null;
        OMMElementList summary = (OMMElementList)dictPayloadData.getSummaryData();
        for (Iterator<?> iter = summary.iterator(); iter.hasNext();)
        {
            OMMElementEntry element = (OMMElementEntry)iter.next();
            if (element.getName().equals(com.reuters.rfa.rdm.RDMDictionary.Summary.DictionaryId))
            {
                dictionaryId = (short)((OMMNumeric)element.getData()).toLong();
            }
            else if (element.getName().equals(com.reuters.rfa.rdm.RDMDictionary.Summary.Type))
            {
                dictionaryType = (int)((OMMNumeric)element.getData()).toLong();
                if (!(dictionaryType == com.reuters.rfa.rdm.RDMDictionary.Type.ENUM_TABLES || dictionaryType == com.reuters.rfa.rdm.RDMDictionary.Type.FIELD_DEFINITIONS))
                {
                    throw new DictionaryException(
                            ValueAddMessageKeys.UNSUPPORTED_DICTIONARY_TYPE.format(dictionaryType));
                }
            }
            else if (element.getName().equals("Version"))
            {
                version = element.getData().toString();
            }

        }

        encoder.encodeSummaryDataInit();
        encoder.encodeElementListInit(OMMElementList.HAS_STANDARD_DATA, (short)0, (short)0);

        if (version != null && version.length() > 0)
        {
            encoder.encodeElementEntryInit(com.reuters.rfa.rdm.RDMDictionary.Summary.Version,
                                           OMMTypes.BUFFER);
            encoder.encodeBytes(version.getBytes());
        }

        if (dictionaryId != -1)
        {
            encoder.encodeElementEntryInit(com.reuters.rfa.rdm.RDMDictionary.Summary.DictionaryId,
                                           OMMTypes.UINT);
            encoder.encodeUInt(dictionaryId);
        }

        if (dictionaryType != -1)
        {
            encoder.encodeElementEntryInit(com.reuters.rfa.rdm.RDMDictionary.Summary.Type,
                                           OMMTypes.UINT);
            encoder.encodeUInt(dictionaryType);
        }
        encoder.encodeAggregateComplete(); // ElementList
    }

    private void decode(OMMMsg ommMsg)
    {
        if (!isValidMsg(ommMsg))
            throw new ValueAddException(ValueAddMessageKeys.NOT_VALID_MSG.format("Dictionary"));

        setMessageType(MessageType.getMessageType(ommMsg.getMsgType()));
        setIndications(ommMsg);
        if (ommMsg.has(OMMTypes.ATTRIB_INFO))
            setAttrib( new RDMDictionaryResponseAttrib(ommMsg.getAttribInfo()));
        if (ommMsg.has(OMMMsg.HAS_STATE))
            setResponseStatus(new ResponseStatus(ommMsg.getState()));
        if (ommMsg.has(OMMMsg.HAS_SEQ_NUM))
            setSequenceNum(ommMsg.getSeqNum());
        if (ommMsg.has(OMMMsg.HAS_SECONDARY_SEQ_NUM))
            setSecondarySequenceNum(ommMsg.getSecondarySeqNum());
        if(ommMsg.has(OMMMsg.HAS_RESP_TYPE_NUM))
            setIsRefreshSolicited(ommMsg.getRespTypeNum() == OMMMsg.RespType.SOLICITED);
        if (ommMsg.getDataType() == OMMTypes.SERIES)
        {
            payload.setData((OMMSeries)ommMsg.getPayload());
            hasPayload = true;
        }
    }

    private boolean isValidMsg(OMMMsg ommMsg)
    {
        if (ommMsg == null)
            return false;

        if (ommMsg.getMsgModelType() != RDMMsgTypes.DICTIONARY)
            return false;

        if (ommMsg.getDataType() != OMMTypes.NO_DATA && ommMsg.getDataType() != OMMTypes.SERIES)
            return false;

        return true;
    }

    private OMMMsg encode(OMMPool pool)
    {
        OMMMsg msg = pool.acquireMsg();
        msg.setMsgType(MessageType.getValue(getMessageType()));
        msg.setMsgModelType(DomainType.getValue(getDomainType()));

        if (!indicationMask.isEmpty())
            msg.setIndicationFlags(IndicationMask.getValue(indicationMask));

        if (hasRespStatus && respStatus != null)
        {
            msg.setState(respStatus.getStreamState(), respStatus.getDataState(),
                         respStatus.getCode(), respStatus.getText());
        }
        
        if (hasSeqNum)
            msg.setSeqNum(seqNum);
        if (hasSecondarySeqNum)
            msg.setSeqNum(secondarySeqNum);
        if (hasIsRefreshSolicited)
            msg.setRespTypeNum(hasIsRefreshSolicited && isRefreshSolicited ? OMMMsg.RespType.SOLICITED : OMMMsg.RespType.UNSOLICITED);
   
        // this message will be owned by the caller and after caller is done
        // with the message,
        // message needs to be returned to the same pool that is passed to get
        // encoded message.

        if (hasDictionaryResponseAttrib && dictionaryResponseAttrib != null)
            return dictionaryResponseAttrib.encode(pool, msg);

        return msg;
    }
    
    /**
     * Enumerations representing message types for RDM dictionary response messages.
     *
     */
    public enum MessageType
    {
        REFRESH_RESP(OMMMsg.MsgType.REFRESH_RESP), STATUS_RESP(OMMMsg.MsgType.STATUS_RESP), 
        GENERIC(OMMMsg.MsgType.GENERIC);

        private MessageType(int value)
        {
            this.value = (byte)value;
        }

        public static byte getValue(MessageType messageType)
        {
            return messageType.value;
        }

        public static MessageType getMessageType(byte value)
        {
            switch (value)
            {
                case OMMMsg.MsgType.REFRESH_RESP:
                    return REFRESH_RESP;
                case OMMMsg.MsgType.STATUS_RESP:
                    return STATUS_RESP;
                case OMMMsg.MsgType.GENERIC:
                    return GENERIC;
                default:
                    throw new ValueAddException(
                            ValueAddMessageKeys.UNSUPPORTED_MESSAGE_TYPE.format(OMMMsg.MsgType.toString(value)));
            }
        }

        private byte value;
    }
    
    /**
     * Indication mask for dictionary response.
     * See RDM Usage guide for more details.
     */
    public enum IndicationMask
    {
        REFRESH_COMPLETE,
        CLEAR_CACHE,
        DO_NOT_CACHE;

        static EnumSet<IndicationMask> getIndicationMask(int ommvalue)
        {
            EnumSet<IndicationMask> list = EnumSet.noneOf(IndicationMask.class);
            if ((ommvalue & OMMMsg.Indication.REFRESH_COMPLETE) != 0)
                list.add(REFRESH_COMPLETE);
            if ((ommvalue & OMMMsg.Indication.CLEAR_CACHE) != 0)
                list.add(CLEAR_CACHE);
            if ((ommvalue & OMMMsg.Indication.DO_NOT_CACHE) != 0)
                list.add(DO_NOT_CACHE);
            return list;
        }

        static int getValue(EnumSet<IndicationMask> typedValue)
        {
            int indicationMask = 0;
            if (typedValue.contains(REFRESH_COMPLETE))
                indicationMask |= OMMMsg.Indication.REFRESH_COMPLETE;
            if (typedValue.contains(REFRESH_COMPLETE))
                indicationMask |= OMMMsg.Indication.CLEAR_CACHE;
            if (typedValue.contains(DO_NOT_CACHE))
                indicationMask |= OMMMsg.Indication.DO_NOT_CACHE;
           
            return indicationMask;
        }
    }
    
    private void setIndications(OMMMsg msg)
    {
        if (msg.isSet(OMMMsg.Indication.CLEAR_CACHE))
        {
            indicationMask.add(IndicationMask.CLEAR_CACHE);
        }

        if (msg.isSet(OMMMsg.Indication.DO_NOT_CACHE))
        {
            indicationMask.add(IndicationMask.DO_NOT_CACHE);
        }

        if (msg.isSet(OMMMsg.Indication.REFRESH_COMPLETE))
        {
            indicationMask.add(IndicationMask.REFRESH_COMPLETE);
        }
    }
}
