package com.thomsonreuters.rfa.valueadd.domainrep;

import com.reuters.rfa.rdm.RDMMsgTypes;
import com.thomsonreuters.rfa.valueadd.util.ValueAddException;
import com.thomsonreuters.rfa.valueadd.util.ValueAddMessageKeys;

/**
 * Enumerations representing RDM domain. 
 */
public enum DomainType
{
    RDM_LOGIN(RDMMsgTypes.LOGIN), 
    RDM_DIRECTORY(RDMMsgTypes.DIRECTORY), 
    RDM_DICTIONARY(RDMMsgTypes.DICTIONARY);

    private DomainType(int value)
    {
        this.value = (short)value;
    }

    public static short getValue(DomainType domainType)
    {
        return domainType.value;
    }

    public static DomainType getDomainType(short value)
    {
        switch (value)
        {
            case 1:
                return RDM_LOGIN;
            case 4:
                return RDM_DIRECTORY;
            case 5:
                return RDM_DICTIONARY;
            default:
                throw new ValueAddException(
                        ValueAddMessageKeys.UNSUPPORTED_DOMAIN_TYPE.format(value));
        }
    }

    private short value;
}