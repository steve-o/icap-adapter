package com.thomsonreuters.rfa.valueadd.domainrep.rdm.directory;

import java.util.Iterator;

import com.reuters.rfa.omm.OMMData;
import com.reuters.rfa.omm.OMMEncoder;
import com.reuters.rfa.omm.OMMMap;
import com.reuters.rfa.omm.OMMMapEntry;
import com.reuters.rfa.omm.OMMPool;
import com.reuters.rfa.omm.OMMTypes;
import com.thomsonreuters.rfa.valueadd.domainrep.rdm.directory.RDMDirectory.ServiceList;
import com.thomsonreuters.rfa.valueadd.util.ValueAddException;
import com.thomsonreuters.rfa.valueadd.util.ValueAddMessageKeys;

/**
 * Representation of RDM directory response payload. See RDM Usage guide for more details.
 * <li>Contains {@link ServiceList list} of {@link Service}.
 * <li>Use {@link #getData(OMMPool)} to get encoded OMMMap payload.
 * <li>Similarly, use {@link #RDMDirectoryResponsePayload(OMMData)} or {@link #setData(OMMData)} to clear
 * all previous values and decode OMMData into this object.
 * @see Service
 * @see ServiceList
 */

public class RDMDirectoryResponsePayload
{
    private RDMDirectory.ServiceList rdmServiceList = new RDMDirectory.ServiceList();
    private boolean hasRdmServiceList;
    static final int ENCODER_SIZE_PER_SERVICE = 1024;
    
    public RDMDirectoryResponsePayload()
    {

    }
    
    /**
     * Decode {@link OMMMap} represented by {@link OMMData}.
     * @param payload - OMMMap to decode.
     * @throws ValueAddException if OMMMap is not valid directory response payload.
     */
    public RDMDirectoryResponsePayload(OMMData payload)
    {
        setData(payload);
    }
    
    /**
     * @param pool to acquire OMMData from. 
     * @return Encoded OMMData which is OMMMap for directory response payload.
     * @throws ValueAddException if service list is not present. 
     */
    public OMMData getData(OMMPool pool)
    {
        RDMDirectory.ServiceList rdmSvcList = getServiceList();

        OMMEncoder encoder = pool.acquireEncoder();
        encoder.initialize(OMMTypes.MAP, ENCODER_SIZE_PER_SERVICE * rdmSvcList.size());
        encoder.encodeMapInit(OMMMap.HAS_TOTAL_COUNT_HINT, OMMTypes.ASCII_STRING,
                              OMMTypes.FILTER_LIST, rdmServiceList.size(), (short)0);

        for (Service svcEntry : rdmSvcList)
        {
            svcEntry.encodeEntry(encoder);
        }
        encoder.encodeAggregateComplete();
        OMMData data = (OMMData)encoder.acquireEncodedObject();

        pool.releaseEncoder(encoder);

        return data;
    }

    /**
     * Decode OMMData which needs to be OMMMap.
     * @param payload - OMMData to decode.
     * @throws ValueAddException if OMMData is not valid directory response payload.
     */
    public void setData(OMMData payload)
    {
        if (payload.getType() != OMMTypes.MAP)
        {
            throw new ValueAddException(
                    ValueAddMessageKeys.INVALID_DATA_TYPE.format(OMMTypes.toString(OMMTypes.MAP), OMMTypes.toString(payload.getType())));
        }

        OMMMap data = (OMMMap)payload;

        // decode
        if (payload != null)
        {
            RDMDirectory.ServiceList decodedServices = new RDMDirectory.ServiceList();
            for (Iterator<?> iter = data.iterator(); iter.hasNext();)
            {
                Service service = new Service((OMMMapEntry)iter.next());
                decodedServices.add(service);
            }
            setServiceList(decodedServices);
        }
    }
    
    /**
     * 
     * @param serviceList
     */
    public void setServiceList(RDMDirectory.ServiceList serviceList)
    {
        this.rdmServiceList = serviceList;
        hasRdmServiceList = true;
    }

    /**
     * @return ServiceList - a list of Service. 
     * @throws ValueAddException if service list is not present.
     */
    public RDMDirectory.ServiceList getServiceList()
    {
        if (!hasRdmServiceList)
            throw new ValueAddException(ValueAddMessageKeys.FIELD_NOT_SET.format("ServiceList"));

        return rdmServiceList;
    }

    /**
     * 
     * @return Flag indicating presence of rdm service list.
     */
    public boolean hasServiceList()
    {
        return hasRdmServiceList;
    }

    /**
     * clears the object to make it reusable.
     */
    public void clear()
    {
        hasRdmServiceList = false;
    }
    
    /**
     * Utility method to search service list and return the service with a specified name.
     * @param serviceName Service name to search for the service in service list.
     * @return Service or null if a service is not found.
     */
    public Service getService(String serviceName)
    {
        if(!hasRdmServiceList || rdmServiceList == null)
            return null;
        for(Service service : rdmServiceList)
        {
            if (service != null && (serviceName == service.getServiceName()) || (serviceName != null && serviceName.equals(service.getServiceName())))
                return service;
        }

        return null;
    }
}
