package com.thomsonreuters.rfa.valueadd.util;

import com.reuters.rfa.omm.OMMData;
import com.reuters.rfa.omm.OMMNumeric;
import com.reuters.rfa.omm.OMMState;
import com.thomsonreuters.rfa.valueadd.domainrep.rdm.login.RDMLoginResponse;

/**
 * Collection of utility methods.
 */
public class RDMUtil
{
	public static boolean isLoginSucessful(RDMLoginResponse loginResp)
	{
		return ( loginResp.getMessageType() == RDMLoginResponse.MessageType.STATUS_RESP ||
				loginResp.getMessageType() == RDMLoginResponse.MessageType.REFRESH_RESP)
				&& loginResp.hasRespStatus()
				&& loginResp.getRespStatus().getStreamState() == OMMState.Stream.OPEN
				&& loginResp.getRespStatus().getDataState() == OMMState.Data.OK;

	}

    public static boolean isLoginRejected(RDMLoginResponse loginResp)
    {
        return loginResp.getMessageType() == RDMLoginResponse.MessageType.STATUS_RESP
                && loginResp.hasRespStatus()
                && (loginResp.getRespStatus().getStreamState() == OMMState.Stream.CLOSED || loginResp
                        .getRespStatus().getCode() == OMMState.Code.NOT_ENTITLED);
    }

    public static boolean isLoginStale(RDMLoginResponse loginResp)
    {
        return loginResp.getMessageType() == RDMLoginResponse.MessageType.STATUS_RESP && loginResp.hasRespStatus()
                && loginResp.getRespStatus().getStreamState() == OMMState.Stream.OPEN
                && loginResp.getRespStatus().getDataState() == OMMState.Data.SUSPECT;

    }
    
    public static boolean isLoginSuspect(RDMLoginResponse loginResp)
    {
        return loginResp.getMessageType() == RDMLoginResponse.MessageType.REFRESH_RESP && loginResp.hasRespStatus()
                && loginResp.getRespStatus().getStreamState() == OMMState.Stream.OPEN
                && loginResp.getRespStatus().getDataState() == OMMState.Data.SUSPECT;

    }

    public static long getLongValue(OMMData data)
    {
        return ((OMMNumeric)data).toLong();
    }

    public static boolean getBooleanValue(OMMData data)
    {
        if (data instanceof OMMNumeric)
        {
            return ((OMMNumeric)data).toLong() == 1;
        }
    
        return false;
    }

    public static boolean isFlagSet(int flags, int flag)
    {
        return (flags & flag) != 0;
    }
}
