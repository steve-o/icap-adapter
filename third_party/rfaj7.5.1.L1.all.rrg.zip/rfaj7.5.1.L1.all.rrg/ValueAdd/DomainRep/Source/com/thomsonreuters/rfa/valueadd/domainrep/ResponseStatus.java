package com.thomsonreuters.rfa.valueadd.domainrep;

import com.reuters.rfa.omm.OMMPool;
import com.reuters.rfa.omm.OMMState;

/**
 * Utility class that manages RFAJ's OMMState.
 *
 */
public class ResponseStatus
{
    private byte streamState;
    private byte dataState;
    private short code;
    private String text;

    public ResponseStatus()
    {

    }

    public ResponseStatus(OMMState ommState)
    {
        setStreamState(ommState.getStreamState());
        setDataState(ommState.getDataState());
        setCode(ommState.getCode());
        setText(ommState.getText());
    }
  
    public ResponseStatus(byte streamState, byte dataState, short code, String text)
    {
        setStreamState(streamState);
        setDataState(dataState);
        setCode(code);
        setText(text);
    }

    public byte getStreamState()
    {
        return streamState;
    }

    public void setStreamState(byte streamState)
    {
        this.streamState = streamState;
    }

    public byte getDataState()
    {
        return dataState;
    }

    public void setDataState(byte dataState)
    {
        this.dataState = dataState;
    }

    public short getCode()
    {
        return code;
    }

    public void setCode(short code)
    {
        this.code = code;
    }

    public String getText()
    {
        return text;
    }

    public void setText(String text)
    {
        this.text = text;
    }

    public void setState(OMMState state)
    {
        this.streamState = state.getStreamState();
        this.dataState = state.getDataState();
        this.code = state.getCode();
        this.text = state.getText();
    }

    public OMMState getState(OMMPool pool)
    {
        OMMState state = pool.acquireState();
        state.setStreamState(streamState);
        state.setDataState(dataState);
        state.setCode(code);
        state.setText(text);

        return state;
    }

    public String toString()
    {
        StringBuilder buffer = new StringBuilder(30 + getText().length());
        buffer.append(OMMState.Stream.toString(streamState));
        buffer.append(", ");
        buffer.append(OMMState.Data.toString(dataState));
        buffer.append(", ");

        buffer.append(OMMState.Code.toString(code));

        buffer.append(",  \"");
        buffer.append(getText());
        buffer.append("\"");
        return buffer.toString();
    }
}