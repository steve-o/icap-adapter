package com.thomsonreuters.rfa.valueadd.domainrep.rdm.directory;

import java.util.Iterator;

import com.reuters.rfa.common.QualityOfService;
import com.reuters.rfa.omm.OMMArray;
import com.reuters.rfa.omm.OMMData;
import com.reuters.rfa.omm.OMMDataBuffer;
import com.reuters.rfa.omm.OMMElementEntry;
import com.reuters.rfa.omm.OMMElementList;
import com.reuters.rfa.omm.OMMEncoder;
import com.reuters.rfa.omm.OMMEntry;
import com.reuters.rfa.omm.OMMFilterEntry;
import com.reuters.rfa.omm.OMMFilterList;
import com.reuters.rfa.omm.OMMItemGroup;
import com.reuters.rfa.omm.OMMMap;
import com.reuters.rfa.omm.OMMMapEntry;
import com.reuters.rfa.omm.OMMNumeric;
import com.reuters.rfa.omm.OMMQos;
import com.reuters.rfa.omm.OMMState;
import com.reuters.rfa.omm.OMMTypes;
import com.thomsonreuters.rfa.valueadd.domainrep.ResponseStatus;
import com.thomsonreuters.rfa.valueadd.util.ValueAddException;
import com.thomsonreuters.rfa.valueadd.util.ValueAddListManager;
import com.thomsonreuters.rfa.valueadd.util.ValueAddMessageKeys;
import com.thomsonreuters.rfa.valueadd.util.ValueAddException.ReasonCode;

/**
 * Representation of a service in the directory response payload. See RDM Usage guide for more details.
 * <li>When a field is not set, get method for the field returns default values as specified by the RDM usage guide. 
 *    If there is no default value, get method throws an exception of class ValueAddException.
 * <li>has methods checks if a field is set or not.
 * @see RDMDirectoryResponsePayload 
 */
public class Service
{
    private String serviceName;
    private RDMDirectory.ServiceAction action;
    private Service.InfoFilter info;
    private Service.StateFilter state;
    private Service.GroupFilterList groupList = new Service.GroupFilterList();
    private Service.LoadFilter load;
    private Service.DataFilter data;
    private Service.LinkFilter link;
    private boolean hasServiceName;
    private boolean hasAction;
    private boolean hasInfo;
    private boolean hasState;
    private boolean hasGroupList;
    private boolean hasLoad;
    private boolean hasData;
    private boolean hasLink;

    public Service()
    {

    }

    /**
     * @param mapEntry - OMMMapEntry representing a service in the directory response.
     * @throws ValueAddException if map entry is not valid OMMMapEntry for RDM service.
     */
    public Service(OMMMapEntry mapEntry)
    {
       decodeEntry(mapEntry);
    }

    /**
     * @return Service name.
     * @throws ValueAddException if required service name is not present.
     */
    public String getServiceName()
    {
        if (hasServiceName)
            return serviceName;
        throw new ValueAddException(ReasonCode.MISSING_REQUIRED_FIELD,
                ValueAddMessageKeys.FIELD_NOT_SET.format("ServiceName"));
    }

    /**
     * 
     * @param serviceName
     */
    public void setServiceName(String serviceName)
    {
        this.serviceName = serviceName;
        hasServiceName = true;
    }

    /**
     * 
     * @return Flag indicating presence of ServiceName.
     */
    public boolean hasServiceName()
    {
        return hasServiceName;
    }

    /**
     * @return Service action
     * @throws ValueAddException when Service Action is not present.
     */
    public RDMDirectory.ServiceAction getAction()
    {
        if (hasAction)
            return action;

        throw new ValueAddException(ReasonCode.MISSING_OPTIONAL_FIELD,
                ValueAddMessageKeys.FIELD_NOT_SET.format("Action"));
    }

    /**
     * 
     * @param serviceAction
     */
    public void setAction(RDMDirectory.ServiceAction serviceAction)
    {
        this.action = serviceAction;
        hasAction = true;
    }

    /**
     * 
     * @return Flag indicating presence of ServiceAction.
     */
    public boolean hasAction()
    {
        return hasAction;
    }

    /**
     * @return Info filter
     * @throws ValueAddException when info filter is not present.
     */
    public InfoFilter getInfoFilter()
    {
        if (hasInfo)
            return info;

        throw new ValueAddException(ReasonCode.MISSING_OPTIONAL_FIELD,
                ValueAddMessageKeys.FIELD_NOT_SET.format("InfoFilter"));
    }

    /**
     * 
     * @param infoFilter
     */
    public void setInfoFilter(InfoFilter infoFilter)
    {
        this.info = infoFilter;
        hasInfo = true;
    }

    /**
     * 
     * @return Flag indicating presence of info filter.
     */
    public boolean hasInfoFilter()
    {
        return hasInfo;
    }

    /**
     * @return State filter.
     * @throws ValueAddException when state filter is not present.
     */
    public StateFilter getStateFilter()
    {
        if (hasState)
            return state;

        throw new ValueAddException(ReasonCode.MISSING_OPTIONAL_FIELD,
                ValueAddMessageKeys.FIELD_NOT_SET.format("StateFilter"));
    }

    /**
     * 
     * @param stateFilter
     */
    public void setStateFilter(StateFilter stateFilter)
    {
        this.state = stateFilter;
        hasState = true;
    }

    /**
     * 
     * @return Flag indicating presence of state filter.
     */
    public boolean hasStateFilter()
    {
        return hasState;
    }

    /**
     * There can be more than one group filter for a service. This method returns list of all group filters for a service.
     * @return Group filter list.
     * @throws ValueAddException Group filter is not set.
     */
    public GroupFilterList getGroupFilterList()
    {
        if (!hasGroupList)
            throw new ValueAddException(ReasonCode.MISSING_REQUIRED_FIELD,
                    ValueAddMessageKeys.FIELD_NOT_SET.format("GroupFilterList"));

        return groupList;
    }

    /**
     * 
     * @param groupFilterList
     */
    public void setGroupFilterList(Service.GroupFilterList groupFilterList)
    {
        this.groupList = groupFilterList;
        hasGroupList = true;
    }

    /**
     * 
     * @return Flag indicating presence of group filter list.
     */
    public boolean hasGroupFilterList()
    {
        return hasGroupList;
    }

    /**
     * @return Load filter.
     * @throws ValueAddException when Load filter is not present.
     */
    public LoadFilter getLoadFilter()
    {
        if (hasLoad)
            return load;

        throw new ValueAddException(ReasonCode.MISSING_OPTIONAL_FIELD,
                ValueAddMessageKeys.FIELD_NOT_SET.format("LoadFilter"));
    }

    /**
     * 
     * @param loadFilter
     */
    public void setLoadFilter(LoadFilter loadFilter)
    {
        this.load = loadFilter;
        hasLoad = true;
    }

    /**
     * 
     * @return Flag indicating presence of load filer.
     */
    public boolean hasLoadFilter()
    {
        return hasLoad;
    }

    /**
     * @return Data Filter.
     * @throws ValueAddException if data filter is not present.
     */
    public DataFilter getDataFilter()
    {
        if (hasData)
            return data;

        throw new ValueAddException(ReasonCode.MISSING_OPTIONAL_FIELD,
                ValueAddMessageKeys.FIELD_NOT_SET.format("DataFilter"));
    }

    /**
     * 
     * @param dataFilter
     */
    public void setDataFilter(DataFilter dataFilter)
    {
        this.data = dataFilter;
        hasData = true;
    }

    /**
     * 
     * @return Flag indicating presence of data filter.
     */
    public boolean hasDataFilter()
    {
        return hasData;
    }

    /**
     * @return Link Filter.
     * @throws ValueAddException - if Link filter is not present.
     */
    public LinkFilter getLinkFilter()
    {
        if (hasLink)
            return link;

        throw new ValueAddException(ReasonCode.MISSING_OPTIONAL_FIELD,
                ValueAddMessageKeys.FIELD_NOT_SET.format("LinkFilter"));
    }

    /**
     * 
     * @param linkFilter
     */
    public void setLinkFilter(LinkFilter linkFilter)
    {
        this.link = linkFilter;
        hasLink = true;
    }

    /**
     * 
     * @return Flag indicating presence of link filter.
     */
    public boolean hasLinkFilter()
    {
        return hasLink;
    }

    /**
     * Clears all filters and all presence flags.
     */
    public void clear()
    {
        if (info != null)
            info.clear();
        if (state != null)
            state.clear();
        if (link != null)
            link.clear();
        if (groupList != null)
            groupList.clear();
        if (data != null)
            data.clear();
        if (load != null)
            load.clear();

        hasServiceName = false;
        hasAction = false;
        hasInfo = false;
        hasState = false;
        hasLink = false;
        hasGroupList = false;
        hasData = false;
        hasLoad = false;
    }

    protected final void encodeEntry(OMMEncoder encoder)
    {
        encoder.encodeMapEntryInit(0, action.getValue(), null);
        encoder.encodeString(serviceName, OMMTypes.ASCII_STRING);
        
        int count = 0;
        if (hasInfo && info != null)
            count++;
        if (hasState && state != null)
            count++;
        if (hasGroupList && groupList != null)
            count += groupList.size();
        if (load != null)
            count++;
        if (data != null)
            count++;
        if (link != null)
            count++;
      
        if(action == RDMDirectory.ServiceAction.DELETE)
        {
            if(count == 0)
                return;
            throw new ValueAddException(ValueAddMessageKeys.FILTER_NOT_ALLOWED_FOR_DELETE.format());
        }
        
        encoder.encodeFilterListInit(0, OMMTypes.ELEMENT_LIST, count);

        if (hasInfo && info != null)
        {
            info.encodeEntry(encoder);
        }
        if (hasState && state != null)
        {
            state.encodeEntry(encoder);
        }
        if (hasGroupList && !groupList.isEmpty())
        {
            for(GroupFilter group : groupList)
            {
                group.encodeEntry(encoder);
            }
        }
        if (hasData && data != null)
        {
            data.encodeEntry(encoder);
        }
        if (hasLink && link != null)
        {
            link.encodeEntry(encoder);
        }
        if (hasLoad && load != null)
        {
            load.encodeEntry(encoder);
        }
        encoder.encodeAggregateComplete();
    }

    private final void decodeEntry(OMMMapEntry mapEntry)
    {
        if (mapEntry == null)
            return;

        setServiceName(mapEntry.getKey().toString());
        setAction(RDMDirectory.ServiceAction.getAction(mapEntry.getAction()));
        
        // when action is CLEAR or DELETE, data will be null.
        if(mapEntry.getData() == null)
            return;
        
        if (mapEntry.getDataType() != OMMTypes.FILTER_LIST)
            throw new ValueAddException(
                    ValueAddMessageKeys.INVALID_DATA_TYPE.format(mapEntry.getDataType(),
                                                                 OMMTypes.FILTER_LIST));
        OMMFilterList serviceFilterList = (OMMFilterList)(mapEntry.getData());
        for (Iterator<?> iter = serviceFilterList.iterator(); iter.hasNext();)
        {
            OMMFilterEntry fEntry = (OMMFilterEntry)iter.next();
            switch (fEntry.getFilterId())
            {
                case com.reuters.rfa.rdm.RDMService.FilterId.INFO:
                    info = new Service.InfoFilter(fEntry);
                    hasInfo = true;
                    break;
                case com.reuters.rfa.rdm.RDMService.FilterId.STATE:
                    state = new Service.StateFilter(fEntry);
                    hasState = true;
                    break;
                case com.reuters.rfa.rdm.RDMService.FilterId.GROUP:
                    GroupFilter group = new Service.GroupFilter(fEntry);
                    hasGroupList = true;
                    groupList.add(group);
                    break;
                case com.reuters.rfa.rdm.RDMService.FilterId.LOAD:
                    load = new Service.LoadFilter(fEntry);
                    hasLoad = true;
                    break;
                case com.reuters.rfa.rdm.RDMService.FilterId.DATA:
                    data = new Service.DataFilter(fEntry);
                    hasData = true;
                    break;
                case com.reuters.rfa.rdm.RDMService.FilterId.LINK:
                    if (fEntry.getDataType() == OMMTypes.MAP)
                    {
                        link = new Service.LinkFilter(fEntry);
                        hasLink = true;
                    }
                    // else ELEMENT_LIST for older RDFD is dropped
                    break;
                default:
            }
        }
    }

    /**
     * Representation of an Info filter for the RDM service. See RDM usage guide for more details.
     */
    public static class InfoFilter
    {
        private RDMDirectory.FilterId filterId;
        private RDMDirectory.FilterAction filterAction;
        private boolean hasFilterAction;
        
        private String serviceName;
        private boolean hasServiceName;

        private long serviceId;
        private boolean hasServiceId;

        private String vendor;
        private boolean hasVendor;

        private boolean isSource;
        private boolean hasIsSource;

        private RDMDirectory.CapabilityList capabilityList = new RDMDirectory.CapabilityList();
        private boolean hasCapabilityList;
        private RDMDirectory.DictionaryUsedList dictionaryUsedList = new RDMDirectory.DictionaryUsedList();
        private boolean hasDictionaryUsedList;
        private RDMDirectory.DictionaryProvidedList dictionaryProvidedList = new RDMDirectory.DictionaryProvidedList();
        private boolean hasDictionaryProvidedList;
        private RDMDirectory.QosList qos = new RDMDirectory.QosList();
        private boolean hasQos;
        
        private boolean supportsQosRange;
        boolean hasSupQosRange;

        private String itemList;
        private boolean hasItemList;

        private boolean supportsOutOfBandSnapshots;
        private boolean hasSupOOBSnap;

        private boolean acceptingConsumerStatus;
        private boolean hasAcceptingConsStatus;

        private boolean DEFAULT_IS_SOURCE = false;
        private boolean DEFAULT_SUP_QOSRANGE = false;
        private boolean DEFAULT_SUP_OOB_SNAPSHOTS = true;
        private boolean DEFAULT_ACCEPTING_CONS_STATUS = true;
        private RDMDirectory.FilterAction DEFAULT_FILTER_ACTION = RDMDirectory.FilterAction.SET;
        
        private RDMDirectory.QosList DEFAULT_QOS = new RDMDirectory.QosList();
        {
            DEFAULT_QOS.add(QualityOfService.QOS_REALTIME_TICK_BY_TICK);
        }

        /**
         * Create an Info filter with default RDM values for all elements.
         * see RDMUserGuide for default values. 
         */
        public InfoFilter()
        {
            filterId = RDMDirectory.FilterId.INFO;
            setRDMDefaultValue();
        }

        /**
         * Create an Info filter for a service name with default RDM values for all other elements.
         * see RDMUserGuide for default values. 
         * @param serviceName - service name.
         */
        public InfoFilter(String serviceName)
        {
            filterId = RDMDirectory.FilterId.INFO;
            setRDMDefaultValue();
            this.serviceName = serviceName;
            hasServiceName = true;
        }

        /**
         * Decode an info filter entry.
         * @param filterEntry - OMMFilterEntry to decode.
         * @throws ValueAddException - if OMMFilterEntry is not valid info filter entry.
         */
        public InfoFilter(OMMFilterEntry filterEntry)
        {
            filterId = RDMDirectory.FilterId.INFO;
            setRDMDefaultValue();
            decodeEntry(filterEntry);
        }

        /**
         * 
         * @return FilterId. Always RDMDirectory.FilterId.INFO.
         */
        public RDMDirectory.FilterId getFilterId()
        {
             return filterId;
        }
        
        /**
         * @return Filter action if present. RDMDirectory.FilterAction.SET otherwise.  
         */
        public RDMDirectory.FilterAction getFilterAction()
        {
            if(!hasFilterAction)
                return DEFAULT_FILTER_ACTION;
            return filterAction;
        }

        /**
         * 
         * @param filterAction
         */
        public void setFilterAction(RDMDirectory.FilterAction filterAction)
        {
            this.filterAction = filterAction;
            hasFilterAction = true;
        }

        /**
         * 
         * @return Flag indicating presence of filter action.
         */
        public boolean hasFilterAction()
        {
            return hasFilterAction;
        }

        private final boolean isCorrectEntry(OMMFilterEntry fEntry)
        {
            return fEntry != null && fEntry.getFilterId() == filterId.getValue();
        }
        
        private final void encodeEntry(OMMEncoder encoder)
        {

            if(filterAction == RDMDirectory.FilterAction.CLEAR)
            {
                if(hasServiceId || hasAcceptingConsStatus || hasCapabilityList || hasDictionaryProvidedList ||
                        hasDictionaryUsedList || hasIsSource || hasItemList || hasQos || hasServiceName || hasSupOOBSnap ||
                        hasSupQosRange || hasVendor)
                   throw new ValueAddException(ValueAddMessageKeys.FILTERDATA_NOT_ALLOWED_FOR_CLEAR.format());
                
                return;
            }
            
            if (!hasServiceName || serviceName == null || serviceName.isEmpty())
                throw new ValueAddException(ReasonCode.MISSING_REQUIRED_FIELD,
                        ValueAddMessageKeys.FIELD_NOT_SET.format("Name"));
            if (!hasCapabilityList)
                throw new ValueAddException(ReasonCode.MISSING_REQUIRED_FIELD,
                        ValueAddMessageKeys.FIELD_NOT_SET.format("Capabilities"));

            encoder.encodeFilterEntryInit(OMMFilterEntry.HAS_DATA_FORMAT, RDMDirectory.FilterAction.getValue(getFilterAction()),
                                          getFilterId().getValue(), OMMTypes.ELEMENT_LIST, null);

        
            
            encoder.encodeElementListInit(OMMElementList.HAS_STANDARD_DATA, (short)0, (short)0);
            encoder.encodeElementEntryInit(com.reuters.rfa.rdm.RDMService.Info.Name,
                                           OMMTypes.ASCII_STRING);
            encoder.encodeString(serviceName, OMMTypes.ASCII_STRING);
            encoder.encodeElementEntryInit(com.reuters.rfa.rdm.RDMService.Info.Capabilities,
                                           OMMTypes.ARRAY);
            encoder.encodeArrayInit(OMMTypes.UINT, 0);
            for (RDMDirectory.Capability capability : capabilityList)
            {
                encoder.encodeArrayEntryInit();
                encoder.encodeUInt(capability.getValue());
            }
            encoder.encodeAggregateComplete();

            if (hasVendor)
            {
                encoder.encodeElementEntryInit(com.reuters.rfa.rdm.RDMService.Info.Vendor,
                                               OMMTypes.ASCII_STRING);
                encoder.encodeString(vendor, OMMTypes.ASCII_STRING);
            }
            if (hasIsSource)
            {
                encoder.encodeElementEntryInit(com.reuters.rfa.rdm.RDMService.Info.IsSource,
                                               OMMTypes.UINT);
                encoder.encodeUInt(isSource ? 1 : 0);
            }
            if (hasServiceId)
            {
                encoder.encodeElementEntryInit(com.reuters.rfa.rdm.RDMService.Info.ServiceID,
                                               OMMTypes.UINT);
                encoder.encodeUInt(serviceId);
            }
            if (hasSupQosRange)
            {
                encoder.encodeElementEntryInit(com.reuters.rfa.rdm.RDMService.Info.SupportsQoSRange,
                                               OMMTypes.UINT);
                encoder.encodeUInt(supportsQosRange ? 1 : 0);
            }
            if (hasItemList)
            {
                encoder.encodeElementEntryInit(com.reuters.rfa.rdm.RDMService.Info.ItemList,
                                               OMMTypes.ASCII_STRING);
                encoder.encodeString(itemList, OMMTypes.ASCII_STRING);
            }
            if (hasSupOOBSnap)
            {
                encoder.encodeElementEntryInit(com.reuters.rfa.rdm.RDMService.Info.SupportsOutOfBandSnapshots,
                                               OMMTypes.UINT);
                encoder.encodeUInt(supportsOutOfBandSnapshots ? 1 : 0);
            }
            if (hasAcceptingConsStatus)
            {
                encoder.encodeElementEntryInit(com.reuters.rfa.rdm.RDMService.Info.AcceptingConsumerStatus,
                                               OMMTypes.UINT);
                encoder.encodeUInt(acceptingConsumerStatus ? 1 : 0);
            }
            if (hasDictionaryProvidedList)
            {
                encoder.encodeElementEntryInit(com.reuters.rfa.rdm.RDMService.Info.DictionariesProvided,
                                               OMMTypes.ARRAY);
                encoder.encodeArrayInit(OMMTypes.ASCII_STRING, 0);
                for (int i = 0; i < dictionaryProvidedList.size(); i++)
                {
                    String dictProvided = dictionaryProvidedList.get(i);
                    encoder.encodeArrayEntryInit();
                    encoder.encodeString(dictProvided, OMMTypes.ASCII_STRING);
                }
                encoder.encodeAggregateComplete();
            }
            if (hasDictionaryUsedList)
            {
                encoder.encodeElementEntryInit(com.reuters.rfa.rdm.RDMService.Info.DictionariesUsed,
                                               OMMTypes.ARRAY);
                encoder.encodeArrayInit(OMMTypes.ASCII_STRING, 0);
                for (int i = 0; i < dictionaryUsedList.size(); i++)
                {
                    String dictUsed = dictionaryUsedList.get(i);
                    encoder.encodeArrayEntryInit();
                    encoder.encodeString(dictUsed, OMMTypes.ASCII_STRING);
                }
                encoder.encodeAggregateComplete();
            }
            if (hasQos)
            {
                encoder.encodeElementEntryInit(com.reuters.rfa.rdm.RDMService.Info.QoS,
                                               OMMTypes.ARRAY);
                encoder.encodeArrayInit(OMMTypes.QOS, 0);

                for (int i = 0; i < qos.size(); i++)
                {
                    QualityOfService qOfService = qos.get(i);
                    encoder.encodeArrayEntryInit();
                    encoder.encodeQos(qOfService.getTimeliness(), qOfService.getRate());
                }

                encoder.encodeAggregateComplete();
            }
            encoder.encodeAggregateComplete(); // Completes the ElementList
        }

        private final void decodeEntry(OMMFilterEntry fEntry)
        {
            if (!isCorrectEntry(fEntry))
                throw new ValueAddException(
                        ValueAddMessageKeys.DIR_FILTER_ENTRY_INVALID
                                .format(getFilterId(), fEntry == null ? null : fEntry.getFilterId()));

            clear();
            setFilterAction(RDMDirectory.FilterAction.getFilterAction(fEntry.getAction()));

            if(fEntry.getData() == null)
                return; //for CLEAR, data is null.
            
            if (fEntry.getDataType() != OMMTypes.ELEMENT_LIST)
            {
                throw new ValueAddException(
                        ValueAddMessageKeys.FIELD_NOT_SET.format("Capabilities"));
            }

            decode((OMMElementList)fEntry.getData());

            if (!hasServiceName)
                throw new ValueAddException(ReasonCode.MISSING_REQUIRED_FIELD,
                        ValueAddMessageKeys.FIELD_NOT_SET.format("Name"));

            if (!hasCapabilityList)
                throw new ValueAddException(ReasonCode.MISSING_REQUIRED_FIELD,
                        ValueAddMessageKeys.FIELD_NOT_SET.format("Capabilities"));
        }

        private void decode(OMMElementList eList)
        {
            for (Iterator<?> eliter = eList.iterator(); eliter.hasNext();)
            {
                OMMElementEntry eentry = (OMMElementEntry)eliter.next();
                OMMData edata = eentry.getData();
                if (eentry.getName().compareTo(com.reuters.rfa.rdm.RDMService.Info.Name) == 0)
                {
                    serviceName = (edata.toString());
                    hasServiceName = true;
                }
                else if (eentry.getName().compareTo(com.reuters.rfa.rdm.RDMService.Info.Vendor) == 0)
                {
                    vendor = edata.toString();
                    hasVendor = true;
                }
                else if (eentry.getName().compareTo(com.reuters.rfa.rdm.RDMService.Info.IsSource) == 0)
                {
                    isSource = ((OMMNumeric)edata).toLong() == 1;
                    hasIsSource = true;
                }
                else if (eentry.getName()
                        .compareTo(com.reuters.rfa.rdm.RDMService.Info.Capabilities) == 0)
                {
                    hasCapabilityList = true;
                    if (edata.getType() == OMMTypes.ARRAY)
                    {
                        Iterator<?> aiter = ((OMMArray)edata).iterator();
                        while (aiter.hasNext())
                        {
                            OMMEntry aentry = (OMMEntry)aiter.next();
                            capabilityList.add(RDMDirectory.Capability.getCapability(((OMMNumeric)aentry
                                    .getData()).toLong()));
                        }
                    }
                }
                else if (eentry.getName()
                        .compareTo(com.reuters.rfa.rdm.RDMService.Info.DictionariesProvided) == 0)
                {
                    hasDictionaryProvidedList = true;
                    if (edata.getType() == OMMTypes.ARRAY)
                    {
                        Iterator<?> aiter = ((OMMArray)edata).iterator();
                        while (aiter.hasNext())
                        {
                            OMMEntry aentry = (OMMEntry)aiter.next();
                            dictionaryProvidedList.add(aentry.getData().toString());
                        }
                    }
                }
                else if (eentry.getName()
                        .compareTo(com.reuters.rfa.rdm.RDMService.Info.DictionariesUsed) == 0)
                {
                    hasDictionaryUsedList = true;
                    if (edata.getType() == OMMTypes.ARRAY)
                    {
                        Iterator<?> aiter = ((OMMArray)edata).iterator();
                        while (aiter.hasNext())
                        {
                            OMMEntry aentry = (OMMEntry)aiter.next();
                            dictionaryUsedList.add(aentry.getData().toString());
                        }
                    }
                }
                else if (eentry.getName().compareTo(com.reuters.rfa.rdm.RDMService.Info.QoS) == 0)
                {
                    hasQos = true;
                    if (edata.getType() == OMMTypes.ARRAY)
                    {
                        OMMArray qosArray = (OMMArray)edata;
                        if (OMMTypes.QOS == qosArray.getDataType())
                        {
                            for (Iterator<?> iter = qosArray.iterator(); iter.hasNext();)
                            {
                                OMMEntry entry = (OMMEntry)iter.next();
                                qos.add(((OMMQos)entry.getData()).toQos());
                            }
                        }
                    }
                }
                else if (eentry.getName()
                        .compareTo(com.reuters.rfa.rdm.RDMService.Info.SupportsQoSRange) == 0)
                {
                    supportsQosRange = ((OMMNumeric)edata).toLong() == 1;
                    hasSupQosRange = true;
                }
                else if (eentry.getName().compareTo(com.reuters.rfa.rdm.RDMService.Info.ItemList) == 0)
                {
                    itemList = edata.toString();
                    hasItemList = true;
                }
                else if (eentry.getName()
                        .compareTo(com.reuters.rfa.rdm.RDMService.Info.SupportsOutOfBandSnapshots) == 0)
                {
                    supportsOutOfBandSnapshots = ((OMMNumeric)edata).toLong() == 1;
                    hasSupOOBSnap = true;
                }
                else if (eentry.getName()
                        .compareTo(com.reuters.rfa.rdm.RDMService.Info.AcceptingConsumerStatus) == 0)
                {
                    acceptingConsumerStatus = ((OMMNumeric)edata).toLong() == 1;
                    hasAcceptingConsStatus = true;
                }
                else if (eentry.getName().compareTo(com.reuters.rfa.rdm.RDMService.Info.ServiceID) == 0)
                {
                    serviceId = (int)((OMMNumeric)edata).toLong();
                    hasServiceId = true;
                }
            }
        }

        private void setRDMDefaultValue()
        {
            isSource = DEFAULT_IS_SOURCE;
            qos = DEFAULT_QOS;
            supportsQosRange = DEFAULT_SUP_QOSRANGE;
            supportsOutOfBandSnapshots = DEFAULT_SUP_OOB_SNAPSHOTS;
            acceptingConsumerStatus = DEFAULT_ACCEPTING_CONS_STATUS;
            filterAction = DEFAULT_FILTER_ACTION;
        }

        /**
         * @return Service name.
         * @throws ValueAddException if ServiceName is not present.  
         */
        public String getServiceName()
        {
            if (!hasServiceName)
                throw new ValueAddException(ReasonCode.MISSING_REQUIRED_FIELD,
                        ValueAddMessageKeys.FIELD_NOT_SET.format("ServiceName"));

            return serviceName;
        }

        /**
         * 
         * @param serviceName
         */
        public void setServiceName(String serviceName)
        {
            this.serviceName = serviceName;
            hasServiceName = true;
        }

        /**
         * 
         * @return Flag indicating presence of ServiceName.
         */
        public boolean hasServiceName()
        {
            return hasServiceName;
        }

        /**
         * @return Vendor.
         * @throws ValueAddException if Vendor is not present.  
         */
        public String getVendor()
        {
            if (!hasVendor)
                throw new ValueAddException(ReasonCode.MISSING_OPTIONAL_FIELD,
                        ValueAddMessageKeys.FIELD_NOT_SET.format("Vendor"));
            return vendor;
        }

        /**
         * 
         * @param vendor
         */
        public void setVendor(String vendor)
        {
            hasVendor = true;
            this.vendor = vendor;
        }

        /**
         * 
         * @return Flag indicating presence of vendor field.
         */
        public boolean hasVendor()
        {
            return hasVendor;
        }

        /**
         * @return ServiceId.
         * @throws ValueAddException if ServiceId is not present.  
         */
        public Long getServiceId()
        {
            if (!hasServiceId)
                throw new ValueAddException(ReasonCode.MISSING_OPTIONAL_FIELD,
                        ValueAddMessageKeys.FIELD_NOT_SET.format("ServiceId"));

            return serviceId;
        }

        /**
         * 
         * @param serviceId
         */
        public void setServiceId(long serviceId)
        {
            hasServiceId = true;
            this.serviceId = serviceId;
        }

        /**
         * 
         * @return Flag indicating presence of ServiceId.
         */
        public boolean hasServiceId()
        {
            return hasServiceId;
        }

        /**
         * @return IsSource if it is set. Returns false by default when it's not set. 
         */
        public boolean getIsSource()
        {
            if (!hasIsSource)
                return DEFAULT_IS_SOURCE;

            return isSource;
        }

        /**
         * 
         * @param isSource
         */
        public void setIsSource(boolean isSource)
        {
            this.isSource = isSource;
            hasIsSource = true;
        }

        /**
         * 
         * @return Flag indicating presence of IsSource.
         */
        public boolean hasIsSource()
        {
            return isSource;
        }

        /**
         * @return List of capabilities provided by the service.
         * @throws ValueAddException if capabilities are not set.
         */
        public RDMDirectory.CapabilityList getCapabilityList()
        {
            if (!hasCapabilityList)
                throw new ValueAddException(ReasonCode.MISSING_REQUIRED_FIELD,
                        ValueAddMessageKeys.FIELD_NOT_SET.format("Capabilities"));

            return capabilityList;
        }

        /**
         * 
         * @param capabilityList
         */
        public void setCapabilityList(RDMDirectory.CapabilityList capabilityList)
        {
            this.capabilityList = capabilityList;
            hasCapabilityList = true;
        }

        /**
         * 
         * @return Flag indicating presence of capability list.
         */
        public boolean hasCapabilityList()
        {
            return hasCapabilityList;
        }

        /**
         * @return List of dictionaries provided by the service.
         * @throws ValueAddException if DictionariesProvided are not set.
         */
        public RDMDirectory.DictionaryProvidedList getDictionaryProvidedList()
        {
            if (hasDictionaryProvidedList)
                return dictionaryProvidedList;

            throw new ValueAddException(ReasonCode.MISSING_OPTIONAL_FIELD,
                    ValueAddMessageKeys.FIELD_NOT_SET.format("DictionariesProvided"));
        }

        /**
         * 
         * @param dictionaryProvidedList
         */
        public void setDictionaryProvidedList(RDMDirectory.DictionaryProvidedList dictionaryProvidedList)
        {
            this.dictionaryProvidedList = dictionaryProvidedList;
            hasDictionaryProvidedList = true;
        }

        /**
         * 
         * @return Flag indicating presence of dictionary provided list.
         */
        public boolean hasDictionaryProvidedList()
        {
            return hasDictionaryProvidedList;
        }

        /**
         * @return List of dictionaries used in a service.
         * @throws ValueAddException if DictionariesUsed are not set.
         */
        public RDMDirectory.DictionaryUsedList getDictionaryUsedList()
        {
            if (hasDictionaryUsedList)
                return dictionaryUsedList;

            throw new ValueAddException(ReasonCode.MISSING_OPTIONAL_FIELD,
                    ValueAddMessageKeys.FIELD_NOT_SET.format("DictionariesUsed"));
        }

        /**
         * 
         * @param dictionaryUsedList
         */
        public void setDictionaryUsedList(RDMDirectory.DictionaryUsedList dictionaryUsedList)
        {
            this.dictionaryUsedList = dictionaryUsedList;
            hasDictionaryUsedList = true;
        }

        /**
         * 
         * @return Flag indicating presence of dictionary used list.
         */
        public boolean hasDictionaryUsedList()
        {
            return hasDictionaryUsedList;
        }

        /**
         * @return List of qos provided by the service. If not present, RDM default value of 
         * QualityOfService.QOS_REALTIME_TICK_BY_TICK is returned.
         */
        public RDMDirectory.QosList getQosList()
        {
            if (!hasQos)
                return DEFAULT_QOS;
            return qos;
        }

        /**
         * 
         * @param qosList
         */
        public void setQosList(RDMDirectory.QosList qosList)
        {
            this.qos = qosList;
            hasQos = true;
        }

        /**
         * 
         * @return Flag indicating presence of QOS list.
         */
        public boolean hasQosList()
        {
            return hasQos;
        }

        /**
         * @return SupportsQoSRange. If not set, RDM default value false is returned.
         */
        public boolean getSupportsQoSRange()
        {
            if (!hasSupQosRange)
                return DEFAULT_SUP_QOSRANGE;
            return supportsQosRange;
        }

        /**
         * 
         * @param supportsQoSRange
         */
        public void setSupportsQoSRange(boolean supportsQoSRange)
        {
            this.supportsQosRange = supportsQoSRange;
            hasSupQosRange = true;
        }

        /**
         * 
         * @return Flag indicating presence of supports Qos Range.
         */
        public boolean hasSupportsQoSRange()
        {
            return hasSupQosRange;
        }

        /**
         * @return ItemList.
         * @throws ValueAddException if ItemList is not set.
         */
        public String getItemList()
        {
            if (hasItemList)
                return itemList;
            throw new ValueAddException(ReasonCode.MISSING_OPTIONAL_FIELD,
                    ValueAddMessageKeys.FIELD_NOT_SET.format("ItemList"));
        }

        /**
         * 
         * @param itemList
         */
        public void setItemList(String itemList)
        {
            this.itemList = itemList;
            hasItemList = true;
        }

        /**
         * 
         * @return Flag indicating presence of item list.
         */
        public boolean hasItemList()
        {
            return hasItemList;
        }

        /**
         * @return supportsOutOfBandSnapshots. If not set, RDM default value, true is returned.
         */
        public boolean getSupportsOutOfBandSnapshots()
        {
            if (!hasSupOOBSnap)
                return DEFAULT_SUP_OOB_SNAPSHOTS;
            return supportsOutOfBandSnapshots;
        }

        /**
         * 
         * @param supportsOutOfBandSnapshots
         */
        public void setSupportsOutOfBandSnapshots(boolean supportsOutOfBandSnapshots)
        {
            this.supportsOutOfBandSnapshots = supportsOutOfBandSnapshots;
            hasSupOOBSnap = true;
        }

        /**
         * 
         * @return Flag indicating presence of Supports Out Of Band Snapshots.
         */
        public boolean hasSupportsOutOfBandSnapshots()
        {
            return hasSupOOBSnap;
        }

        /**
         * @return acceptingConsumerStatus. If not set, RDM default value, true is returned.
         */
        public boolean getAcceptingConsumerStatus()
        {
            if (!hasAcceptingConsStatus)
                return DEFAULT_ACCEPTING_CONS_STATUS;
            return acceptingConsumerStatus;
        }

        /**
         * 
         * @param acceptingConsumerStatus
         */
        public void setAcceptingConsumerStatus(boolean acceptingConsumerStatus)
        {
            this.acceptingConsumerStatus = acceptingConsumerStatus;
            hasAcceptingConsStatus = true;
        }

        /**
         * 
         * @return Flag indicating presence of accepting consumer status.
         */
        public boolean hasAcceptingConsumerStatus()
        {
            return hasAcceptingConsStatus;
        }

        /**
         * Clears the presence flags and sets all fields to their rdm default values.
         */
        public void clear()
        {
            hasFilterAction = false;
            hasServiceName = false;
            hasServiceId = false;
            hasVendor = false;
            hasSupQosRange = false;
            hasItemList = false;
            hasSupOOBSnap = false;
            hasAcceptingConsStatus = false;
            hasCapabilityList = false;
            hasQos = false;
            hasDictionaryProvidedList = false;
            hasDictionaryUsedList = false;
            setRDMDefaultValue();
        }
    }

    /**
     * Representation of State Filter for a service. It can be in directory update or refresh response messages.
     * see RDMUsageGuide for more details.
     */
    public static class StateFilter
    {
        private RDMDirectory.FilterId filterId;
        private RDMDirectory.FilterAction filterAction;
        private boolean hasFilterAction;
        
        private boolean serviceUp;
        private boolean hasServiceUp;

        private boolean acceptingRequests;
        private boolean hasAcceptingRequests;

        private ResponseStatus status = new ResponseStatus();
        private boolean hasStatus;
        
        private RDMDirectory.FilterAction DEFAULT_FILTER_ACTION = RDMDirectory.FilterAction.SET;
        private boolean DEFAULT_ACCEPTING_REQUEST = true;
        private ResponseStatus DEFAULT_STATUS = new ResponseStatus();
        {
            DEFAULT_STATUS.setCode(OMMState.Code.NONE);
            DEFAULT_STATUS.setDataState(OMMState.Data.OK);
            DEFAULT_STATUS.setStreamState(OMMState.Stream.OPEN);
            DEFAULT_STATUS.setText("");
        }

        /**
         * Create an State filter with default RDM values for all elements.
         * see RDMUsageGuide for default values. 
         */
        public StateFilter()
        {
            filterId = RDMDirectory.FilterId.STATE;
            setRDMDefaultValues();
        }

        /**
         * Create an State filter for a specified service state with default RDM values for all other elements.
         * see RDMUsageGuide for default values. 
         */
        public StateFilter(boolean isUp)
        {
            filterId = RDMDirectory.FilterId.STATE;
            setRDMDefaultValues();
            this.serviceUp = isUp;
            hasServiceUp = true;
        }

        /**
         * Decode a State filter entry. For an optional field, RDM default value is used if it is not set.
         * @param filterEntry
         * @throws ValueAddException if OMMFilterEntry is not valid state filter entry.
         */
        public StateFilter(OMMFilterEntry filterEntry)
        {
            filterId = RDMDirectory.FilterId.STATE;
            setRDMDefaultValues();
            decodeEntry(filterEntry);
        }
        
        /**
         * @return Always RDMDirectory.FilterId.STATE
         */
        public RDMDirectory.FilterId getFilterId()
        {
             return filterId;
        }
        
        /**
         * @return FilterAction for the state filter. RDMDirectory.FilterAction.SET if not set.
         */
        public RDMDirectory.FilterAction getFilterAction()
        {
            if(!hasFilterAction)
               return DEFAULT_FILTER_ACTION;
            return filterAction;
        }

        /**
         * 
         * @param filterAction
         */
        public void setFilterAction(RDMDirectory.FilterAction filterAction)
        {
            this.filterAction = filterAction;
            hasFilterAction = true;
        }

        /**
         * 
         * @return Flag indicating presence of FilterAction.
         */
        public boolean hasFilterAction()
        {
            return hasFilterAction;
        }
        
        private final boolean isCorrectEntry(OMMFilterEntry fEntry)
        {
            return fEntry != null && fEntry.getFilterId() == filterId.getValue();
        }
        
        private final void encodeEntry(OMMEncoder encoder)
        {
            if(filterAction == RDMDirectory.FilterAction.CLEAR)
            {
                if(hasAcceptingRequests || hasStatus || hasServiceUp)
                   throw new ValueAddException(ValueAddMessageKeys.FILTERDATA_NOT_ALLOWED_FOR_CLEAR.format());
                
                return;
            }
   
            if (!hasServiceUp)
            {
                throw new ValueAddException(ReasonCode.MISSING_REQUIRED_FIELD,
                        ValueAddMessageKeys.FIELD_NOT_SET.format("ServiceState"));
            }
            encoder.encodeFilterEntryInit(OMMFilterEntry.HAS_DATA_FORMAT, RDMDirectory.FilterAction.getValue(getFilterAction()),
                                          getFilterId().getValue(), OMMTypes.ELEMENT_LIST, null);
            
            encoder.encodeElementListInit(OMMElementList.HAS_STANDARD_DATA, (short)0, (short)0);
            encoder.encodeElementEntryInit(com.reuters.rfa.rdm.RDMService.SvcState.ServiceState,
                                           OMMTypes.UINT);
            encoder.encodeUInt(serviceUp ? 1 : 0);
            if (hasAcceptingRequests)
            {
                encoder.encodeElementEntryInit(com.reuters.rfa.rdm.RDMService.SvcState.AcceptingRequests,
                                               OMMTypes.UINT);
                encoder.encodeUInt(acceptingRequests ? 1 : 0);
            }
            if (hasStatus)
            {
                encoder.encodeElementEntryInit(com.reuters.rfa.rdm.RDMService.SvcState.Status,
                                               OMMTypes.STATE);
                encoder.encodeState(status.getStreamState(), status.getDataState(),
                                    status.getCode(), status.getText());
            }
            encoder.encodeAggregateComplete();
        }

        private final void decodeEntry(OMMFilterEntry fEntry)
        {
            if (!isCorrectEntry(fEntry))
                throw new ValueAddException(
                        ValueAddMessageKeys.DIR_FILTER_ENTRY_INVALID
                                .format(getFilterId(), fEntry == null ? null : fEntry.getFilterId()));

            clear();
            setFilterAction(RDMDirectory.FilterAction.getFilterAction(fEntry.getAction()));
            if(fEntry.getData() == null)
                return; //for CLEAR, data is null.
            if (fEntry.getDataType() != OMMTypes.ELEMENT_LIST)
            {
                throw new ValueAddException(ValueAddMessageKeys.INVALID_DATA_TYPE.format(fEntry
                        .getDataType(), OMMTypes.ELEMENT_LIST));
            }

            decode((OMMElementList)fEntry.getData());
            if (!hasServiceUp)
            {
                throw new ValueAddException(ReasonCode.MISSING_REQUIRED_FIELD,
                        ValueAddMessageKeys.FIELD_NOT_SET.format("ServiceState"));
            }
        }

        private void decode(OMMElementList eList)
        {
            for (Iterator<?> eliter = eList.iterator(); eliter.hasNext();)
            {
                OMMElementEntry eentry = (OMMElementEntry)eliter.next();
                if (eentry.getName().equals(com.reuters.rfa.rdm.RDMService.SvcState.ServiceState))
                {
                    serviceUp = ((OMMNumeric)eentry.getData()).toLong() == com.reuters.rfa.rdm.RDMService.State.UP;
                    hasServiceUp = true;
                }
                else if (eentry.getName()
                        .equals(com.reuters.rfa.rdm.RDMService.SvcState.AcceptingRequests))
                {
                    acceptingRequests = ((OMMNumeric)eentry.getData()).toLong() == com.reuters.rfa.rdm.RDMService.State.UP;
                    hasAcceptingRequests = true;
                }
                else if (eentry.getName().equals(com.reuters.rfa.rdm.RDMService.SvcState.Status))
                {
                    status.setState((OMMState)eentry.getData());
                    hasStatus = true;
                }
            }

        }

        /**
         * @return ServiceState for the state filter.
         * @throws ValueAddException if ServiceState is not present.
         */
        public boolean getServiceUp()
        {
            if (!hasServiceUp)
                throw new ValueAddException(ReasonCode.MISSING_REQUIRED_FIELD,
                        ValueAddMessageKeys.FIELD_NOT_SET.format("ServiceState"));

            return serviceUp;
        }

        /**
         * 
         * @param serviceState
         */
        public void setServiceUp(boolean serviceState)
        {
            this.serviceUp = serviceState;
            hasServiceUp = true;
        }

        /**
         * 
         * @return Flag indicating presence of service up field.
         */
        public boolean hasServiceUp()
        {
            return hasServiceUp;
        }

        /**
         * 
         * @param acceptingRequests
         */
        public void setAcceptingRequests(boolean acceptingRequests)
        {
            this.acceptingRequests = acceptingRequests;
            hasAcceptingRequests = true;
        }

        /**
         * @return AcceptingRequests. Returns RDM default value, true when AcceptingRequests is not set.
         */
        public boolean getAcceptingRequests()
        {
            if (!hasAcceptingRequests)
                return DEFAULT_ACCEPTING_REQUEST;

            return acceptingRequests;
        }

        /**
         * 
         * @return Flag indicating presence of AcceptingRequests.
         */
        public boolean hasAcceptingRequests()
        {
            return hasAcceptingRequests;
        }

        /**
         * @return Status for the state filter. Returnds RDM Default value, OPEN,OK,NONE,"" status when Status field is not set.
         */
        public ResponseStatus getStatus()
        {
            if (!hasStatus)
                return DEFAULT_STATUS;
            return status;
        }

        /**
         * 
         * @param status
         */
        public void setStatus(ResponseStatus status)
        {
            hasStatus = true;
            this.status = status;
        }

        /**
         * 
         * @return Flag indicating presence of status field.
         */
        public boolean hasStatus()
        {
            return hasStatus;
        }

        /**
         * Clears presence flags and sets optional fields to their RDM default values.
         */
        public void clear()
        {
            hasFilterAction = false;
            hasServiceUp = false;
            hasStatus = false;
            hasAcceptingRequests = false;

            setRDMDefaultValues();
        }

        private void setRDMDefaultValues()
        {
            acceptingRequests = DEFAULT_ACCEPTING_REQUEST;
            status = DEFAULT_STATUS;
            filterAction = DEFAULT_FILTER_ACTION;
        }
    }

    /**
     * List of group filters that can be present in a service.
     * @see ValueAddListManager
     */
    public static class GroupFilterList extends ValueAddListManager<GroupFilter>
    {
    }
    
    /**
     * Representation of a group filter for a RDM Service.  
     */
    public static class GroupFilter
    {
        private RDMDirectory.FilterId filterId;
        private RDMDirectory.FilterAction filterAction;
        private boolean hasFilterAction;
        
        private ResponseStatus status = new ResponseStatus();
        private boolean hasStatus;

        private OMMItemGroup group = null;
        private boolean hasGroup = false;

        private OMMItemGroup mergedToGroup = null;
        private boolean hasMergedToGroup = false;
        private RDMDirectory.FilterAction DEFAULT_FILTER_ACTION = RDMDirectory.FilterAction.SET;
        private ResponseStatus DEFAULT_STATUS = new ResponseStatus();
        {
            DEFAULT_STATUS.setCode(OMMState.Code.NONE);
            DEFAULT_STATUS.setDataState(OMMState.Data.OK);
            DEFAULT_STATUS.setStreamState(OMMState.Stream.OPEN);
            DEFAULT_STATUS.setText("");
        }

        /**
         * Create a group filter with RDM default values for optional fields.
         */
        public GroupFilter()
        {
            filterId = RDMDirectory.FilterId.GROUP;
            setRDMDefaultValues();
        }

        /**
         * Decode a Group filter entry. If an element is not present, RDM default value is used for that element.
         * @throws ValueAddException if OMMFilterEntry not valid group filter entry.
         */
        public GroupFilter(OMMFilterEntry fEntry)
        {
            filterId = RDMDirectory.FilterId.GROUP;
            setRDMDefaultValues();
            decodeEntry(fEntry);
        }
        
        /**
         * 
         * @return Filter Action for group filter. Returns RDMDirectory.FilterAction.SET if action is not set.
         */
        public RDMDirectory.FilterAction getFilterAction()
        {
            if(!hasFilterAction)
                return DEFAULT_FILTER_ACTION;
            return filterAction;
        }

        /**
         * 
         * @param filterAction
         */
        public void setFilterAction(RDMDirectory.FilterAction filterAction)
        {
            this.filterAction = filterAction;
            hasFilterAction = true;
        }

        /**
         * 
         * @return Flag indicating presence of FilterAction.
         */
        public boolean hasFilterAction()
        {
            return hasFilterAction;
        }
        
        /**
         * @return  Always RDMDirectory.FilterId.GROUP
         */
        public RDMDirectory.FilterId getFilterId()
        {
             return filterId;
        }

        private final boolean isCorrectEntry(OMMFilterEntry fEntry)
        {
            return fEntry != null && fEntry.getFilterId() == filterId.getValue();
        }
        
        private final void encodeEntry(OMMEncoder encoder)
        {
            if(filterAction == RDMDirectory.FilterAction.CLEAR)
            {
                if(hasGroup || hasStatus || hasMergedToGroup)
                   throw new ValueAddException(ValueAddMessageKeys.FILTERDATA_NOT_ALLOWED_FOR_CLEAR.format());
                
                return;
            }
            
            if (!hasGroup)
                throw new ValueAddException(ReasonCode.MISSING_REQUIRED_FIELD,
                        ValueAddMessageKeys.FIELD_NOT_SET.format("Group"));

            encoder.encodeFilterEntryInit(OMMFilterEntry.HAS_DATA_FORMAT, RDMDirectory.FilterAction.getValue(getFilterAction()),
                                          getFilterId().getValue(), OMMTypes.ELEMENT_LIST, null);
        
            
            encoder.encodeElementListInit(OMMElementList.HAS_STANDARD_DATA, (short)0, (short)0);
            encoder.encodeElementEntryInit(com.reuters.rfa.rdm.RDMService.Group.Group,
                                           OMMTypes.BUFFER);
            encoder.encodeBytes(group.getBytes());
            if (hasStatus)
            {
                encoder.encodeElementEntryInit(com.reuters.rfa.rdm.RDMService.Group.Status,
                                               OMMTypes.STATE);
                encoder.encodeState(status.getStreamState(), status.getDataState(), status.getCode(), status.getText());
            }
            if (hasMergedToGroup)
            {
                encoder.encodeElementEntryInit(com.reuters.rfa.rdm.RDMService.Group.MergedToGroup,
                                               OMMTypes.BUFFER);
                encoder.encodeBytes(mergedToGroup.getBytes());
            }
            encoder.encodeAggregateComplete();
        }

        private final void decodeEntry(OMMFilterEntry fEntry)
        {
            if (!isCorrectEntry(fEntry))
                throw new ValueAddException(
                        ValueAddMessageKeys.DIR_FILTER_ENTRY_INVALID
                                .format(getFilterId(), fEntry == null ? null : fEntry.getFilterId()));

            clear();
            setFilterAction(RDMDirectory.FilterAction.getFilterAction(fEntry.getAction()));
            if(fEntry.getData() == null)
                return; //for CLEAR, data is null.
            if (fEntry.getDataType() != OMMTypes.ELEMENT_LIST)
            {
                throw new ValueAddException(
                        ValueAddMessageKeys.INVALID_DATA_TYPE.format(OMMTypes.ELEMENT_LIST,
                                                                     fEntry.getDataType()));
            }

            decode((OMMElementList)fEntry.getData());
            if (!hasGroup)
            {
                throw new ValueAddException(ReasonCode.MISSING_REQUIRED_FIELD,
                        ValueAddMessageKeys.FIELD_NOT_SET.format("Group"));
            }
        }

        private void decode(OMMElementList eList)
        {
            for (Iterator<?> eliter = eList.iterator(); eliter.hasNext();)
            {
                OMMElementEntry eentry = (OMMElementEntry)eliter.next();

                if (eentry.getName().equals(com.reuters.rfa.rdm.RDMService.Group.Group))
                {
                    OMMDataBuffer db = (OMMDataBuffer)eentry.getData();
                    group = OMMItemGroup.create(db.getBytes());
                    hasGroup = true;
                }
                else if (eentry.getName()
                        .equals(com.reuters.rfa.rdm.RDMService.Group.MergedToGroup))
                {
                    OMMDataBuffer db = (OMMDataBuffer)eentry.getData();
                    mergedToGroup = OMMItemGroup.create(db.getBytes());
                    hasMergedToGroup = true;
                }
                else if (eentry.getName().equals(com.reuters.rfa.rdm.RDMService.Group.Status))
                {
                    status.setState((OMMState)eentry.getData());
                    hasStatus = true;
                }
            }
        }

      

        /**
         * @return Group status. If not set, RDM default, OPEN,OK,NONE,""
         */
        public ResponseStatus getStatus()
        {
            if (!hasStatus)
                return DEFAULT_STATUS;
            return status;
        }

        /**
         * 
         * @param status
         */
        public void setStatus(ResponseStatus status)
        {
            this.status = status;
            hasStatus = true;
        }
        
        /**
         * 
         * @return Flag indicating presence of status field.
         */
        public boolean hasStatus()
        {
            return hasStatus;
        }

        /**
         * @return Group field for the group filter.
         * @throws ValueAddException if group is not present.
         */
        public OMMItemGroup getGroup()
        {
            if (!hasGroup)
                throw new ValueAddException(ReasonCode.MISSING_OPTIONAL_FIELD,
                        ValueAddMessageKeys.FIELD_NOT_SET.format("Group"));
            return group;
        }

        /**
         * 
         * @param group
         */
        public void setGroup(OMMItemGroup group)
        {
            hasGroup = true;
            this.group = group;
        }

        /**
         * 
         * @return Flag indicating presence of group field.
         */
        public boolean hasGroup()
        {
            return hasGroup;
        }

        /**
         * @return Merged group field. 
         * @throws ValueAddException if merge to group is not set.
         */
        public OMMItemGroup getMergedToGroup()
        {
            if (!hasMergedToGroup)
                throw new ValueAddException(ReasonCode.MISSING_OPTIONAL_FIELD,
                        ValueAddMessageKeys.FIELD_NOT_SET.format("MergedToGroup"));
            return mergedToGroup;
        }

        /**
         * 
         * @param mergedToGroup
         */
        public void setMergedToGroup(OMMItemGroup mergedToGroup)
        {
            hasMergedToGroup = true;
            this.mergedToGroup = mergedToGroup;
        }

        /**
         * 
         * @return Flag indicating merged to group field.
         */
        public boolean hasMergedToGroup()
        {
            return hasMergedToGroup;
        }

        private void setRDMDefaultValues()
        {
            filterAction = DEFAULT_FILTER_ACTION;
            status = DEFAULT_STATUS;
        }

        /**
         * Clears presence flags and sets values of optional fields to RDM default values.
         */
        public void clear()
        {
            hasFilterAction = false;
            hasStatus = false;
            hasGroup = false;
            hasMergedToGroup = false;
            setRDMDefaultValues();
        }
    }

    
    /**
     * Representation of a load filter for the service.
     * See RDMUsageGuide for more details. 
     */
    public static class LoadFilter
    {
        private RDMDirectory.FilterId filterId;
        private RDMDirectory.FilterAction filterAction;
        private boolean hasFilterAction;
        
        private long openLimit;
        private boolean hasOpenLimit;

        private long openWindow;
        private boolean hasOpenWindow;

        private int loadFactor;
        private boolean hasLoadFactor;
        private RDMDirectory.FilterAction DEFAULT_FILTER_ACTION = RDMDirectory.FilterAction.SET;
        
        /**
         * Create a Load filter with RDM default values for optional fields.
         */
        public LoadFilter()
        {
            filterId = RDMDirectory.FilterId.LOAD;
            setRDMDefaultValues();
        }

        /**
         * Decode a Load filter entry for the service.
         * @param filterEntry to decode.
         * @throws ValueAddException if OMMFilterEntry is not valid Load Filter entry.
         */
        public LoadFilter(OMMFilterEntry filterEntry)
        {
            filterId = RDMDirectory.FilterId.LOAD;
            setRDMDefaultValues();
            decodeEntry(filterEntry);
        }

        /**
         * @return Filter action. RDMDirectory.FilterAction.SET if filter action field is not set.
         */
        public RDMDirectory.FilterAction getFilterAction()
        {
            if(!hasFilterAction)
                return DEFAULT_FILTER_ACTION;
            return filterAction;
        }

        /**
         * 
         * @param filterAction
         */
        public void setFilterAction(RDMDirectory.FilterAction filterAction)
        {
            this.filterAction = filterAction;
            hasFilterAction = true;
        }

        /**
         * 
         * @return Flag indicating presence of FilterAction.
         */
        public boolean hasFilterAction()
        {
            return hasFilterAction;
        }
        
        /**
         * @return Always RDMDirectory.FilterId.LOAD
         */
        public RDMDirectory.FilterId getFilterId()
        {
             return filterId;
        }

        private final boolean isCorrectEntry(OMMFilterEntry fEntry)
        {
            return fEntry != null && fEntry.getFilterId() == filterId.getValue();
        }
        
        private final void encodeEntry(OMMEncoder encoder)
        {
            if(filterAction == RDMDirectory.FilterAction.CLEAR)
            {
                if(hasOpenLimit || hasOpenWindow || hasLoadFactor)
                   throw new ValueAddException(ValueAddMessageKeys.FILTERDATA_NOT_ALLOWED_FOR_CLEAR.format());
                
                return;
            }
            
            if (!(hasOpenLimit || hasOpenWindow || hasLoadFactor))
                return;

            encoder.encodeFilterEntryInit(0, RDMDirectory.FilterAction.getValue(getFilterAction()), getFilterId().getValue(),
                                          OMMTypes.ELEMENT_LIST, null);
            
            
            encoder.encodeElementListInit(OMMElementList.HAS_STANDARD_DATA, (short)0, (short)0);
            if (hasOpenLimit)
            {
                encoder.encodeElementEntryInit(com.reuters.rfa.rdm.RDMService.Load.OpenLimit,
                                               OMMTypes.UINT);
                encoder.encodeUInt(openLimit);
            }
            if (hasOpenWindow)
            {
                encoder.encodeElementEntryInit(com.reuters.rfa.rdm.RDMService.Load.OpenWindow,
                                               OMMTypes.UINT);
                encoder.encodeUInt(openWindow);
            }
            if (hasLoadFactor)
            {
                encoder.encodeElementEntryInit(com.reuters.rfa.rdm.RDMService.Load.LoadFactor,
                                               OMMTypes.UINT);
                encoder.encodeUInt(loadFactor);
            }
            encoder.encodeAggregateComplete();
        }

        private final void decodeEntry(OMMFilterEntry fEntry)
        {
            if (!isCorrectEntry(fEntry))
                throw new ValueAddException(
                        ValueAddMessageKeys.DIR_FILTER_ENTRY_INVALID
                                .format(getFilterId(), fEntry == null ? null : fEntry.getFilterId()));

            clear();
            setFilterAction(RDMDirectory.FilterAction.getFilterAction(fEntry.getAction()));
            if(fEntry.getData() == null)
                return; //for CLEAR, data is null.
            if (fEntry.getDataType() != OMMTypes.ELEMENT_LIST)
                throw new ValueAddException(ValueAddMessageKeys.INVALID_DATA_TYPE.format(fEntry
                        .getDataType(), OMMTypes.ELEMENT_LIST));

            decode((OMMElementList)fEntry.getData());
        }

        private void decode(OMMElementList eList)
        {
            for (Iterator<?> eliter = eList.iterator(); eliter.hasNext();)
            {
                OMMElementEntry eentry = (OMMElementEntry)eliter.next();
                if (eentry.getName().compareTo(com.reuters.rfa.rdm.RDMService.Load.OpenLimit) == 0)
                {
                    openLimit = ((OMMNumeric)eentry.getData()).toLong();
                    hasOpenLimit = true;
                }
                else if (eentry.getName().compareTo(com.reuters.rfa.rdm.RDMService.Load.LoadFactor) == 0)
                {
                    loadFactor = (int)((OMMNumeric)eentry.getData()).toLong();
                    hasLoadFactor = true;
                }
                else if (eentry.getName().compareTo(com.reuters.rfa.rdm.RDMService.Load.OpenWindow) == 0)
                {
                    openWindow = ((OMMNumeric)eentry.getData()).toLong();
                    hasOpenWindow = true;
                }
            }
        }
        private void setRDMDefaultValues()
        {
            filterAction = DEFAULT_FILTER_ACTION;
        }
        
        /**
         * @return OpenLimit.
         * @throws ValueAddException if OpenLimit is not set.
         */
        public long getOpenLimit()
        {
            if (!hasOpenLimit)
                throw new ValueAddException(ReasonCode.MISSING_OPTIONAL_FIELD,
                        ValueAddMessageKeys.FIELD_NOT_SET.format("OpenLimit"));
            return openLimit;
        }

        /**
         * 
         * @param openLimit
         */
        public void setOpenLimit(long openLimit)
        {
            this.openLimit = openLimit;
            hasOpenLimit = true;
        }

        /**
         * 
         * @return Flag indicating presence of OpenLimit.
         */
        public boolean hasOpenLimit()
        {
            return hasOpenLimit;
        }

        /**
         * @return OpenWindow.
         * @throws ValueAddException if OpenWindow is not present.
         */
        public long getOpenWindow()
        {
            if (!hasOpenWindow)
                throw new ValueAddException(ReasonCode.MISSING_OPTIONAL_FIELD,
                        ValueAddMessageKeys.FIELD_NOT_SET.format("OpenWindow"));

            return openWindow;
        }

        /**
         * 
         * @param openWindow
         */
        public void setOpenWindow(long openWindow)
        {
            this.openWindow = openWindow;
            hasOpenWindow = true;
        }

        public boolean hasOpenWindow()
        {
            return hasOpenWindow;
        }

        /**
         * @return LoadFactor.
         * @throws ValueAddException if LoadFactor is not set.
         */
        public int getLoadFactor()
        {
            if (!hasLoadFactor)
                throw new ValueAddException(ReasonCode.MISSING_OPTIONAL_FIELD,
                        ValueAddMessageKeys.FIELD_NOT_SET.format("LoadFactor"));
 
            return loadFactor;
        }

        /**
         * 
         * @param loadFactor
         */
        public void setLoadFactor(int loadFactor)
        {
            this.loadFactor = loadFactor;
            hasLoadFactor = true;
        }

        /**
         * 
         * @return Flag indicating presence of LoadFactor.
         */
        public boolean hasLoadFactor()
        {
            return hasLoadFactor;
        }

        /**
         * Clears presence flags and sets default RDM values for optional fields.
         */
        public void clear()
        {
            hasFilterAction = false;
            hasOpenLimit = false;
            hasLoadFactor = false;
            hasOpenWindow = false;
            setRDMDefaultValues();
        }
    }

    /**
     * Representation of Data filter for the service.
     * See RDMUsageGuide for more details. 
     */
    public static class DataFilter
    {
        /**
         * Enumeration representing valid values for Type field in the DataFilter. 
         */
        public enum DataType
        {
            TIME(1), ALERT(2), HEADLINE(3), STATUS(4), RESERVED(0);

            private int value;

            private DataType(int value)
            {
                this.value = value;
            }

            static int getValue(DataType dataType)
            {
                return dataType.value;
            }

            static DataType getDataType(int value)
            {
                switch (value)
                {
                    case 1:
                        return TIME;
                    case 2:
                        return ALERT;
                    case 3:
                        return HEADLINE;
                    case 4:
                        return STATUS;
                    default:
                        return RESERVED;
                }
            }
        }

        private RDMDirectory.FilterId filterId;
        private RDMDirectory.FilterAction filterAction;
        private boolean hasFilterAction;
        
        private DataFilter.DataType type;
        private boolean hasType;

        private byte[] data;
        private boolean hasData;
        private RDMDirectory.FilterAction DEFAULT_FILTER_ACTION = RDMDirectory.FilterAction.SET;
        
        
        /**
         * Create a data filter with RDM default values.
         */
        public DataFilter()
        {
            filterId = RDMDirectory.FilterId.DATA;
            setRDMDefaultValues();
        }

        /**
         * Decode a Data Filter entry.
         * @param filterEntry - Entry to decode
         * @throws ValueAddException if OMMFilterEntry is not value Data filter entry.
         */
        public DataFilter(OMMFilterEntry filterEntry)
        {
            filterId = RDMDirectory.FilterId.DATA;
            setRDMDefaultValues();
            decodeEntry(filterEntry);
        }

        /**
         * @return FilterAction. RDMDirectory.FilterAction.SET if field is not set.
         */
        public RDMDirectory.FilterAction getFilterAction()
        {
            if(!hasFilterAction)
                return DEFAULT_FILTER_ACTION;
            return filterAction;
        }

        /**
         * 
         * @param filterAction
         */
        public void setFilterAction(RDMDirectory.FilterAction filterAction)
        {
            this.filterAction = filterAction;
            hasFilterAction = true;
        }

        /**
         * 
         * @return Flag indicating presence of filter action.
         */
        public boolean hasFilterAction()
        {
            return hasFilterAction;
        }
        
        /**
         * @return Always RDMDirectory.FilterId.DATA
         */
        public RDMDirectory.FilterId getFilterId()
        {
             return filterId;
        }

        private final boolean isCorrectEntry(OMMFilterEntry fEntry)
        {
            return fEntry != null && fEntry.getFilterId() == filterId.getValue();
        }
        
        private final void encodeEntry(OMMEncoder encoder)
        {
            if(filterAction == RDMDirectory.FilterAction.CLEAR)
            {
                if(hasType || hasData)
                   throw new ValueAddException(ValueAddMessageKeys.FILTERDATA_NOT_ALLOWED_FOR_CLEAR.format());
                
                return;
            }
            
            if (!(hasType || hasData)) // not allowing empty filter entry
                return;
            encoder.encodeFilterEntryInit(OMMFilterEntry.HAS_DATA_FORMAT, RDMDirectory.FilterAction.getValue(getFilterAction()),
                                          getFilterId().getValue(), OMMTypes.ELEMENT_LIST, null);
            
            //Ignore/Discard all data for CLEAR action
            if(filterAction == RDMDirectory.FilterAction.CLEAR)
                return;
            
            encoder.encodeElementListInit(OMMElementList.HAS_STANDARD_DATA, (short)0, (short)0);

            if (hasType)
            {
                encoder.encodeElementEntryInit(com.reuters.rfa.rdm.RDMService.Data.Type,
                                               OMMTypes.UINT);
                encoder.encodeUInt(DataType.getValue(type));
            }
            if (hasData)
            {
                encoder.encodeElementEntryInit(com.reuters.rfa.rdm.RDMService.Data.Data,
                                               OMMTypes.BUFFER);
                encoder.encodeBytes(data);
            }
            encoder.encodeAggregateComplete();
        }

        private final void decodeEntry(OMMFilterEntry fEntry)
        {
            if (!isCorrectEntry(fEntry))
                throw new ValueAddException(
                        ValueAddMessageKeys.DIR_FILTER_ENTRY_INVALID
                                .format(getFilterId(), fEntry == null ? null : fEntry.getFilterId()));

            clear();
            setFilterAction(RDMDirectory.FilterAction.getFilterAction(fEntry.getAction()));
            if(fEntry.getData() == null)
                return; //for CLEAR, data is null.
            if (fEntry.getDataType() != OMMTypes.ELEMENT_LIST)
            {
                throw new ValueAddException(ValueAddMessageKeys.INVALID_DATA_TYPE.format(fEntry
                        .getDataType(), OMMTypes.ELEMENT_LIST));
            }

            decode((OMMElementList)fEntry.getData());
            if (hasData && !hasType)
            {
                throw new ValueAddException(ReasonCode.MISSING_REQUIRED_FIELD,
                        ValueAddMessageKeys.FIELD_NOT_SET.format("Type"));
            }
        }

        private void decode(OMMElementList eList)
        {
            for (Iterator<?> eliter = eList.iterator(); eliter.hasNext();)
            {
                OMMElementEntry eentry = (OMMElementEntry)eliter.next();
                OMMData edata = eentry.getData();

                if (eentry.getName().compareTo(com.reuters.rfa.rdm.RDMService.Data.Type) == 0)
                {
                    type = DataType.getDataType((int)((OMMNumeric)edata).toLong());
                    hasType = true;
                }
                else if (eentry.getName().compareTo(com.reuters.rfa.rdm.RDMService.Data.Data) == 0)
                {
                    data = edata.getBytes();
                    hasData = true;
                }
            }
        }
      
        private void setRDMDefaultValues()
        {
            filterAction = DEFAULT_FILTER_ACTION;
        }

        /**
         * Explains the data. Required if Data field is set.
         * @return DataType.
         * @throws ValueAddException. If type is not set.
         */
        public DataFilter.DataType getType()
        {
            if (!hasType)
                throw new ValueAddException(ReasonCode.MISSING_OPTIONAL_FIELD,
                        ValueAddMessageKeys.FIELD_NOT_SET.format("Type"));

            return type;
        }

        /**
         * 
         * @param type
         */
        public void setType(DataFilter.DataType type)
        {
            this.type = type;
            hasType = true;
        }

        /**
         * 
         * @return Flag indicating presence of Type.
         */
        public boolean hasType()
        {
            return hasType;
        }

        /**
         * @return Data that should be applied to all items from the service that have an ANSI_Page data type.
         * @throws ValueAddException if data is not present.
         */
        public byte[] getData()
        {
            if (!hasData)
                throw new ValueAddException(ReasonCode.MISSING_OPTIONAL_FIELD,
                        ValueAddMessageKeys.FIELD_NOT_SET.format("Data"));
            return data;
        }

        /**
         * 
         * @param data
         */
        public void setData(byte[] data)
        {
            this.data = data;
            hasData = true;
        }

        /**
         * 
         * @return Flag indicating presence of data.
         */
        public boolean hasData()
        {
            return hasData;
        }
        
        /**
         * Clears presence flags. Set default RDM values for optional fields.
         */
        public void clear()
        {
            hasFilterAction = false;
            hasType = false;
            hasData = false;
            setRDMDefaultValues();
        }
    }

    /**
     * List of link entries in a Link filter.
     * @see ValueAddListManager
     */
    public static class LinkList extends ValueAddListManager<LinkFilter.Link>
    {
    }

    /**
     * Representation of a link filter for the service.
     * Contains list of link entries. See RDMUsageGuide for more details.
     */
    public static class LinkFilter
    {
        private RDMDirectory.FilterId filterId;
        private RDMDirectory.FilterAction filterAction;
        private boolean hasFilterAction;
        private LinkList linkList = new LinkList();
        private boolean hasLinkList;
        private RDMDirectory.FilterAction DEFAULT_FILTER_ACTION = RDMDirectory.FilterAction.SET;
        
        /**
         * Create a Link filter with RDM default values.
         */
        public LinkFilter()
        {
            this.filterId = RDMDirectory.FilterId.LINK;
            setRDMDefaultValues();
        }

        /**
         * Decode a link filter entry.
         * @param fEntry
         */
        public LinkFilter(OMMFilterEntry fEntry)
        {
            this.filterId = RDMDirectory.FilterId.LINK;
           
            decodeEntry(fEntry);
        }
        
        /**
         * 
         * @param linkList
         */
        public void setLinkList(LinkList linkList)
        {
            this.linkList = linkList;
            hasLinkList = true;
        }

        /**
         * @return LinkList.
         * @throws ValueAddException if LinkList is not set.
         */
        public LinkList getLinkList()
        {
            if (!hasLinkList)
                throw new ValueAddException(ReasonCode.MISSING_REQUIRED_FIELD,
                        ValueAddMessageKeys.FIELD_NOT_SET.format("LinkList"));

            return linkList;
        }

        /**
         * 
         * @return Flag indicating presence of link entry list.
         */
        public boolean hasLinkList()
        {
            return hasLinkList;
        }
        
        /**
         * @return FilterAction. RDMDirectory.FilterAction.SET if field is not set.
         */
        public RDMDirectory.FilterAction getFilterAction()
        {
            if(!hasFilterAction)
                return DEFAULT_FILTER_ACTION;
            return filterAction;
        }

        /**
         * 
         * @param filterAction
         */
        public void setFilterAction(RDMDirectory.FilterAction filterAction)
        {
            this.filterAction = filterAction;
            hasFilterAction = true;
        }
        
        /**
         * 
         * @return Flag indicating presence of filter action.
         */
        public boolean hasFilterAction()
        {
            return hasFilterAction;
        }

        /**
         * @return - Always RDMDirectory.FilterId.LINK.
         */
        public RDMDirectory.FilterId getFilterId()
        {
             return filterId;
        }

        private final boolean isCorrectEntry(OMMFilterEntry fEntry)
        {
            return fEntry != null && fEntry.getFilterId() == filterId.getValue();
        }
        
       
        private void setRDMDefaultValues()
        {
            filterAction = DEFAULT_FILTER_ACTION;
        }

        private final void encodeEntry(OMMEncoder encoder)
        {
            if(filterAction == RDMDirectory.FilterAction.CLEAR)
            {
                if(hasLinkList)
                   throw new ValueAddException(ValueAddMessageKeys.FILTERDATA_NOT_ALLOWED_FOR_CLEAR.format());
                
                return;
            }
            LinkList lList = getLinkList();
            encoder.encodeFilterEntryInit(0, RDMDirectory.FilterAction.getValue(getFilterAction()), getFilterId().getValue(),
                                          OMMTypes.MAP, null);
            
            encoder.encodeMapInit(OMMMap.HAS_TOTAL_COUNT_HINT, OMMTypes.ASCII_STRING,
                                  OMMTypes.ELEMENT_LIST, lList.size(), (short)0);
            for (LinkFilter.Link linkVal : lList)
            {
                encoder.encodeMapEntryInit(0, RDMDirectory.FilterAction.getValue(getFilterAction()), null);
                encoder.encodeString(linkVal.getName(), OMMTypes.ASCII_STRING);
                
                encoder.encodeElementListInit(OMMElementList.HAS_STANDARD_DATA, (short)0, (short)0);
                if (linkVal.hasLinkType)
                {
                    encoder.encodeElementEntryInit(com.reuters.rfa.rdm.RDMService.Link.Type,
                                                   OMMTypes.UINT);
                    encoder.encodeUInt(LinkType.getValue(linkVal.linkType));
                }
                if (linkVal.hasLinkState)
                {
                    encoder.encodeElementEntryInit(com.reuters.rfa.rdm.RDMService.Link.LinkState,
                                                   OMMTypes.UINT);
                    encoder.encodeUInt(linkVal.linkState ? 1 : 0);
                }
                if (linkVal.hasLinkCode)
                {
                    encoder.encodeElementEntryInit(com.reuters.rfa.rdm.RDMService.Link.LinkCode,
                                                   OMMTypes.UINT);
                    encoder.encodeUInt(LinkCode.getValue(linkVal.linkCode));
                }
                if (linkVal.hasText)
                {
                    encoder.encodeElementEntryInit(com.reuters.rfa.rdm.RDMService.Link.Text,
                                                   OMMTypes.ASCII_STRING);
                    encoder.encodeString(linkVal.text, OMMTypes.ASCII_STRING);
                }
                encoder.encodeAggregateComplete();
            }
            encoder.encodeAggregateComplete();
        }

        private final void decodeEntry(OMMFilterEntry fEntry)
        {
            if (!isCorrectEntry(fEntry))
                throw new ValueAddException(
                        ValueAddMessageKeys.DIR_FILTER_ENTRY_INVALID
                                .format(getFilterId(), fEntry == null ? null : fEntry.getFilterId()));

            clear();
            setFilterAction(RDMDirectory.FilterAction.getFilterAction(fEntry.getAction()));
            if(fEntry.getData() == null)
                return; //for CLEAR, data is null.
            if (fEntry.getDataType() != OMMTypes.MAP)
            {
                throw new ValueAddException(ValueAddMessageKeys.INVALID_DATA_TYPE.format(fEntry
                        .getDataType(), OMMTypes.MAP));
            }

            decode((OMMMap)fEntry.getData());
        }

        private void decode(OMMMap data)
        {
            linkList.clear();
            for (Iterator<?> iter = data.iterator(); iter.hasNext();)
            {
                OMMMapEntry mapEntry = (OMMMapEntry)iter.next();
                String name = mapEntry.getKey().toString();
                LinkFilter.Link linkEntry = new LinkFilter.Link();
                linkEntry.setName(name);
                linkEntry.setEntry((OMMElementList)mapEntry.getData());
                linkList.add(linkEntry);
            }
            hasLinkList = true;
        }

        /**
         * Clears LinkFilter presence flags. Sets RDM default values for optional fields.
         */
        public void clear()
        {
            hasFilterAction = false;
            hasLinkList = false;
            if(linkList != null)
                linkList.clear();
            setRDMDefaultValues();
        }
        
       

        /**
         * Representation of each link entry in the Link Filter.
         * See RDM user guide for more details.
         */
        public static class Link
        {
            private String name;
            private boolean hasName;

            private LinkType linkType;
            private boolean hasLinkType;

            private LinkCode linkCode;
            private boolean hasLinkCode;

            private boolean linkState;
            private boolean hasLinkState;

            private String text;
            private boolean hasText;

            private LinkType DEFAULT_TYPE = LinkType.INTERACTIVE;
            private LinkCode DEFAULT_CODE = LinkCode.NONE;
            private String DEFAULT_TEXT = "";

            /**
             * Creates a link with RDM default values.
             */
            public Link()
            {
                setDefaultRDMValues();
            }
            
            /**
             * Decode an element list representing link entry of a link filter.
             * @param elementList - Element list that represents each link entry in the link filter.
             * @throws ValueAddException - if there is no LinkState which is a required field.
             */
            public Link(OMMElementList elementList)
            {
                setEntry(elementList);
            }

            void setEntry(OMMElementList eList)
            {
                clear();
                decode(eList);
                if (!hasLinkState)
                {
                    throw new ValueAddException(ReasonCode.MISSING_REQUIRED_FIELD,
                            ValueAddMessageKeys.FIELD_NOT_SET.format("LinkState"));
                }
            }

            private void decode(OMMElementList eList)
            {
                for (Iterator<?> eiter = eList.iterator(); eiter.hasNext();)
                {
                    OMMElementEntry entry = (OMMElementEntry)eiter.next();
                    String ename = entry.getName();
                    if (ename.equals(com.reuters.rfa.rdm.RDMService.Link.Type))
                    {
                        linkType = (LinkType.getLinkType((int)((OMMNumeric)entry.getData()).toLong()));
                        hasLinkType = true;
                    }
                    else if (ename.equals(com.reuters.rfa.rdm.RDMService.Link.LinkState))
                    {
                        linkState = (((OMMNumeric)entry.getData()).toLong() == 1);
                        hasLinkState = true;
                    }
                    else if (ename.equals(com.reuters.rfa.rdm.RDMService.Link.LinkCode))
                    {
                        linkCode = (LinkCode.getLinkCode((int)((OMMNumeric)entry.getData()).toLong()));
                        hasLinkCode = true;
                    }
                    else if (ename.equals(com.reuters.rfa.rdm.RDMService.Link.Text))
                    {
                        text = (entry.getData().toString());
                        hasText = true;
                    }
                }
            }

          
            /**
             * @return LinkType. LinkType.INTERACTIVE if link type is not set.
             */
            public LinkType getLinkType()
            {
                if (!hasLinkType)
                    return DEFAULT_TYPE;
                return linkType;
            }

            /**
             * 
             * @param linkType
             */
            public void setLinkType(LinkType linkType)
            {
                this.linkType = linkType;
                hasLinkType = true;
            }

            /**
             * 
             * @return Flag indicating presence of link type.
             */
            public boolean hasLinkType()
            {
                return hasLinkType;
            }

            /**
             * @return LinkCode. LinkCode.NONE is link code is not set.
             */
            public LinkCode getLinkCode()
            {
                if (!hasLinkCode)
                    return DEFAULT_CODE;
                return linkCode;
            }

            /**
             * 
             * @param code
             */
            public void setLinkCode(LinkCode code)
            {
                this.linkCode = code;
                hasLinkCode = true;
            }

            /**
             * 
             * @return Flag indicating presence of link code.
             */
            public boolean hasLinkCode()
            {
                return hasLinkCode;
            }

            /**
             * @return LinkState. Up or Down. 
             * @throws ValueAddException if LinkState is not set.
             */
            public boolean getLinkState()
            {
                if (!hasLinkState)
                    throw new ValueAddException(ReasonCode.MISSING_REQUIRED_FIELD,
                            ValueAddMessageKeys.FIELD_NOT_SET.format("LinkState"));
                return linkState;
            }

            /**
             * 
             * @param linkState
             */
            public void setLinkState(boolean linkState)
            {
                this.linkState = linkState;
                hasLinkState = true;
            }

            /**
             * 
             * @return Flag indicating presence of link state.
             */
            public boolean hasLinkState()
            {
                return hasLinkState;
            }

            /**
             * Explains LinkState and LinkCode.
             * @return Text. Empty string if it is not set.
             */
            public String getText()
            {
                if (!hasText)
                    return DEFAULT_TEXT;
                return text;
            }

            /**
             * 
             * @param text
             */
            public void setText(String text)
            {
                this.text = text;
                hasText = true;
            }

            /**
             * 
             * @return Flag indicating presence of text.
             */
            public boolean hasText()
            {
                return hasText;
            }

            /**
             * @return LinkName. 
             * @throws ValueAddException if LinkName field is not present.
             */
            public String getName()
            {
                if (!hasName)
                    throw new ValueAddException(ReasonCode.MISSING_REQUIRED_FIELD,
                            ValueAddMessageKeys.FIELD_NOT_SET.format("LinkName"));
                return name;
            }

            /**
             * 
             * @param name
             */
            public void setName(String name)
            {
                this.name = name;
                hasName = true;
            }

            /**
             * 
             * @return Flag indicating presence of name.
             */
            public boolean hasName()
            {
                return hasName;
            }

            private void setDefaultRDMValues()
            {
                linkType = DEFAULT_TYPE;
                linkCode = DEFAULT_CODE;
                text = DEFAULT_TEXT;
            }

            /**
             * Clears the presence flags and sets RDM default values for optional fields.
             */
            public void clear()
            {
                hasLinkType = false;
                hasLinkState = false;
                hasLinkCode = false;
                hasText = false;
                setDefaultRDMValues();
            }
        }

        /**
         * Enumeration representing valid values for LinkCode.
         */
        public enum LinkCode
        {
            NONE(0), OK(1), RECOVERY_STARTED(2), RECOVERY_COMPLETED(3);

            private int value;

            private LinkCode(int value)
            {
                this.value = value;
            }

            static int getValue(LinkCode linkCode)
            {
                return linkCode.value;
            }

            static LinkCode getLinkCode(int value)
            {
                switch (value)
                {
                    case 1:
                        return OK;
                    case 2:
                        return RECOVERY_STARTED;
                    case 3:
                        return RECOVERY_COMPLETED;
                    default:
                        return NONE;
                }
            }
        }
        
        /**
         * Enumeration representing valid link type. Interactive or Broadcast. 
         */
        public enum LinkType
        {
            INTERACTIVE(1), BROADCAST(2);

            private int value;

            private LinkType(int value)
            {
                this.value = value;
            }

            static int getValue(LinkType linkType)
            {
                return linkType.value;
            }

            static LinkType getLinkType(int value)
            {
                switch (value)
                {
                    case 2:
                        return BROADCAST;
                    default:
                        return INTERACTIVE;
                }
            }
        }
    }
}