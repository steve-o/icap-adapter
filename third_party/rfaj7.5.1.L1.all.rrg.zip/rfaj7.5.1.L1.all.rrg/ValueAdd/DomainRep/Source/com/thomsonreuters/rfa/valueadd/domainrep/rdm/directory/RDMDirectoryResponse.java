package com.thomsonreuters.rfa.valueadd.domainrep.rdm.directory;

import java.util.EnumSet;

import com.reuters.rfa.omm.OMMData;
import com.reuters.rfa.omm.OMMEncoder;
import com.reuters.rfa.omm.OMMMsg;
import com.reuters.rfa.omm.OMMPool;
import com.reuters.rfa.omm.OMMTypes;
import com.reuters.rfa.rdm.RDMMsgTypes;
import com.thomsonreuters.rfa.valueadd.domainrep.DomainResponse;
import com.thomsonreuters.rfa.valueadd.domainrep.DomainType;
import com.thomsonreuters.rfa.valueadd.domainrep.ResponseStatus;
import com.thomsonreuters.rfa.valueadd.util.ValueAddException;
import com.thomsonreuters.rfa.valueadd.util.ValueAddMessageKeys;
import com.thomsonreuters.rfa.valueadd.util.ValueAddException.ReasonCode;

/**
 * Representation of RDM directory response message.
 * <li>It contains message type, response status, response type, response attributes, and response payload 
 * as well as sequence number and secondary sequence number.
 * <li>User can send REFRESH_RESP, STATUS_RESP, UPDATE_RESP {@link MessageType} responses with an optional {@link IndicationMask}, 
 * directory payload, and directory attributes and one or more filter for a service.
 * <li>As with all RDM response message representation, use {@link #getMsg(OMMPool)} to get encoded {@link OMMMsg} from the object of this class.
 * <li>Similarly, use {@link #setMsg(OMMMsg)} or {@link #RDMDirectoryResponse(OMMMsg)} to decode {@link OMMMsg} into object of this class.
 * <li>When a field is not set, get method for the field returns default values as specified by the RDM usage guide. 
 *    If there is no default value, get method throws an exception of class ValueAddException.
 * <li>has methods checks if a field is set or not.      
 * @see MessageType
 * @see IndicationMask
 * @see RDMDirectoryResponseAttrib
 * @see RDMDirectoryResponsePayload
 * @see DomainResponse
 */
public class RDMDirectoryResponse extends DomainResponse
{
    private MessageType messageType;
    
    private boolean isRefreshSolicited;
    private boolean hasIsRefreshSolicited;

    private long seqNum;
    private boolean hasSeqNum;

    private ResponseStatus responseStatus = new ResponseStatus();
    private boolean hasResponseStatus;

    private long secondarySeqNum;
    private boolean hasSecondarySeqNum;

    private RDMDirectoryResponsePayload payload = new RDMDirectoryResponsePayload();
    private boolean hasPayload;

    private RDMDirectoryResponseAttrib directoryResponseAttrib;
    private boolean hasDirectoryResponseAttrib;
  
    private EnumSet<IndicationMask> indicationMask = EnumSet.noneOf(IndicationMask.class);
 
    /**
     * Constructor to create {@link MessageType#REFRESH_RESP Directory refresh response}.
     */
    public RDMDirectoryResponse()
    {
        super(DomainType.RDM_DIRECTORY);
        indicationMask = EnumSet.noneOf(IndicationMask.class);
        messageType = MessageType.REFRESH_RESP;
    }

    /**
     * Create an {@link RDMDirectoryResponse} object by decoding directory response OMMMsg.
     * @throws {@link ValueAddException} if OMMMsg is not valid directory response message. 
     */
    public RDMDirectoryResponse(OMMMsg ommMsg)
    {
        super(DomainType.getDomainType(ommMsg.getMsgModelType()));
        indicationMask = EnumSet.noneOf(IndicationMask.class);
        clear();
        decode(ommMsg);
    }
    
    /**
     * @return MessageType set or decoded before. 
     * Returns default {@link MessageType#REFRESH_RESP} when message type is not set. 
     */
    public MessageType getMessageType()
    {
        return messageType;
    }

    /**
     * 
     * @param messageType
     */
    public void setMessageType(MessageType messageType)
    {
        this.messageType = messageType;
    }

    /**
     * 
     * @return RDMDirectoryResponsePayload set or decoded before.
     * @throws ValueAddException if there is no payload.
     */
    public RDMDirectoryResponsePayload getPayload()
    {
        if (hasPayload)
            return payload;
        throw new ValueAddException(ReasonCode.MISSING_OPTIONAL_FIELD,
                ValueAddMessageKeys.FIELD_NOT_SET.format("Payload"));
    }


    /**
     * @param directoryPayload to decode payload from.
     */
    public void setPayload(RDMDirectoryResponsePayload directoryPayload)
    {
        this.payload = directoryPayload;
        hasPayload = true;
    }

    /**
     * @return Flag indicating presence of Payload.
     */
    public boolean hasPayload()
    {
        return hasPayload;
    }

    /**
     * Encode {@link RDMDirectoryResponse} and return encoded {@link OMMMsg}.
     * Caller is expected to return the message back into the same pool.
     * @param pool - OMMMsg is acquired from the pool used when this method is called.
     * @return OMMMsg - encoded OMMMsg. 
     */
    public OMMMsg getMsg(OMMPool pool)
    {
        return encode(pool);
    }

    /**
     * Decode directory response message represented in OMMMsg into this object.
     * Before decoding the encoded directory response message, 
     * this method first clears any previous values stored for this object.
     * @param ommEncodedMessage - Encoded directory response message.
     * @throws {@link ValueAddException} if OMMMsg is not valid directory response message. 
     */
    public void setMsg(OMMMsg ommEncodedMessage)
    {
        clear();
        decode(ommEncodedMessage);
    }

    /**
     * @return RDMDirectoryResponseAttrib
     * @throws ValueAddException if RDMDirectoryResponseAttrib is not present.
     */
    public RDMDirectoryResponseAttrib getAttrib()
    {
        if (hasDirectoryResponseAttrib)
            return directoryResponseAttrib;
        throw new ValueAddException(ReasonCode.MISSING_OPTIONAL_FIELD,
                ValueAddMessageKeys.FIELD_NOT_SET.format("DirectoryResponseAttrib"));
    }

    /**
     * @return Flag indicating presence of Attributes.
     */
    public boolean hasAttrib()
    {
        return hasDirectoryResponseAttrib;
    }

    /**
     * 
     * @param directoryResponseAttrib
     */
    public void setAttrib(RDMDirectoryResponseAttrib directoryResponseAttrib)
    {
        this.directoryResponseAttrib = directoryResponseAttrib;
        hasDirectoryResponseAttrib = true;
    }

    /**
     * Clears previously set values and set the default values as defined in RDM Usage Guide. 
     * Used to make this object reusable.
     * See RDMUsageGuide for default values.
     */
    public void clear()
    {
        super.clear();

        hasResponseStatus = false;
        hasIsRefreshSolicited = false;
        hasSeqNum = false;
        hasSecondarySeqNum = false;

        hasPayload = false;
        if (payload != null)
            payload.clear();
        if (directoryResponseAttrib != null)
            directoryResponseAttrib.clear();
        hasDirectoryResponseAttrib = false;
        indicationMask = EnumSet.noneOf(IndicationMask.class);
        messageType = MessageType.REFRESH_RESP;
    }

    private boolean isValidMsg(OMMMsg ommMsg)
    {
        if (ommMsg.getMsgModelType() != RDMMsgTypes.DIRECTORY)
            return false;

        return true;
    }

    private void decode(OMMMsg ommMsg)
    {
        if (!isValidMsg(ommMsg))
            throw new ValueAddException(ValueAddMessageKeys.NOT_VALID_MSG.format("Directory"));

        setMessageType(MessageType.getMessageType(ommMsg.getMsgType()));
        setIndications(ommMsg);
        if (ommMsg.has(OMMMsg.HAS_ATTRIB_INFO))
        {
            setAttrib(new RDMDirectoryResponseAttrib(ommMsg.getAttribInfo()));
        }
        if(ommMsg.has(OMMMsg.HAS_RESP_TYPE_NUM))
            setIsRefreshSolicited(ommMsg.getRespTypeNum() == OMMMsg.RespType.SOLICITED);
        if (ommMsg.has(OMMMsg.HAS_STATE))
            setResponseStatus(new ResponseStatus(ommMsg.getState()));
        if (ommMsg.has(OMMMsg.HAS_SEQ_NUM))
            setSequenceNum(ommMsg.getSeqNum());
        if (ommMsg.has(OMMMsg.HAS_SECONDARY_SEQ_NUM))
            setSecondarySequenceNum(ommMsg.getSecondarySeqNum());

        if(ommMsg.getDataType() != OMMTypes.NO_DATA)
        {
            hasPayload = true;
            payload.setData(ommMsg.getPayload());
        }
    }

    private OMMMsg encode(OMMPool pool)
    {
        OMMMsg msg = pool.acquireMsg();
        msg.setMsgType(MessageType.getValue(getMessageType()));
        msg.setMsgModelType(DomainType.getValue(getDomainType()));

        //For directory updates, DO_NOT_CONFLATE is always set.
        if(getMessageType() == MessageType.UPDATE_RESP)
        {
            int intIndMask = OMMMsg.Indication.DO_NOT_CONFLATE;
            if (!indicationMask.isEmpty())
                intIndMask |= IndicationMask.getValue(indicationMask);
        
            msg.setIndicationFlags(intIndMask);
        }
        else
        {
            if (!indicationMask.isEmpty())
                msg.setIndicationFlags(IndicationMask.getValue(indicationMask));
        }
        
        if (hasResponseStatus && responseStatus != null)
        {
            msg.setState(responseStatus.getStreamState(), responseStatus.getDataState(),
                         responseStatus.getCode(), responseStatus.getText());
        }
        
        if (hasSeqNum)
            msg.setSeqNum(seqNum);
        if (hasSecondarySeqNum)
            msg.setSeqNum(secondarySeqNum);
      
        if (hasIsRefreshSolicited)
            msg.setRespTypeNum(hasIsRefreshSolicited && isRefreshSolicited ? OMMMsg.RespType.SOLICITED : OMMMsg.RespType.UNSOLICITED);

        if (directoryResponseAttrib != null && hasDirectoryResponseAttrib)
            msg = directoryResponseAttrib.encode(pool, msg);

        if (!hasPayload || !payload.hasServiceList())
            return msg;

        OMMData mapData = payload.getData(pool);
        OMMEncoder encoder = pool.acquireEncoder();
        encoder.initialize(OMMTypes.MSG, msg.getEncodedLength() + mapData.getEncodedLength() + 100);
        encoder.encodeMsgInit(msg, OMMTypes.NO_DATA, OMMTypes.MAP);
        encoder.encodeData(mapData);

        OMMMsg encMsg = (OMMMsg)encoder.acquireEncodedObject();
        pool.releaseEncoder(encoder);
        pool.releaseMsg(msg);
        pool.releaseData(mapData);
        return encMsg;
    }

    /**
     * 
     * @return Sequence number.
     * @throws ValueAddException if Sequence number is not set.
     */
    public long getSequenceNum()
    {
        if (!hasSeqNum)
            throw new ValueAddException(ValueAddException.ReasonCode.MISSING_OPTIONAL_FIELD,
                    ValueAddMessageKeys.FIELD_NOT_SET.format("SequenceNumber"));

        return seqNum;
    }

    /**
     * 
     * @param sequenceNumber
     */
    public void setSequenceNum(long sequenceNumber)
    {
        this.seqNum = sequenceNumber;
        hasSeqNum = true;
    }

    /**
     * @return Boolean flag indicating presence of sequence number.
     */
    public boolean hasSequenceNum()
    {
        return hasSeqNum;
    }

    /**
     * 
     * @return Secondary sequence number.
     * @throws ValueAddException if secondary sequence number is not set.
     */
    public long getSecondarySequenceNum()
    {
        if (!hasSecondarySeqNum)
            throw new ValueAddException(ValueAddException.ReasonCode.MISSING_OPTIONAL_FIELD,
                    ValueAddMessageKeys.FIELD_NOT_SET.format("SecondarySequenceNumber"));
        return secondarySeqNum;
    }

    /**
     * 
     * @param secondarySequenceNumber
     */
    public void setSecondarySequenceNum(long secondarySequenceNumber)
    {
        this.secondarySeqNum = secondarySequenceNumber;
        hasSecondarySeqNum = true;
    }
    
    /**
     * @return Boolean flag indicating presence of secondary sequence number.
     */
    public boolean hasSecondarySequenceNum()
    {
        return hasSecondarySeqNum;
    }

    /**
     * 
     * @return ResponseStatus of the message.
     * @throws ValueAddException if ResponseStatus is not set.
     */
    public ResponseStatus getResponseStatus()
    {
        if (!hasResponseStatus)
            throw new ValueAddException(ValueAddException.ReasonCode.MISSING_OPTIONAL_FIELD,
                    ValueAddMessageKeys.FIELD_NOT_SET.format("ResponseStatus"));
        return responseStatus;
    }

    /**
     * 
     * @param responseStatus
     */
    public void setResponseStatus(ResponseStatus responseStatus)
    {
        this.hasResponseStatus = true;
        this.responseStatus = responseStatus;
    }
    
    /**
     * @return Boolean flag representing presence of response status.
     */
    public boolean hasResponseStatus()
    {
        return hasResponseStatus;
    }

    /**
     * 
     * @return True if this is a refresh solicited message.
     * @throws ValueAddException when field is not set.
     */
    public boolean getIsRefreshSolicited()
    {
        if (!hasIsRefreshSolicited)
            throw new ValueAddException(ValueAddException.ReasonCode.MISSING_OPTIONAL_FIELD,
                    ValueAddMessageKeys.FIELD_NOT_SET.format("IsRefreshSolicited"));

        return isRefreshSolicited;
    }
    
    /**
     * 
     * @param isRefreshSolicited
     */
    public void setIsRefreshSolicited(boolean isRefreshSolicited)
    {
        this.isRefreshSolicited = isRefreshSolicited;
        hasIsRefreshSolicited = true;
    }
    
    /**
     * 
     * @return Flag indicating presence of IsRefreshSolicited.
     */
    public boolean hasIsRefreshSolicited()
    {
        return hasIsRefreshSolicited;
    }

   
    /**
     * 
     * @return Set of IndicationMask representing indication flags in the response.
     *         Returns empty EnumSet if indication mask is not set.
     */
    public EnumSet<IndicationMask> getIndicationMask()
    {
        return indicationMask;
    }

    /**
     * 
     * @param indicationMask
     */
    public void setIndicationMask(EnumSet<IndicationMask> indicationMask)
    {
        this.indicationMask = indicationMask;
    }

    /**
     * Message type enumerations for RDM directory response. 
     */
    public enum MessageType
    {
        REFRESH_RESP(OMMMsg.MsgType.REFRESH_RESP), STATUS_RESP(OMMMsg.MsgType.STATUS_RESP), 
        UPDATE_RESP(OMMMsg.MsgType.UPDATE_RESP), GENERIC(OMMMsg.MsgType.GENERIC);

        private MessageType(int value)
        {
            this.value = (byte)value;
        }

        public static byte getValue(MessageType messageType)
        {
            return messageType.value;
        }

        public static MessageType getMessageType(byte value)
        {
            switch (value)
            {
                case OMMMsg.MsgType.REFRESH_RESP:
                    return REFRESH_RESP;
                case OMMMsg.MsgType.STATUS_RESP:
                    return STATUS_RESP;
                case OMMMsg.MsgType.UPDATE_RESP:
                    return UPDATE_RESP;
                case OMMMsg.MsgType.GENERIC:
                    return GENERIC;
                default:
                    throw new ValueAddException(ValueAddMessageKeys.UNSUPPORTED_MESSAGE_TYPE.format(OMMMsg.MsgType.toString(value)));
            }
        }

        private byte value;
    }
    
    /**
     * Indication mask enumerations for directory response.
     */
    public enum IndicationMask
    {
        REFRESH_COMPLETE, CLEAR_CACHE, DO_NOT_CACHE, DO_NOT_CONFLATE;

        static EnumSet<IndicationMask> getIndicationMask(int ommvalue)
        {
            EnumSet<IndicationMask> list = EnumSet.noneOf(IndicationMask.class);
            if ((ommvalue & OMMMsg.Indication.REFRESH_COMPLETE) != 0)
                list.add(REFRESH_COMPLETE);
            if ((ommvalue & OMMMsg.Indication.CLEAR_CACHE) != 0)
                list.add(CLEAR_CACHE);
            if ((ommvalue & OMMMsg.Indication.DO_NOT_CACHE) != 0)
                list.add(DO_NOT_CACHE);
            if ((ommvalue & OMMMsg.Indication.DO_NOT_CONFLATE) != 0)
                list.add(DO_NOT_CONFLATE);
            return list;
        }

        static int getValue(EnumSet<IndicationMask> typedValue)
        {
            int indicationMask = 0;
            if (typedValue.contains(REFRESH_COMPLETE))
                indicationMask |= OMMMsg.Indication.REFRESH_COMPLETE;
            if (typedValue.contains(CLEAR_CACHE))
                indicationMask |= OMMMsg.Indication.CLEAR_CACHE;
            if (typedValue.contains(DO_NOT_CACHE))
                indicationMask |= OMMMsg.Indication.DO_NOT_CACHE;
            if (typedValue.contains(DO_NOT_CONFLATE))
                indicationMask |= OMMMsg.Indication.DO_NOT_CONFLATE;

            return indicationMask;
        }
    }
    
    private void setIndications(OMMMsg msg)
    {
        if (msg.isSet(OMMMsg.Indication.CLEAR_CACHE))
        {
            indicationMask.add(IndicationMask.CLEAR_CACHE);
        }

        if (msg.isSet(OMMMsg.Indication.DO_NOT_CACHE))
        {
            indicationMask.add(IndicationMask.DO_NOT_CACHE);
        }

        if (msg.isSet(OMMMsg.Indication.REFRESH_COMPLETE))
        {
            indicationMask.add(IndicationMask.REFRESH_COMPLETE);
        }
        
        if (msg.isSet(OMMMsg.Indication.DO_NOT_CONFLATE))
        {
            indicationMask.add(IndicationMask.DO_NOT_CONFLATE);
        }
    }
}