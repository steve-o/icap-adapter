package com.thomsonreuters.rfa.valueadd.domainrep.rdm.dictionary;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import com.reuters.rfa.common.Handle;
import com.reuters.rfa.dictionary.DictionaryException;

import com.reuters.rfa.dictionary.FieldDictionary;
import com.reuters.rfa.omm.OMMData;
import com.reuters.rfa.omm.OMMElementEntry;
import com.reuters.rfa.omm.OMMElementList;
import com.reuters.rfa.omm.OMMEncoder;
import com.reuters.rfa.omm.OMMNumeric;
import com.reuters.rfa.omm.OMMPool;
import com.reuters.rfa.omm.OMMSeries;
import com.reuters.rfa.omm.OMMTypes;
import com.thomsonreuters.rfa.valueadd.util.ValueAddException;
import com.thomsonreuters.rfa.valueadd.util.ValueAddMessageKeys;

/**
 * Manages RFA's FieldDictionary object.   
 * <li>Provider application can load dictionaries using {@link #load(String, RDMDictionary.DictionaryType)} interface
 * and then use {@link #getDictionary(OMMPool, RDMDictionary.DictionaryType)} to retrieve encoded payload data.
 * <li>Consumer application loads dictionaries using {@link #load(RDMDictionaryResponsePayload, Handle)}.
 * This function supports loading of multi-part refresh messages. 
 * Consumer application can also use {@link #getDictionaryType(Handle)} to retrieve dictionary type of cached dictionary.
 */
public class RDMDictionaryCache
{
    private Map<Handle, RDMDictionary.DictionaryType> dictHandles;
    private FieldDictionary fldDict;
    
    public RDMDictionaryCache()
    {
        dictHandles = new HashMap<Handle, RDMDictionary.DictionaryType>();
        fldDict = FieldDictionary.create();
    }

    /**
     * 
     * @return RFA's FieldDictionary.
     */
    public FieldDictionary getFieldDictionary()
    {
        return fldDict;
    }

    /**
     * 
     * @param handle
     * @return Dictionary type for a handle.
     */
    public RDMDictionary.DictionaryType getDictionaryType(Handle handle)
    {
        if (dictHandles.containsKey(handle))
        {
            return dictHandles.get(handle);
        }

        return RDMDictionary.DictionaryType.UNSPECIFIED;
    }

    /**
     * Decodes and stores the field dictionary from the dictionary refresh message.
     * @param payload Dictionary response payload. It can be part in a multi-part refresh message received by the consumer application.
     * @param handle Handle for which dictionary response is received.
     */
    public void load(RDMDictionaryResponsePayload payload, Handle handle)
    {
        OMMData payloadData = payload.getData();
        if (payloadData.getType() != OMMTypes.SERIES)
            throw new ValueAddException(ValueAddMessageKeys.INVALID_DATA_TYPE.format(OMMTypes.toString(OMMTypes.SERIES), OMMTypes.toString(payloadData.getType())));
        OMMSeries series = (OMMSeries)payloadData;
        RDMDictionary.DictionaryType dictType = getDictionaryType(handle, series);
        if (dictType == com.thomsonreuters.rfa.valueadd.domainrep.rdm.dictionary.RDMDictionary.DictionaryType.RWFFLD)
        {
            FieldDictionary.decodeRDMFldDictionary(fldDict, series);
        }
        else if (dictType == com.thomsonreuters.rfa.valueadd.domainrep.rdm.dictionary.RDMDictionary.DictionaryType.RWFENUM)
        {
            FieldDictionary.decodeRDMEnumDictionary(fldDict, series);
        }
        else
        {
            throw new ValueAddException(ValueAddMessageKeys.DICTIONARY_TYPE_UNDETERMINED.format(dictType));
        }
    }

    /**
     * Read the dictionary file of a specific type. 
     * @param filename
     * @param dictionaryType - Dictionary type of the file being read.
     * @throws DictionaryException
     */
    public void load(String filename, RDMDictionary.DictionaryType dictionaryType) throws DictionaryException
    {
        if (dictionaryType == RDMDictionary.DictionaryType.RWFFLD)
        {
            FieldDictionary.readRDMFieldDictionary(fldDict, filename);
        }
        else if (dictionaryType == RDMDictionary.DictionaryType.RWFENUM)
        {
            FieldDictionary.readEnumTypeDef(fldDict, filename);
        }
        else
        {
            throw new ValueAddException(
                    ValueAddMessageKeys.DICTIONARY_TYPE_UNDETERMINED.format(dictionaryType));
        }
    }

    /**
     * Encodes the cached field dictionary for a specified dictionary type.
     * Typically, used by provider application which reads the file first during initialization and then
     * calls this method to get encoded dictionary data.
     * @param pool - Pool to retrieve encoded data from.
     * @param dictionaryType - Dictionary type to retrieve.
     * @return RDMDictionaryResponsePayload with encoded OMMSeries data.
     */
    public RDMDictionaryResponsePayload getDictionary(OMMPool pool, RDMDictionary.DictionaryType dictionaryType)
    {
        OMMEncoder encoder = pool.acquireEncoder();
        encoder.initialize(OMMTypes.SERIES, 600000);
        if (dictionaryType == com.thomsonreuters.rfa.valueadd.domainrep.rdm.dictionary.RDMDictionary.DictionaryType.RWFFLD)
            FieldDictionary.encodeRDMFieldDictionary(fldDict, encoder);
        else if (dictionaryType == com.thomsonreuters.rfa.valueadd.domainrep.rdm.dictionary.RDMDictionary.DictionaryType.RWFENUM)
            FieldDictionary.encodeRDMEnumDictionary(fldDict, encoder);
        else
            throw new ValueAddException(ValueAddMessageKeys.INVALID_DICTIONARY_TYPE.format(dictionaryType));

        OMMSeries series = (OMMSeries)encoder.acquireEncodedObject();
        pool.releaseEncoder(encoder);
        return new RDMDictionaryResponsePayload(series);
    }

    private RDMDictionary.DictionaryType getDictionaryType(Handle handle, OMMSeries series)
    {
        if (dictHandles.containsKey(handle))
        {
            return dictHandles.get(handle);
        }

        if (series.has(OMMSeries.HAS_SUMMARY_DATA))
        {
            int dictType = com.reuters.rfa.rdm.RDMDictionary.Type.UNSPECIFIED;
            OMMElementList summaryData = (OMMElementList)series.getSummaryData();
            Iterator<?> iter = summaryData.iterator();
            while (iter.hasNext())
            {
                OMMElementEntry entry = (OMMElementEntry)iter.next();
                if (entry.getName().equals(com.reuters.rfa.rdm.RDMDictionary.Summary.Type))
                    dictType = (int)((OMMNumeric)entry.getData()).toLong();
            }
            RDMDictionary.DictionaryType rdmDictType;
            if (dictType == com.reuters.rfa.rdm.RDMDictionary.Type.ENUM_TABLES)
                rdmDictType = com.thomsonreuters.rfa.valueadd.domainrep.rdm.dictionary.RDMDictionary.DictionaryType.RWFENUM;
            else if (dictType == com.reuters.rfa.rdm.RDMDictionary.Type.FIELD_DEFINITIONS)
                rdmDictType = com.thomsonreuters.rfa.valueadd.domainrep.rdm.dictionary.RDMDictionary.DictionaryType.RWFFLD;
            else
                rdmDictType = com.thomsonreuters.rfa.valueadd.domainrep.rdm.dictionary.RDMDictionary.DictionaryType.UNSPECIFIED;
            dictHandles.put(handle, rdmDictType);

            return rdmDictType;
        }

        // dictionary type not in summary data.
        throw new ValueAddException(ValueAddMessageKeys.DICTIONARY_TYPE_UNDETERMINED.format());
    }

}