package com.thomsonreuters.rfa.valueadd.domainrep.rdm.directory;

import java.util.EnumSet;

import com.reuters.rfa.omm.OMMAttribInfo;
import com.reuters.rfa.omm.OMMMsg;
import com.reuters.rfa.omm.OMMPool;
import com.thomsonreuters.rfa.valueadd.util.ValueAddException;
import com.thomsonreuters.rfa.valueadd.util.ValueAddMessageKeys;
import com.thomsonreuters.rfa.valueadd.util.ValueAddException.ReasonCode;


/**
 * Class representing directory response attributes as defined in RDM user guide.
 * <li> {@link RDMDirectory.FilterMask} is used for filters present in the directory response.
 * <li> As with any attribute information representation, use {@link #getAttribInfo(OMMPool)} to get encoded OMMAttribInfo object.
 * <li> Similarly, use {@link #RDMDirectoryResponseAttrib(OMMAttribInfo)} or {@link #setAttribInfo(OMMAttribInfo)} to clear
 * all previous values and decode OMMAttribInfo into this object.
 * <li>When a field is not set, get method for the field returns default values as specified by the RDM usage guide. 
 *    If there is no default value, get method throws an exception of class ValueAddException.
 * <li>has methods checks if a field is set or not. *       
 */
public class RDMDirectoryResponseAttrib
{
    private EnumSet<RDMDirectory.FilterMask> filterMask;
    private boolean hasFilterMask;

    public RDMDirectoryResponseAttrib()
    {
        
    }

    /**
     * Decode OMMAttribInfo into this object.
     * @param ommAttribInfo to decode
     */
    public RDMDirectoryResponseAttrib(OMMAttribInfo ommAttribInfo)
    {
        decode(ommAttribInfo);
    }
    
    /**
     * @return Set of filter masks present in directory response.
     * @throws ValueADdException if filter mask field is not set.
     */
    public EnumSet<RDMDirectory.FilterMask> getFilterMask()
    {
        if (!hasFilterMask)
            throw new ValueAddException(ReasonCode.MISSING_REQUIRED_FIELD,
                    ValueAddMessageKeys.FIELD_NOT_SET.format("FilterMask"));
        return filterMask;
    }

    /**
     * @param filterMask - set of filterMasks that is minimally required to create RDMDirectoryResponseAttrib object. 
     */
    public void setFilterMask(EnumSet<RDMDirectory.FilterMask> filterMask)
    {
        this.filterMask = filterMask;
        hasFilterMask = true;
    }

    public boolean hasFilterMask()
    {
        return hasFilterMask;
    }

    /**
     * @param pool from which OMMAttribInfo is acquired.
     * @return encoded OMMAttribInfo object from this object. 
     *         User needs to release the returned OMMAttribInfo into the same pool used to call this method. 
     * @throws ValueAddException if required FilterMask field is not set.
     */
    public OMMAttribInfo getAttribInfo(OMMPool pool)
    {
        if (!hasFilterMask())
            throw new ValueAddException(ReasonCode.MISSING_REQUIRED_FIELD,
                    ValueAddMessageKeys.FIELD_NOT_SET.format("FilterMask"));
        
        OMMAttribInfo newAi = pool.acquireAttribInfo();
        newAi.setFilter(RDMDirectory.FilterMask.getValue(getFilterMask()));
        return newAi;
    }
    
    /**
     * Clears all previous values and decode OMMAttribInfo into this object.
     * @param ommAttribInfo to decode the directory request attributes.
     */
    public void setAttribInfo(OMMAttribInfo ommAttribInfo)
    {
        clear();
        decode(ommAttribInfo);
    }
    
    /**
     * Clears previously set values to make this object reusable.
     */
    public void clear()
    {
        hasFilterMask = false;
    }

    OMMMsg encode(OMMPool pool, OMMMsg ommMsg)
    {
        if (!hasFilterMask)
            throw new ValueAddException(ReasonCode.MISSING_REQUIRED_FIELD,
                    ValueAddMessageKeys.FIELD_NOT_SET.format("DataMask"));

        OMMAttribInfo newAi = pool.acquireAttribInfo();
        newAi.setFilter(RDMDirectory.FilterMask.getValue(filterMask));
        ommMsg.setAttribInfo(newAi);
        pool.releaseAttribInfo(newAi);

        return ommMsg;
    }

    void decode(OMMAttribInfo ommAttribInfo)
    {
        if (!ommAttribInfo.has(OMMAttribInfo.HAS_FILTER))
            throw new ValueAddException(ReasonCode.MISSING_REQUIRED_FIELD,
                    ValueAddMessageKeys.FIELD_NOT_SET.format("DataMask"));

        filterMask = RDMDirectory.FilterMask.getDataMask(ommAttribInfo.getFilter());
        hasFilterMask = true;
    }
}
