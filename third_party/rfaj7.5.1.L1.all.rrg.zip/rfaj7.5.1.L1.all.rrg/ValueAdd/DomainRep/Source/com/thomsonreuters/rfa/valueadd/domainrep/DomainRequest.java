package com.thomsonreuters.rfa.valueadd.domainrep;

import com.reuters.rfa.omm.OMMMsg;
import com.reuters.rfa.omm.OMMPool;


/**
 * Base class for RDM request messages.
 * Use {@link #getMsg(OMMPool)} to encode and get OMMMsg
 * Use {@link #setMsg(OMMMsg)} to decode and set fields for the request message.
 */
public abstract class DomainRequest extends Domain
{
    protected DomainRequest(DomainType domain)
    {
        super(domain);
    }

    /**
     * Encode a request message and return encoded {@link OMMMsg}.
     * Caller is expected to return the message back into the same pool.
     * @param pool - OMMMsg is acquired from the pool used when this method is called.
     * @return OMMMsg - encoded OMMMsg. 
     */
    public abstract OMMMsg getMsg(OMMPool pool);
    
    /**
     * Decode request message represented in OMMMsg into this object.
     * @param encodedMessage - Encoded request message.
     */
    public abstract void setMsg(OMMMsg encodedMessage);
}