package com.thomsonreuters.rfa.valueadd.util;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.ConsoleHandler;
import java.util.logging.Formatter;
import java.util.logging.Handler;
import java.util.logging.Level;
import java.util.logging.LogRecord;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;

/**
 * Logger for value add. 
 */
public class ValueAddLogger
{
    private final static SimpleDateFormat dateFormat = new SimpleDateFormat("MMM dd, yyyy hh:mm:ss.SSS a");
    private static Date dat = new Date();

    public static void initialize(Level level, String fileName)
    {

        Logger logger = Logger.getLogger(LoggerNames.VALUEADD_GLOBAL_LOGGER);
        logger.setLevel(level);
        if (fileName != null && fileName.length() != 0
                && fileName.compareToIgnoreCase("console") != 0)
        {
            Handler handler = null;
            try
            {
                handler = new java.util.logging.FileHandler(fileName);
            }
            catch (IOException e)
            {
                System.err.println("Could not create " + logger.getName() + " handler: "
                        + e.getMessage());
                return;
            }
            handler.setFormatter(new FileFormatter());
            handler.setLevel(level);
            logger.addHandler(handler);
        }
        else
        {
            logger.setUseParentHandlers(false);
            Handler handler = new ConsoleHandler();
            handler.setFormatter(new ConsoleFormatter());
            handler.setLevel(level);
            logger.addHandler(handler);
        }

    }

    public static void cleanup(Logger logger)
    {
        if (logger == null)
        {
            return;
        }

        Handler[] handlers = logger.getHandlers();
        for (int i = 0; i < handlers.length; i++)
        {
            handlers[i].close();
            logger.removeHandler(handlers[i]);
        }
    }

    private static class ConsoleFormatter extends SimpleFormatter
    {
        // This method is called just after the handler using this
        // formatter is created
        public String getHead(Handler h)
        {
            long time = System.currentTimeMillis();
            dat.setTime(time);
            return "Start time:\"" + dateFormat.format(dat) + "\"" + ", version:\""
                    + ValueAddContext.getRFAVersion() + "\"" + ", rfaversion:\""
                    + ValueAddContext.getVersion() + "\"\n";
        }

        // This method is called just after the handler using this
        // formatter is closed
        // JDK logger doesn't call this for its consolehandler
        public String getTail(Handler h)
        {
            long time = System.currentTimeMillis();
            dat.setTime(time);
            return "End time:\"" + dateFormat.format(dat) + "\"\n";
        }
    }

    private static class FileFormatter extends Formatter
    {
        public String format(LogRecord rec)
        {
            dat.setTime(rec.getMillis());
            StringBuilder buf = new StringBuilder(1000);
            buf.append("<record>\n\t<date>");
            buf.append(dateFormat.format(dat));
            buf.append("</date>\n\t<millis>");
            buf.append(dat.getTime());
            buf.append("</millis>\n\t<level>");
            buf.append(rec.getLevel());
            buf.append("</level>\n\t<logger>");
            buf.append(rec.getLoggerName());
            buf.append("</logger>\n\t<class>");
            buf.append(rec.getSourceClassName());
            buf.append("</class>\n\t<method>");
            buf.append(rec.getSourceMethodName());
            buf.append("</method>\n\t<thread>");
            buf.append(rec.getThreadID());
            buf.append("</thread>\n\t<message>");
            buf.append(formatMessage(rec));
            buf.append("</message>\n</record>\n");
            return buf.toString();
        }

        // This method is called just after the handler using this
        // formatter is created
        public String getHead(Handler h)
        {
            long time = System.currentTimeMillis();
            dat.setTime(time);
            return "<log time=\"" + dateFormat.format(dat) + "\"" + " version=\""
                    + ValueAddContext.getRFAVersion() + "\"" + " rfaversion=\""
                    + ValueAddContext.getVersion() + "\">\n";
        }

        // This method is called just after the handler using this
        // formatter is closed
        public String getTail(Handler h)
        {
            return "</log>\n";
        }
    }

    public static class LoggerNames
    {
        public static final String VALUEADD_GLOBAL_LOGGER = new String(
                "com.thomsonreuters.rfa.valueadd");
        public static final String ADMIN_LOGGER = new String(
                "com.thomsonreuters.rfa.valueadd.admin");
        public static final String ADMIN_UTIL_LOGGER = new String(
                "com.thomsonreuters.rfa.valueadd.admin.util");
        public static final String ADMIN_CONFIG_LOGGER = new String(
                "com.thomsonreuters.rfa.valueadd.admin.config");
        public static final String DOMAINREP_LOGGER = new String(
                "com.thomsonreuters.rfa.valueadd.domainrep");
    }
}
