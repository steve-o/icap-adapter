package com.thomsonreuters.rfa.valueadd.domainrep.rdm.dictionary;

import com.reuters.rfa.omm.OMMAttribInfo;
import com.reuters.rfa.omm.OMMMsg;
import com.reuters.rfa.omm.OMMPool;
import com.thomsonreuters.rfa.valueadd.util.ValueAddException;
import com.thomsonreuters.rfa.valueadd.util.ValueAddMessageKeys;
import com.thomsonreuters.rfa.valueadd.util.ValueAddException.ReasonCode;

/**
 * Class representing dictionary request attributes as defined in RDM user guide.
 * <li>Contains service name, service id, dictionary name and verbosity of dictionary request.
 * <li>As with all RDM attribute representation, use {@link #getAttribInfo(OMMPool)} to get encoded {@link OMMAttribInfo} from an object of this class.
 * <li>Similarly, use {@link #setAttribInfo(OMMAttribInfo)} or {@link #RDMDictionaryRequestAttrib(OMMAttribInfo)} to decode {@link OMMAttribInfo} 
 *    into an object of this class.
 * <li>When a field is not set, get method for the field returns default values as specified by the RDM usage guide. 
 *    If there is no default value, get method throws an exception of class ValueAddException.
 * <li>has methods checks if a field is set or not.        
 */
public class RDMDictionaryRequestAttrib
{
    private String serviceName;
    private boolean hasServiceName;
    private int serviceId;
    private boolean hasServiceId;
    private String dictionaryName;
    private boolean hasDictionaryName;
    private RDMDictionary.Verbosity verbosity;
    private boolean hasVebosity;
    private boolean isDecoded;

    public RDMDictionaryRequestAttrib()
    {

    }

    /**
     * Decode OMMAttribInfo into this object.
     * @param ommAttribInfo to decode
     */
    public RDMDictionaryRequestAttrib(OMMAttribInfo ommAttribInfo)
    {
        decode(ommAttribInfo);
    }

    /**
     * 
     * @param dictAttribInfo
     */
    public RDMDictionaryRequestAttrib(RDMDictionaryRequestAttrib dictAttribInfo)
    {
        setDictionaryName(dictAttribInfo.getDictionaryName());
        setVerbosity(dictAttribInfo.getVerbosity());
        if (dictAttribInfo.hasServiceName())
            setServiceName(dictAttribInfo.getServiceName());

        if (dictAttribInfo.hasServiceId())
            setServiceId(dictAttribInfo.getServiceId());
    }

    /**
     * @return serviceName.
     * @throws ValueAddException if service name is not present.
     */
    public String getServiceName()
    {
        if (!hasServiceId && !hasServiceName)
            throw new ValueAddException(ReasonCode.MISSING_REQUIRED_FIELD,
                    ValueAddMessageKeys.FIELD_NOT_SET.format("ServiceID"));

        if (hasServiceName)
            return serviceName;

        throw new ValueAddException(ReasonCode.MISSING_OPTIONAL_FIELD,
                ValueAddMessageKeys.FIELD_NOT_SET.format("ServiceName"));
    }

    /**
     * 
     * @param serviceName
     */
    public void setServiceName(String serviceName)
    {
        this.serviceName = serviceName;
        hasServiceName = true;
    }

    /**
     * 
     * @return Flag representing presence of ServiceName.
     */
    public boolean hasServiceName()
    {
        return hasServiceName;
    }

    /**
     * 
     * @return ServiceId.
     * @throws ValueAddException if ServiceId not set.
     */
    public int getServiceId()
    {
        if (!hasServiceId && !hasServiceName)
            throw new ValueAddException(ReasonCode.MISSING_REQUIRED_FIELD,
                    ValueAddMessageKeys.FIELD_NOT_SET.format("ServiceID"));

        if (!hasServiceId)
            throw new ValueAddException(ReasonCode.MISSING_OPTIONAL_FIELD,
                    ValueAddMessageKeys.FIELD_NOT_SET.format("ServiceID"));

        return serviceId;
    }

    /**
     * 
     * @param serviceId
     */
    public void setServiceId(int serviceId)
    {
        this.serviceId = serviceId;
        hasServiceId = true;
    }

    /**
     * 
     * @return Flag representing presence of service id.
     */
    public boolean hasServiceId()
    {
        return hasServiceId;
    }

    /**
     * 
     * @return DictionaryName
     * @throws ValueAddException if DictionaryName not set.
     */
    public String getDictionaryName()
    {
        if (!hasDictionaryName)
            throw new ValueAddException(ReasonCode.MISSING_REQUIRED_FIELD,
                    ValueAddMessageKeys.FIELD_NOT_SET.format("Name"));

        return dictionaryName;
    }

    /**
     * 
     * @param dictionaryName
     */
    public void setDictionaryName(String dictionaryName)
    {
        this.dictionaryName = dictionaryName;
        hasDictionaryName = true;
    }

    /**
     * 
     * @return Flag representing presence of DictionaryName.
     */
    public boolean hasDictionaryName()
    {
        return hasDictionaryName;
    }

    /**
     * 
     * @return Verbosity of a dictionary request.
     * @throws ValueAddException if verbosity is not set.
     */
    public RDMDictionary.Verbosity getVerbosity()
    {
        if (!hasVebosity)
            throw new ValueAddException(ReasonCode.MISSING_REQUIRED_FIELD,
                    ValueAddMessageKeys.FIELD_NOT_SET.format("DataMask"));

        return verbosity;
    }

    /**
     * 
     * @param verbosity
     */
    public void setVerbosity(RDMDictionary.Verbosity verbosity)
    {
        this.verbosity = verbosity;
        hasVebosity = true;
    }

    /**
     * 
     * @return Flag indicating presence of verbosity flag.
     */
    public boolean hasVerbosity()
    {
        return hasVebosity;
    }

    /**
     * 
     * @param ommAttribInfo
     */
    public void setAttribInfo(OMMAttribInfo ommAttribInfo)
    {
        decode(ommAttribInfo);
    }

    /**
     * 
     * @param pool OMMPool to acquire OMMAttribInfo from. 
     * @return OMMAttribInfo
     * @throws ValueAddException if Vebosity or DictionaryName or ServiceName or Service Id is not set.
     */
    public OMMAttribInfo getAttribInfo(OMMPool pool)
    {
        if (!hasVebosity)
            throw new ValueAddException(ReasonCode.MISSING_REQUIRED_FIELD,
                    ValueAddMessageKeys.FIELD_NOT_SET.format("Vebosity"));
        if (!hasDictionaryName)
            throw new ValueAddException(ReasonCode.MISSING_REQUIRED_FIELD,
                    ValueAddMessageKeys.FIELD_NOT_SET.format("Name"));
        if (!hasServiceName && !hasServiceId)
            throw new ValueAddException(ReasonCode.MISSING_REQUIRED_FIELD,
                    ValueAddMessageKeys.FIELD_NOT_SET.format("ServiceName/ServiceID"));

        OMMAttribInfo newAi = pool.acquireAttribInfo();
        newAi.setFilter(RDMDictionary.Verbosity.getValue(verbosity));
        newAi.setName(dictionaryName);
        if (hasServiceName)
        {
            newAi.setServiceName(serviceName);
        }

        // don't set service id if servicename is also present.
        // allow both service name and id if user is setting it with decode first.
        if (hasServiceId && (!hasServiceName || !isDecoded))
        {
            newAi.setServiceID(serviceId);
        }

        return newAi;
    }

    /**
     * Clears presence flags.
     */
    public void clear()
    {
        hasServiceName = false;
        hasServiceId = false;
        hasVebosity = false;
        hasDictionaryName = false;
        isDecoded = false;
    }

    void decode(OMMAttribInfo ommAttribInfo)
    {
        if (!ommAttribInfo.has(OMMAttribInfo.HAS_NAME))
            throw new ValueAddException(ReasonCode.MISSING_REQUIRED_FIELD,
                    ValueAddMessageKeys.FIELD_NOT_SET.format("Name"));
        if (!ommAttribInfo.has(OMMAttribInfo.HAS_FILTER))
            throw new ValueAddException(ReasonCode.MISSING_REQUIRED_FIELD,
                    ValueAddMessageKeys.FIELD_NOT_SET.format("DataMask"));
        if (!ommAttribInfo.has(OMMAttribInfo.HAS_SERVICE_NAME)
                && !ommAttribInfo.has(OMMAttribInfo.HAS_SERVICE_ID))
            throw new ValueAddException(ReasonCode.MISSING_REQUIRED_FIELD,
                    ValueAddMessageKeys.FIELD_NOT_SET.format("ServiceName/ServiceID"));

        dictionaryName = ommAttribInfo.getName();
        hasDictionaryName = true;
        verbosity = RDMDictionary.Verbosity.getDataMask(ommAttribInfo.getFilter());
        hasVebosity = true;
        isDecoded = true;
        if (ommAttribInfo.has(OMMAttribInfo.HAS_SERVICE_NAME))
        {
            serviceName = ommAttribInfo.getServiceName();
            hasServiceName = true;
        }
        if (ommAttribInfo.has(OMMAttribInfo.HAS_SERVICE_ID))
        {
            serviceId = ommAttribInfo.getServiceID();
            hasServiceId = true;
        }
    }

    OMMMsg encode(OMMPool pool, OMMMsg msg)
    {
        OMMAttribInfo newAI = getAttribInfo(pool);
        msg.setAttribInfo(newAI);
        pool.releaseAttribInfo(newAI);

        return msg;
    }
}
