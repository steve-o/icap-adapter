package com.thomsonreuters.rfa.valueadd.domainrep.rdm.login;

import java.util.EnumSet;
import java.util.Iterator;
import com.reuters.rfa.omm.OMMAttribInfo;
import com.reuters.rfa.omm.OMMData;
import com.reuters.rfa.omm.OMMElementEntry;
import com.reuters.rfa.omm.OMMElementList;
import com.reuters.rfa.omm.OMMEncoder;
import com.reuters.rfa.omm.OMMMsg;
import com.reuters.rfa.omm.OMMPool;
import com.reuters.rfa.omm.OMMTypes;
import com.reuters.rfa.rdm.RDMUser;
import com.thomsonreuters.rfa.valueadd.util.RDMUtil;
import com.thomsonreuters.rfa.valueadd.util.ValueAddException;
import com.thomsonreuters.rfa.valueadd.util.ValueAddMessageKeys;

/**
 * Class representing login response attributes as defined in RDM user guide.
 * <li>Contains login name, name type as well as attributes for the login response message.
 * <li>As with all RDM attribute representation, use {@link #getAttribInfo(OMMPool)} to get encoded {@link OMMAttribInfo} from an object of this class.
 * <li>Similarly, use {@link #setAttribInfo(OMMAttribInfo)} or {@link #RDMLoginResponseAttrib(OMMAttribInfo)} to decode {@link OMMAttribInfo} 
 *    into an object of this class.
 * <li>When a field is not set, get method for the field returns default values as specified by the RDM usage guide. 
 *    If there is no default value, get method throws an exception of class ValueAddException.
 * <li>has methods checks if a field is set or not.      
 */
public class RDMLoginResponseAttrib
{
    private String name;
    private boolean hasName;
    private RDMLogin.NameType nameType;
    private boolean hasNameType;

    // attrib
    private EnumSet<RDMLogin.AllowSuspectData> allowSuspectData;
    private String applicationId;
    private String applicationName;
    private String position;
    private EnumSet<RDMLogin.ProvidePermissionExpressions> providePermissionExpressions;
    private EnumSet<RDMLogin.ProvidePermissionProfile> providePermissionProfile;
    private EnumSet<RDMLogin.SingleOpen> singleOpen;
    private EnumSet<RDMLogin.SupportBatchRequests> supportBatchRequests;
    private EnumSet<RDMLogin.SupportOMMPost> supportOMMPost;
    private EnumSet<RDMLogin.SupportOptimizedPauseResume> supportOptimizedPauseResume;
    private EnumSet<RDMLogin.SupportViewRequests> supportViewRequests;
    private EnumSet<RDMLogin.SupportStandby> supportStandby;
    private EnumSet<RDMLogin.SupportEnhancedSymbolList> supportEnhancedSymbolList;

    private boolean hasApplicationId;
    private boolean hasApplicationName;
    private boolean hasPosition;
    private boolean hasProvidePermissionProfile;
    private boolean hasProvidePermissionExpressions;
    private boolean hasSingleOpen;
    private boolean hasAllowSuspectData;
    private boolean hasSupportOptimizedPauseResume;
    private boolean hasSupportOMMPost;
    private boolean hasSupportViewRequests;
    private boolean hasSupportBatchRequests;
    private boolean hasSupportStandby;
    private boolean hasSupportEnhancedSymbolList;

    public static final int LOGIN_ATTRIB_ENCODER_SIZE = 1024;

    private static final RDMLogin.NameType DEFAULT_NAME_TYPE = RDMLogin.NameType
            .getNameType(RDMUser.NameType.USER_NAME);
    private static final EnumSet<RDMLogin.ProvidePermissionProfile> DEFAULT_PROV_PERMISSION_PROFILE = 
        EnumSet.of(RDMLogin.ProvidePermissionProfile.SUPPORTED);
    private static final EnumSet<RDMLogin.ProvidePermissionExpressions> DEFAULT_PROV_PERMISSION_EXPRS = 
        EnumSet.of(RDMLogin.ProvidePermissionExpressions.SUPPORTED);
    private static final EnumSet<RDMLogin.SingleOpen> DEFAULT_SINGLE_OPEN = 
        EnumSet.of(RDMLogin.SingleOpen.SUPPORTED);
    private static final EnumSet<RDMLogin.AllowSuspectData> DEFAULT_ALLOW_SUSPECT_DATA = 
        EnumSet.of(RDMLogin.AllowSuspectData.SUPPORTED);
    private static final EnumSet<RDMLogin.SupportOptimizedPauseResume> DEFAULT_SUPPORT_OPAR = 
        EnumSet.of(RDMLogin.SupportOptimizedPauseResume.NOT_SUPPORTED);
    private static final EnumSet<RDMLogin.SupportOMMPost> DEFAULT_SUPPORT_POST = EnumSet.of(RDMLogin.SupportOMMPost.NOT_SUPPORTED);
    private static final EnumSet<RDMLogin.SupportViewRequests> DEFAULT_SUPPORT_VIEW = EnumSet.of(RDMLogin.SupportViewRequests.NOT_SUPPORTED);
    private static final EnumSet<RDMLogin.SupportBatchRequests> DEFAULT_SUPPORT_BATCH =  EnumSet.of(RDMLogin.SupportBatchRequests.NOT_SUPPORTED);
    private static final EnumSet<RDMLogin.SupportStandby> DEFAULT_SUPPORT_STDBY =  EnumSet.of(RDMLogin.SupportStandby.NOT_SUPPORTED);
    private static final EnumSet<RDMLogin.SupportEnhancedSymbolList> DEFAULT_SUPPORT_ENHANCED_SYMBOL_LIST =  EnumSet.of(RDMLogin.SupportEnhancedSymbolList.NAMES_ONLY_SUPPORTED);

    public RDMLoginResponseAttrib()
    {
        setRDMDefaultValues();
    }

    /**
     * Decode OMMAttribInfo into this object.
     * @param ommAttribInfo to decode
     */
    public RDMLoginResponseAttrib(OMMAttribInfo ommAttribInfo)
    {
        setRDMDefaultValues();
        decode(ommAttribInfo);
    }

    /**
     * 
     * @param loginResponseAttrib
     */
    public RDMLoginResponseAttrib(RDMLoginResponseAttrib loginResponseAttrib)
    {
        if (!loginResponseAttrib.hasName())
            throw new ValueAddException(ValueAddException.ReasonCode.MISSING_REQUIRED_FIELD,
                    ValueAddMessageKeys.FIELD_NOT_SET.format("Name"));
        setRDMDefaultValues();
        setName(loginResponseAttrib.getName());
        if (loginResponseAttrib.hasNameType())
            setNameType(loginResponseAttrib.getNameType());
        if (loginResponseAttrib.hasAllowSuspectData())
            setAllowSuspectData(loginResponseAttrib.getAllowSuspectData());

        if (loginResponseAttrib.hasApplicationId())
            setApplicationId(loginResponseAttrib.getApplicationId());

        if (loginResponseAttrib.hasApplicationName())
            setApplicationName(loginResponseAttrib.getApplicationName());

        if (loginResponseAttrib.hasPosition())
            setPosition(loginResponseAttrib.getPosition());

        if (loginResponseAttrib.hasProvidePermissionExpressions())
            setProvidePermissionExpressions(loginResponseAttrib.getProvidePermissionExpressions());
        if (loginResponseAttrib.hasProvidePermissionProfile())
            setProvidePermissionProfile(loginResponseAttrib.getProvidePermissionProfile());
        if (loginResponseAttrib.hasSingleOpen())
            setSingleOpen(loginResponseAttrib.getSingleOpen());
        if (loginResponseAttrib.hasBatchSupport())
            setBatchSupport(loginResponseAttrib.getBatchSupport());

        if (loginResponseAttrib.hasOptimizedPauseResumeSupport())
            setOptimizedPauseResumeSupport(loginResponseAttrib.getOptimizedPauseResumeSupport());
        if (loginResponseAttrib.hasSupportOMMPost())
            setSupportOMMPost(loginResponseAttrib.getSupportOMMPost());
        if (loginResponseAttrib.hasStandbySupport())
            setStandbySupport(loginResponseAttrib.getStandbySupport());
        if (loginResponseAttrib.hasViewSupport())
            setViewSupport(loginResponseAttrib.getViewSupport());
        if (loginResponseAttrib.hasEnhancedSymbolListSupport())
            setEnhancedSymbolListSupport(loginResponseAttrib.getEnhancedSymbolListSupport());
    }

    /**
     * 
     * @return Login UserName.
     * @throws ValueAddException if name field is not set.
     */
    public String getName()
    {
        if (!hasName)
            throw new ValueAddException(ValueAddException.ReasonCode.MISSING_REQUIRED_FIELD,
                    ValueAddMessageKeys.FIELD_NOT_SET.format("Name"));

        return name;
    }

    /**
     * 
     * @param name
     */
    public void setName(String name)
    {
        this.name = name;
        hasName = true;
    }

    /**
     * 
     * @return Flag indicating presence of name field.
     */
    public boolean hasName()
    {
        return hasName;
    }

    /**
     * 
     * @return NameType. Default USER_NAME if name type field is not set.
     */
    public RDMLogin.NameType getNameType()
    {
        if (!hasNameType)
            return DEFAULT_NAME_TYPE;

        return nameType;
    }

    /**
     * 
     * @param nameType
     */
    public void setNameType(RDMLogin.NameType nameType)
    {
        this.nameType = nameType;
        hasNameType = true;
    }

    /**
     * 
     * @return Flag indicating presence of name type.
     */
    public boolean hasNameType()
    {
        return hasNameType;
    }

    /**
     * 
     * @return set of allow suspect data support flags. Default SUPPORTED flag.
     * 
     */
    public EnumSet<RDMLogin.AllowSuspectData> getAllowSuspectData()
    {
        if (!hasAllowSuspectData)
            return DEFAULT_ALLOW_SUSPECT_DATA;
        return allowSuspectData;
    }

    /**
     * 
     * @param allowSuspectData
     */
    public void setAllowSuspectData(EnumSet<RDMLogin.AllowSuspectData> allowSuspectData)
    {
        this.allowSuspectData = allowSuspectData;
        hasAllowSuspectData = true;
    }

    /**
     * 
     * @return Flag indicating presence of allow suspect data.
     */
    public boolean hasAllowSuspectData()
    {
        return hasAllowSuspectData;
    }

    /**
     * 
     * @return Set of provide permission profile support flags. Default is SUPPORTED. 
     */
    public EnumSet<RDMLogin.ProvidePermissionProfile> getProvidePermissionProfile()
    {
        if (!hasProvidePermissionProfile)
            return DEFAULT_PROV_PERMISSION_PROFILE;

        return providePermissionProfile;
    }

    /**
     * 
     * @param providePermissionProfile
     */
    public void setProvidePermissionProfile(
            EnumSet<RDMLogin.ProvidePermissionProfile> providePermissionProfile)
    {
        this.providePermissionProfile = providePermissionProfile;
        hasProvidePermissionProfile = true;
    }

    /**
     * 
     * @return Flag indicating presence of provide permission profile flag.
     */
    public boolean hasProvidePermissionProfile()
    {
        return hasProvidePermissionProfile;
    }

    /**
     * 
     * @return Set of provide permission expressions flags. Default is SUPPORTED.
     */
    public EnumSet<RDMLogin.ProvidePermissionExpressions> getProvidePermissionExpressions()
    {
        if (!hasProvidePermissionExpressions)
            return DEFAULT_PROV_PERMISSION_EXPRS;
        return providePermissionExpressions;
    }

    /**
     * 
     * @param providePermissionExpressions
     */
    public void setProvidePermissionExpressions(
            EnumSet<RDMLogin.ProvidePermissionExpressions> providePermissionExpressions)
    {
        this.providePermissionExpressions = providePermissionExpressions;
        this.hasProvidePermissionExpressions = true;
    }

    /**
     * 
     * @return Flag indicating presence of provide permission expressions.
     */
    public boolean hasProvidePermissionExpressions()
    {
        return hasProvidePermissionExpressions;
    }

    /**
     * 
     * @return Set of SingleOpen support flags. Default is SUPPORTED.
     */
    public EnumSet<RDMLogin.SingleOpen> getSingleOpen()
    {
        if (!hasSingleOpen)
            return DEFAULT_SINGLE_OPEN;
        return singleOpen;
    }

    /**
     * 
     * @param singleOpen
     */
    public void setSingleOpen(EnumSet<RDMLogin.SingleOpen> singleOpen)
    {
        this.singleOpen = singleOpen;
        hasSingleOpen = true;
    }

    /**
     * 
     * @return Flag indicating presence of single open support flags.
     */
    public boolean hasSingleOpen()
    {
        return hasSingleOpen;
    }

    /**
     * 
     * @return Set of Optimized pause resume flags. Default is NOT_SUPPORTED.
     */
    public EnumSet<RDMLogin.SupportOptimizedPauseResume> getOptimizedPauseResumeSupport()
    {
        if (!hasSupportOptimizedPauseResume)
            return DEFAULT_SUPPORT_OPAR;

        return supportOptimizedPauseResume;
    }

    /**
     * 
     * @param supportOptimizedPauseResume
     */
    public void setOptimizedPauseResumeSupport(
            EnumSet<RDMLogin.SupportOptimizedPauseResume> supportOptimizedPauseResume)
    {
        this.supportOptimizedPauseResume = supportOptimizedPauseResume;
        hasSupportOptimizedPauseResume = true;
    }

    /**
     * 
     * @return Flag indicating presence of optimized pause resume support field. 
     */
    public boolean hasOptimizedPauseResumeSupport()
    {
        return hasSupportOptimizedPauseResume;
    }

    /**
     * 
     * @return Set of omm post support flags. Default is NOT_SUPPORTED.
     */
    public EnumSet<RDMLogin.SupportOMMPost> getSupportOMMPost()
    {
        if (!hasSupportOMMPost)
            return DEFAULT_SUPPORT_POST;

        return supportOMMPost;
    }

    /**
     * 
     * @param supportOMMPost Set of omm post support flags.
     */
    public void setSupportOMMPost(EnumSet<RDMLogin.SupportOMMPost> supportOMMPost)
    {
        this.supportOMMPost = supportOMMPost;
        hasSupportOMMPost = true;
    }

    /**
     * 
     * @return Flag indicating presence of support omm post.
     */
    public boolean hasSupportOMMPost()
    {
        return hasSupportOMMPost;
    }

    /**
     * 
     * @return Set of view support flags. Default is NOT_SUPPORTED.
     */
    public EnumSet<RDMLogin.SupportViewRequests> getViewSupport()
    {
        if (!hasSupportViewRequests)
            return DEFAULT_SUPPORT_VIEW;

        return supportViewRequests;
    }

    /**
     * 
     * @param supportView
     */
    public void setViewSupport(EnumSet<RDMLogin.SupportViewRequests> supportView)
    {
        this.supportViewRequests = supportView;
        hasSupportViewRequests = true;
    }

    /**
     * 
     * @return Flag indicating presence of view support.
     */
    public boolean hasViewSupport()
    {
        return hasSupportViewRequests;
    }

    /**
     * 
     * @return Set of enhanced symbol list support flag. Default is NAMES_ONLY_SUPPORTED. 
     */
    public EnumSet<RDMLogin.SupportEnhancedSymbolList> getEnhancedSymbolListSupport()
    {
        if (!hasSupportEnhancedSymbolList)
            return DEFAULT_SUPPORT_ENHANCED_SYMBOL_LIST;

        return supportEnhancedSymbolList;
    }

    /**
     * 
     * @param supportEnhancedSymbolList
     */
    public void setEnhancedSymbolListSupport(EnumSet<RDMLogin.SupportEnhancedSymbolList> supportEnhancedSymbolList)
    {
        this.supportEnhancedSymbolList = supportEnhancedSymbolList;
        hasSupportEnhancedSymbolList = true;
    }

    /**
     * 
     * @return Flag indicating presence of support enhanced symbol list.
     */
    public boolean hasEnhancedSymbolListSupport()
    {
        return hasSupportEnhancedSymbolList;
    }

    /**
     * 
     * @return Set of batch support flag. Default is NOT_SUPPORTED. 
     */
    public EnumSet<RDMLogin.SupportBatchRequests> getBatchSupport()
    {
        if (!hasSupportBatchRequests)
            return DEFAULT_SUPPORT_BATCH;

        return supportBatchRequests;
    }

    /**
     * 
     * @param supportBatch
     */
    public void setBatchSupport(EnumSet<RDMLogin.SupportBatchRequests> supportBatch)
    {
        this.supportBatchRequests = supportBatch;
        hasSupportBatchRequests = true;
    }

    /**
     * 
     * @return Flag indicating presence of support batch.
     */
    public boolean hasBatchSupport()
    {
        return hasSupportBatchRequests;
    }

    /**
     * 
     * @return Set of standby support flags.
     */
    public EnumSet<RDMLogin.SupportStandby> getStandbySupport()
    {
        if (!hasSupportStandby)
            return DEFAULT_SUPPORT_STDBY;

        return supportStandby;
    }

    /**
     * 
     * @param supportStandby
     */
    public void setStandbySupport(EnumSet<RDMLogin.SupportStandby> supportStandby)
    {
        this.supportStandby = supportStandby;
        hasSupportStandby = true;
    }

    /**
     * 
     * @return Presence of standby support flag.
     */
    public boolean hasStandbySupport()
    {
        return hasSupportStandby;
    }

    /**
     * 
     * @return ApplicationId.
     * @throws ValueAddException if ApplicationId is not set.
     */
    public String getApplicationId()
    {
        if (hasApplicationId)
            return applicationId;

        throw new ValueAddException(ValueAddException.ReasonCode.MISSING_OPTIONAL_FIELD,
                ValueAddMessageKeys.FIELD_NOT_SET.format("ApplicationId"));
    }

    /**
     * 
     * @param applicationId
     */
    public void setApplicationId(String applicationId)
    {
        this.applicationId = applicationId;
        if (applicationId != null && applicationId.length() > 0)
            hasApplicationId = true;
    }

    /**
     * 
     * @return Flag indicating presence of ApplicationId.
     */
    public boolean hasApplicationId()
    {
        return hasApplicationId;
    }

    /**
     * 
     * @return ApplicationName.
     * @throws ValueAddException if application name is not set.
     */
    public String getApplicationName()
    {
        if (hasApplicationName)
            return applicationName;

        throw new ValueAddException(ValueAddException.ReasonCode.MISSING_OPTIONAL_FIELD,
                ValueAddMessageKeys.FIELD_NOT_SET.format("ApplicationName"));
    }

    /**
     * 
     * @param applicationName
     */
    public void setApplicationName(String applicationName)
    {
        this.applicationName = applicationName;
        if (applicationName != null && applicationName.length() > 0)
            hasApplicationName = true;
    }

    /**
     * 
     * @return Presence of application name.
     */
    public boolean hasApplicationName()
    {
        return hasApplicationName;
    }

    /**
     * 
     * @return Position.
     */
    public String getPosition()
    {
        if (hasPosition)
            return position;

        throw new ValueAddException(ValueAddException.ReasonCode.MISSING_OPTIONAL_FIELD,
                ValueAddMessageKeys.FIELD_NOT_SET.format("Position"));
    }

    /**
     * 
     * @param position
     */
    public void setPosition(String position)
    {
        this.position = position;
        if (position != null && position.length() > 0)
            hasPosition = true;
    }

    /**
     * 
     * @return Flag representing presence of position.
     */
    public boolean hasPosition()
    {
        return hasPosition;
    }

    /**
     * Clears all previous values and decode OMMAttribInfo into this object.
     * @param ommAttribInfo to decode the login request attributes.
     */
    public void setAttribInfo(OMMAttribInfo ommAttribInfo)
    {
        decode(ommAttribInfo);
    }
    
    /**
     * @param pool from which OMMAttribInfo is acquired.
     * @return encoded OMMAttribInfo object from this object. 
     *         User needs to release the returned OMMAttribInfo into the same pool used to call this method. 
     * @throws ValueAddException if required user name is not set.
     */
    public OMMAttribInfo getAttribInfo(OMMPool pool)
    {
        if (!hasName)
                throw new ValueAddException(ValueAddException.ReasonCode.MISSING_REQUIRED_FIELD,
                    ValueAddMessageKeys.FIELD_NOT_SET.format("Name"));

        //there is no way to initialize attribute information for encoding attrib
        //encoder.initialize(OMMTypes.ATTRIB_INFO,...)
        //encoder.encodeAttribInfoInit(attribInfo, OMMTypes.ELEMENT_LIST...)
        //and then encode attrib using encoder.encodeElementList...
        //Also there is no public setAttrib() on attribinfo interface
        //cheat to encode omm message first and then return copy of attrib info from that message.
        OMMMsg ommMsg = pool.acquireMsg();
        
        //Message type is not used in encoded attrib info.
        ommMsg.setMsgType(RDMLoginResponse.MessageType.getValue(RDMLoginResponse.MessageType.GENERIC));
     
        OMMMsg encMsg = encode(pool, ommMsg);
        OMMAttribInfo ommAttribInfo = pool.acquireCopy(encMsg.getAttribInfo(), true);
        pool.releaseMsg(encMsg);
      
        return ommAttribInfo;
    }

    /**
     * Clears previously set values to make this object reusable.
     */
    public void clear()
    {
        hasName = false;
        hasNameType = false;

        hasApplicationId = false;
        hasApplicationName = false;
        hasPosition = false;
        hasProvidePermissionProfile = false;
        hasProvidePermissionExpressions = false;
        hasSingleOpen = false;
        hasAllowSuspectData = false;
        hasSupportOptimizedPauseResume = false;
        hasSupportOMMPost = false;
        hasSupportViewRequests = false;
        hasSupportBatchRequests = false;
        hasSupportStandby = false;
        hasSupportEnhancedSymbolList = false;
        setRDMDefaultValues();
    }

    OMMMsg encode(OMMPool pool, OMMMsg msg)
    {
        if (hasName)
            msg.setAttribInfo(null, name, RDMLogin.NameType.getValue(nameType));
        else
            throw new ValueAddException(ValueAddException.ReasonCode.MISSING_REQUIRED_FIELD,
                    ValueAddMessageKeys.FIELD_NOT_SET.format("Name"));

        if (!(hasProvidePermissionProfile || hasProvidePermissionExpressions || hasSingleOpen
                || hasAllowSuspectData || hasSupportOptimizedPauseResume || hasSupportOMMPost
                || hasSupportViewRequests || hasSupportBatchRequests || hasSupportStandby
                || hasSupportEnhancedSymbolList || hasApplicationId || hasApplicationName || hasPosition))
        {
            return msg;
        }

        // AttribInfo.Attrib
        OMMEncoder encoder = pool.acquireEncoder();
        encoder.initialize(OMMTypes.MSG, LOGIN_ATTRIB_ENCODER_SIZE);
        encoder.encodeMsgInit(msg, OMMTypes.ELEMENT_LIST, OMMTypes.NO_DATA);
        encoder.encodeElementListInit(OMMElementList.HAS_STANDARD_DATA, (short)0, (short)0);

        if (hasApplicationId)
        {
            encoder.encodeElementEntryInit(RDMUser.Attrib.ApplicationId, OMMTypes.ASCII_STRING);
            encoder.encodeString(applicationId, OMMTypes.ASCII_STRING);
        }

        if (hasApplicationName)
        {
            encoder.encodeElementEntryInit(RDMUser.Attrib.ApplicationName, OMMTypes.ASCII_STRING);
            encoder.encodeString(applicationName, OMMTypes.ASCII_STRING);
        }

        if (hasPosition)
        {
            encoder.encodeElementEntryInit(RDMUser.Attrib.Position, OMMTypes.ASCII_STRING);
            encoder.encodeString(position, OMMTypes.ASCII_STRING);
        }

        if (hasProvidePermissionProfile)
        {
            encoder.encodeElementEntryInit(RDMUser.Attrib.ProvidePermissionProfile, OMMTypes.UINT);
            encoder.encodeUInt(RDMLogin.ProvidePermissionProfile
                    .getValue(providePermissionProfile));
        }
        if (hasProvidePermissionExpressions)
        {
            encoder.encodeElementEntryInit(RDMUser.Attrib.ProvidePermissionExpressions,
                                           OMMTypes.UINT);
            encoder.encodeUInt(RDMLogin.ProvidePermissionExpressions
                    .getValue(providePermissionExpressions));
        }
        if (hasSingleOpen)
        {
            encoder.encodeElementEntryInit(RDMUser.Attrib.SingleOpen, OMMTypes.UINT);
            encoder.encodeUInt(RDMLogin.SingleOpen.getValue(singleOpen));
        }
        if (hasAllowSuspectData)
        {
            encoder.encodeElementEntryInit(RDMUser.Attrib.AllowSuspectData, OMMTypes.UINT);
            encoder.encodeUInt(RDMLogin.AllowSuspectData.getValue(allowSuspectData));
        }

        if (hasSupportOptimizedPauseResume)
        {
            encoder.encodeElementEntryInit(RDMUser.Attrib.SupportOptimizedPauseResume,
                                           OMMTypes.UINT);
            encoder.encodeUInt(RDMLogin.SupportOptimizedPauseResume.getValue(supportOptimizedPauseResume));
        }
        if (hasSupportOMMPost)
        {
            encoder.encodeElementEntryInit(RDMUser.Attrib.SupportOMMPost, OMMTypes.UINT);
            encoder.encodeUInt(RDMLogin.SupportOMMPost.getValue(supportOMMPost));
        }
        if (hasSupportViewRequests)
        {
            encoder.encodeElementEntryInit(RDMUser.Attrib.SupportViewRequests, OMMTypes.UINT);
            encoder.encodeUInt(RDMLogin.SupportViewRequests.getValue(supportViewRequests));
        }
        if (hasSupportBatchRequests)
        {
            encoder.encodeElementEntryInit(RDMUser.Attrib.SupportBatchRequests, OMMTypes.UINT);
            encoder.encodeUInt(RDMLogin.SupportBatchRequests.getValue(supportBatchRequests));
        }
        if (hasSupportEnhancedSymbolList)
        {
            encoder.encodeElementEntryInit(RDMUser.Attrib.SupportEnhancedSymbolList, OMMTypes.UINT);
            encoder.encodeUInt(RDMLogin.SupportEnhancedSymbolList.getValue(supportEnhancedSymbolList));
        }
        if (hasSupportStandby)
        {
            encoder.encodeElementEntryInit(RDMUser.Attrib.SupportStandby, OMMTypes.UINT);
            encoder.encodeUInt(RDMLogin.SupportStandby.getValue(supportStandby));
        }
        encoder.encodeAggregateComplete();

        OMMMsg encMsg = (OMMMsg)encoder.acquireEncodedObject();

        pool.releaseMsg(msg);
        pool.releaseEncoder(encoder);

        return encMsg;
    }

    void decode(OMMAttribInfo ommAttribInfo)
    {
        clear();
        if (ommAttribInfo.has(OMMAttribInfo.HAS_ATTRIB)
                && ommAttribInfo.getAttribType() != OMMTypes.ELEMENT_LIST)
            throw new ValueAddException(ValueAddMessageKeys.INVALID_DATA_TYPE.format(OMMTypes.toString(OMMTypes.ELEMENT_LIST), OMMTypes.toString(ommAttribInfo.getType())));
        
        if (!ommAttribInfo.has(OMMAttribInfo.HAS_NAME))
            throw new ValueAddException(ValueAddException.ReasonCode.MISSING_REQUIRED_FIELD,
                    ValueAddMessageKeys.FIELD_NOT_SET.format("Name"));

        if (ommAttribInfo.has(OMMAttribInfo.HAS_NAME_TYPE))
        {
            switch (ommAttribInfo.getNameType())
            {
                case RDMUser.NameType.USER_NAME:
                case RDMUser.NameType.EMAIL_ADDRESS:
                case RDMUser.NameType.USER_TOKEN:
                    break;
                default:
                    throw new ValueAddException(
                            ValueAddMessageKeys.INVALID_NAME_TYPE.format(ommAttribInfo
                                    .getNameType()));
            }
        }

        name = ommAttribInfo.getName();
        hasName = true;

        if (ommAttribInfo.has(OMMAttribInfo.HAS_NAME_TYPE))
        {
            nameType = RDMLogin.NameType.getNameType(ommAttribInfo.getNameType());
            hasNameType = true;
        }
        if (ommAttribInfo.has(OMMAttribInfo.HAS_ATTRIB))
        {
            OMMData attrib = ommAttribInfo.getAttrib();
            if (attrib != null && attrib.getType() == OMMTypes.ELEMENT_LIST)
            {
                OMMElementList elementList = (OMMElementList)attrib;
                for (Iterator<?> iter = elementList.iterator(); iter.hasNext();)
                {
                    OMMElementEntry element = (OMMElementEntry)iter.next();
                    OMMData data = element.getData();
                    if (element.getName().equals(RDMUser.Attrib.ApplicationId))
                    {
                        setApplicationId(data.toString());
                    }
                    else if (element.getName().equals(RDMUser.Attrib.ApplicationName))
                    {
                        setApplicationName(data.toString());
                    }
                    else if (element.getName().equals(RDMUser.Attrib.Position))
                    {
                        setPosition(data.toString());
                    }
                    else if (element.getName().equals(RDMUser.Attrib.ProvidePermissionProfile))
                    {
                        setProvidePermissionProfile(RDMLogin.ProvidePermissionProfile
                                .getProvidePermissionProfile((int)RDMUtil.getLongValue(data)));
                    }
                    else if (element.getName().equals(RDMUser.Attrib.ProvidePermissionExpressions))
                    {
                        setProvidePermissionExpressions(RDMLogin.ProvidePermissionExpressions
                                .getProvidePermissionExpressions((int)RDMUtil.getLongValue(data)));
                    }
                    else if (element.getName().equals(RDMUser.Attrib.SingleOpen))
                    {
                        setSingleOpen(RDMLogin.SingleOpen.getSingleOpen((int)RDMUtil
                                .getLongValue(data)));
                    }
                    else if (element.getName().equals(RDMUser.Attrib.AllowSuspectData))
                    {
                        setAllowSuspectData(RDMLogin.AllowSuspectData.getAllowSuspectData((int)RDMUtil
                                .getLongValue(data)));
                    }
                    else if (element.getName().equals(RDMUser.Attrib.SupportOptimizedPauseResume))
                    {
                        setOptimizedPauseResumeSupport(RDMLogin.SupportOptimizedPauseResume
                                .getSupportOptimizedPauseResume((int)RDMUtil.getLongValue(data)));
                    }
                    else if (element.getName().equals(RDMUser.Attrib.SupportOMMPost))
                    {
                        setSupportOMMPost(RDMLogin.SupportOMMPost.getPostSupport((int)RDMUtil.getLongValue(data)));
                    }
                    else if (element.getName().equals(RDMUser.Attrib.SupportViewRequests))
                    {
                        setViewSupport(RDMLogin.SupportViewRequests.getViewSupport((int)RDMUtil.getLongValue(data)));
                    }
                    else if (element.getName().equals(RDMUser.Attrib.SupportBatchRequests))
                    {
                        setBatchSupport(RDMLogin.SupportBatchRequests.getBatchSupport((int)RDMUtil.getLongValue(data)));
                    }
                    else if (element.getName().equals(RDMUser.Attrib.SupportEnhancedSymbolList))
                    {
                        setEnhancedSymbolListSupport(RDMLogin.SupportEnhancedSymbolList.getEnhancedSymbolListSupport((int)RDMUtil.getLongValue(data)));
                    }
                    else if (element.getName().equals(RDMUser.Attrib.SupportStandby))
                    {
                        setStandbySupport(RDMLogin.SupportStandby.getStandbySupport((int)RDMUtil
                                .getLongValue(data)));
                    }
                }
            }
        }
    }

    private void setRDMDefaultValues()
    {
        nameType = DEFAULT_NAME_TYPE;

        singleOpen = DEFAULT_SINGLE_OPEN;
        allowSuspectData = DEFAULT_ALLOW_SUSPECT_DATA;
        providePermissionExpressions = DEFAULT_PROV_PERMISSION_EXPRS;
        providePermissionProfile = DEFAULT_PROV_PERMISSION_PROFILE;
        supportOptimizedPauseResume = DEFAULT_SUPPORT_OPAR;
        supportOMMPost = DEFAULT_SUPPORT_POST;
        supportViewRequests = DEFAULT_SUPPORT_VIEW;
        supportBatchRequests = DEFAULT_SUPPORT_BATCH;
        supportEnhancedSymbolList = DEFAULT_SUPPORT_ENHANCED_SYMBOL_LIST;
        supportStandby = DEFAULT_SUPPORT_STDBY;
    }
}
